package core;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

/**
 1) HashMap is non synchronized. It is not-thread safe and can't be shared between many threads without proper synchronization code.
 Hashtable is synchronized. It is thread-safe and can be shared with many threads.
 2) HashMap allows one null key and multiple null values.
  - Hashtable doesn't allow any null key or value.
    why? https://stackoverflow.com/questions/11981852/why-hashtable-does-not-allow-null-keys-or
 -values
 3) HashMap is a new class introduced in JDK 1.2.
  - Hashtable is a legacy class.
 4) HashMap is fast.
   - Hashtable is slow.
 5) We can make the HashMap as synchronized by calling this code
    Map m = Collections.synchronizedMap(hashMap);
  - Hashtable is internally synchronized and can't be unsynchronized.
 6) HashMap is traversed by Iterator.
   - Hashtable is traversed by Enumerator and Iterator.
 7) Iterator in HashMap is fail-fast.
   - Enumerator in Hashtable is not fail-fast.
 8) HashMap inherits AbstractMap class.
   - Hashtable inherits Dictionary class.
 */
public class _0_Collections_HashTableVSHashMap {
    public static void main(String args[]){
    //1. HT does not allow null keys
        // HT does not allow null value
        Hashtable<Integer, Integer> ht = new Hashtable<>();
        ht.put(1,1);
        //ht.put(1, null); // Error NPE
        //ht.put(null, 2); // Error NPE

        //** HM ALLOW NULL KEY OR NULL VALUE
        HashMap<Integer, Integer> hm  = new HashMap<>();
        hm.put(1,1);
        hm.put(1, null);
        hm.put(null, 2);
        hm.put(null, 7); // this will override so null-7 and 1-null are 2 entries in this map

     // 2. HM iterator is fail fast, meaning if you modify collection while iteration you see error
        try{
            Iterator<Integer> it = hm.keySet().iterator();
            while (it.hasNext()){
                it.next();
                hm.remove(1);
            }
        }catch(Exception e){
            System.out.println("HashMap iterator is fail fast "+e);

        }
    // 2.2 HT
        Iterator it = ht.keySet().iterator();
        while (it.hasNext()){
            it.next();
            ht.remove(1);
            System.out.println("Hash Table no error it is fail safe");
        }
    // 2.3 Concurrent HM
        ConcurrentHashMap<Integer, Integer> cm = new ConcurrentHashMap<>();
        //cm.putAll(hm);
        cm.put(1,1);
        cm.put(1,1);
        cm.put(1,1);
        // cm.put(1, null);   // Error NPE
        // cm.put(null, 2);   // Error NPE
        System.out.println("CM does not allow null keys or values because: you can change the map" +
                " between calls during iteration and hence there is no way to know if " +
                "null is returned because a key is removed or was actually null from the " +
                "beginning");
        it = cm.keySet().iterator();

        while (it.hasNext()){
            it.next();
            ht.remove(1);
            System.out.println("ConcurrentHashMap no error it is fail safe");
        }
    }
}
