package core;

public class Node {
	public Node next;
	public Integer data;

	public Node(Integer value) {
		this.data = value;
	}
}
