package core;

public class _2_GenericSum {
	public static void main(String[] args) {
		Sum<Float> a = new Sum<>();
		a.sum(10.9F, 12);
		Sum2.sum(12.0F, 13.9F);
		
		//multiple params
		Sum3<Float, Float> sum3  = new Sum3<>();
		sum3.sum(12.0F, 13.9F);
	}
}


class Sum<T extends Number>{
	void sum(T t, int u) {
		// System.out.println(t+u); -- this line will generate error, operator + cannot be applied to T
		if(t instanceof Float) {
			System.out.println("float>> "+ (t.floatValue() + u));
		}else {
			System.out.println("dbl>>" + (t.doubleValue() + u));
		}
	}
}

// When we only need a Generic method, note between modifier and return type you have to 
// mention the type parameter used in the method
class Sum2{
	static <T extends Number> void sum(T t, T u) {
		System.out.println(" generic method " + (t.doubleValue() + u.doubleValue()));
	}
}

// Multiple parameters
class Sum3<T extends Number, U extends Number>{
	void sum(T t, U u) {
		System.out.println(" multiparam " +(t.doubleValue() + u.doubleValue()));
	}
}