package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;
/**
 * Date: 3/3/19
 * Remember: To return "0" at height inplace of -1, because in logic of diam is 1+lh+rh
 * so at leaf node you will get 1-1-1 = -1 as diam : for ex at node 18 in below tree diam is 1
 * but if height returns -1 at null node then diam is -1
 */

/*
                                1
                ┌───────────────┴───────────────┐              diameter at 2 = 8
                2                               3
        ┌───────┴───────┐
        4               5
    ┌───┘           ┌───┘
    8               6
  ┌─┘               └─┐
 18                   7
                     ┌┘
                    17


                       90                       diameter at 90 = 7
            ┌───────────┴───────────┐
           50                      150
      ┌─────┴─────┐           ┌─────┴─────┐
     30          25          35          32
   ┌──┴──┐     ┌──┴──┐     ┌──┘
  33    70    155   152   34

*/

public class _Tree_19_Diameter {
    public static void main(String args[]) {
        // when diameter passes through root element
        int[] ar = new int[]{90, 50, 150, 30, 25, 35, 32, 33, 70, 155, 152, 34};
        Node root1 = TreePrint.create(ar);
        System.out.println(diameter(root1));
        System.out.println(" improved " +diameterImproved(root1));
        // when diameter passes through non-root element
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.left.right.left = new Node(6);
        root.left.right.left.right = new Node(7);
        root.left.right.left.right.left = new Node(17);
        root.left.left.left = new Node(8);
        root.left.left.left.left = new Node(18);
        TreePrint.print(root);
        System.out.println(diameter(root));
        System.out.println(" improved " +diameterImproved(root).diam);
    }

    static DiamAndHght diameterImproved(Node root) {
        if (root == null) {
            return new DiamAndHght(0,0);
        }
        DiamAndHght l = diameterImproved(root.left);
        DiamAndHght r = diameterImproved(root.right);
        int leftHeight = l.hgt;
        int rightHeight = r.hgt;
        int diameter = 1+ leftHeight + rightHeight;
        int maxHeight = 1+ Math.max(leftHeight, rightHeight);
        int leftDiameter = l.diam;
        int rightDiameter = r.diam;
        return new DiamAndHght(maxHeight, Math.max(diameter, Math.max(leftDiameter, rightDiameter)));
    }
    static int diameter(Node root) {
        if (root == null) {
            return 0;
        }
        int leftDiameter = diameter(root.left);
        int rightDiameter = diameter(root.right);
        int diameter = Math.max((1 + height(root.left) + height(root.right)), Math.max( leftDiameter,
                rightDiameter));
        return diameter;

    }

    static int height(Node root) {
        if (root == null) {
            return 0;
        }
        return 1 + Math.max(height(root.left), height(root.right));
    }
}
class DiamAndHght{
    int diam;
    int hgt;
    public DiamAndHght(int hgt, int diam){
        this.hgt = hgt;
        this.diam = diam;
    }
}
