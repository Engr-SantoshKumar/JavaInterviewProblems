package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/4/19
 *
 * *DOUBT: when one of a, b does not exist what should be the o/p with this logic it gives the one
 * that exists as the LCA
 *  *                                 1
 *  *                 ┌───────────────┴───────────────┐
 *  *                 2                               3     Ans:  Left view .. 1, 2, 4, 8, 18, 17
 *  *         ┌───────┴───────┐                                  Right view .. 1, 3, 5, 6, 7, 17
 *  *         4               5
 *  *     ┌───┘           ┌───┘
 *  *     8               6
 *  *   ┌─┘               └─┐
 *  *  18                   7
 *  *                      ┌┘
 *  *                     17
 *  *
 * Remember:
 */
public class _Tree_27_LCA_BinaryTree {
    public static void main(String args[]) {
        Node root = TreePrint.getUnBalancedTree();
        System.out.println(" lca of 18, 6 => " + lca(root, 6,  5).data);

    }
    static Node lca(Node root, int a, int b){
        if(root == null){
            return null;
        }

        if(root.data == a || root.data == b){
            return root;
        }
        Node left = lca(root.left, a, b);
        Node right = lca(root.right, a, b);


        if(left != null && right != null){
            return root;
        }
        if(left!=null){
            return left;
        }
        if(right!=null){
            return right;
        }
        return null;
    }
}




















