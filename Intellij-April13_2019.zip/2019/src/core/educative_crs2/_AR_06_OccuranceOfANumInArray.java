package core.educative_crs2;

import java.util.Arrays;
import java.util.HashSet;

// This soultion is from mycodeschool
// It just uses the prev program to find lo and hi idx of a number to
// find occurances
public class _AR_06_OccuranceOfANumInArray {
	static HashSet<Integer> set = new HashSet<>();
	public static void main(String[] args) {
		Integer[] ar = new Integer[] { 1, 2, 3, 3, 4, 5, 5, 5, 5, 5, 20, 20, 21 , 21, 22 };
		for(int i=0;i<ar.length ; i++) {
			System.out.print(","+ar[i]+"["+i+"]");
		}
		set.addAll(Arrays.asList(ar));
		for(Integer a : set) {
			System.out.println(" \nfind for "+a+" .. ");
			int loIdx = findLoIdx(ar, a);
			int hiIdx = findHiIdx(ar, a);
			System.out.println(" range from "+loIdx+" "+hiIdx);
			System.out.println(" total occurance "+ (hiIdx-loIdx+1));
		}
	}

	static int findLoIdx(Integer[] ar, Integer key) {
		int lo = 0;
		int hi = ar.length - 1;
		int loIdx = -1; 
		while (lo <= hi) {
			int mid = (lo+hi)/2;
			if(ar[mid] > key) {
				hi = mid-1;
			}else if (ar[mid] < key) {
				lo = mid+1;
			}else if(ar[mid] == key) {
				    loIdx = mid;// we got a temp result but will keep finding on left
					hi=mid-1;
			}
		}
			//System.out.println(" now hi becomes "+hi+" lo is "+lo+ " lo index is "+loIdx);
		return loIdx;
	}
	static int findHiIdx(Integer[] ar, Integer key) {
		int lo = 0;
		int hi = ar.length - 1;
		int hiIdx = -1; 
		while (lo <= hi) {
			int mid = (lo+hi)/2;
			if(ar[mid] > key) {
				hi = mid-1;
			}else if (ar[mid] < key) {
				lo = mid+1;
			}else if(ar[mid] == key) {
				    hiIdx = mid;// we got a temp result but will keep finding on left
					lo=mid+1;
			}
		}
		return hiIdx;
	}
}