package core.educative_crs2;

import java.util.Arrays;

// solution from : https://www.youtube.com/playlist?list=PL2_aWCzGMAwL3ldWlrii6YeLszojgH77j
public class _AB_BinarySrchINSortedRotatedArray {
	
	// Solution from mycodeschool
	static int search(int[] ar, int key) {
		int lo = 0;
		int hi = ar.length - 1;

		// normal check line bin src
		while (lo <= hi) {
			int mid = lo + (hi - lo) / 2;
			if (key == ar[mid])
				return mid;

			// If it is ordered from mid to high
			if (ar[mid] <= ar[hi]) { // second half means this part is sorted
				if (key > ar[mid] && key <= ar[hi]) { // good case, target in between mid to hi
					lo = mid + 1;
				} else { // lets try in other part
					hi = mid - 1;
				}
			} else {// unordered
				if (key >= ar[lo] && key < ar[mid]) {// good case, search in sorted part
					hi = mid - 1;
				} else { // if target is not in range lets try in other part
					lo = mid + 1;
				}
			}
		}

		return -1;
	}
	// THis is my old solution and works well
	static int search1(int[] nums, int target) {
		int lo = 0;
		int hi = nums.length - 1;

		// normal check line bin src
		while (lo <= hi) {
			int mid = lo + (hi - lo) / 2;
			if (target == nums[mid])// || target==nums[lo] || target==nums[hi])
				return mid;

			// If it is ordered from lo to mid
			if (nums[lo] <= nums[mid]) {
				if (nums[lo] <= target && target < nums[mid]) { // good case, target in between lo - mid, <= sign on lo
																// as we will shift mid
					hi = mid - 1;
				} else { // lets try in other part
					lo = mid + 1;
				}
			} else {// unordered
				if (nums[mid] < target && target <= nums[hi]) {// good case, tarteg in range
					lo = mid + 1;
				} else { // if target is not in range lets try in other part
					hi = mid - 1;
				}
			}
		}

		return -1;
	}
	public static void main(String[] args) {
		int[] arr = new int[] { 1, 2, 3, 4, 5, 6, 0 };
		System.out.println(" hi" + search(arr, 6));

		int[] ar = new int[] { 9, 2, 3, 4, 5, 6 };
		int[] arNotRotated = new int[] { 1, 2, 3, 4, 5, 6 };
		int[] arLastElement = new int[] { 1, 2, 3, 4, 5, 6, 0 };
		int[] arSecondElement = new int[] { 1, 2, 3, 4, 5, 6, 0 };
		// int[] reversArray = new int[] { 9, 8, 7, 6, 5, 4, 3, 2, 1 };
		int[][] arrayOfArrays = new int[][] { arNotRotated, ar, arLastElement, arSecondElement };
		for (int[] a : arrayOfArrays) {
			int x = search(a, 6);
			System.out.println(" index of elemnt in rotated array is " + Arrays.toString(a) + " is " + x);
		}
	}
}
