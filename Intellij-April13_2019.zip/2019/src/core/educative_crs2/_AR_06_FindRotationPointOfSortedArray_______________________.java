package core.educative_crs2;

import java.util.HashSet;

//https://www.educative.io/collection/page/5642554087309312/5679846214598656/130003
/*Given a sorted array of integers, return the low and high index of the given key. Return -1 if not found. The array length can be in millions with lots of duplicates.*/

public class _AR_06_FindRotationPointOfSortedArray_______________________ {
	static HashSet<Integer> set = new HashSet<>();

	// This solution is from mycodeSchool
	//https://www.youtube.com/watch?v=4qjprDkJrjY&list=PL2_aWCzGMAwL3ldWlrii6YeLszojgH77j&index=7&t=0s
//FULL SERIES HERE	// https://www.youtube.com/playlist?list=PL2_aWCzGMAwL3ldWlrii6YeLszojgH77j
	static void rotation(Integer[] ar) {
		// IMPLEMENT FROM MYCODESCHOOL, VERY NICE IMPL
	}

	public static void main(String[] args) {
		Integer[] ar = new Integer[] { 1, 2, 3, 3, 4, 5, 5, 5, 5, 5, 20, 20, 21 , 21, 22 };
		for(int i=0;i<ar.length ; i++) {
			System.out.print(","+ar[i]+"["+i+"]");
		}
	}
	
	
}