package core.educative_crs2;

/**
 * Date: 3/4/19
 * jus opposite of bottom view, best to do using BFS, if map contains an entry for that Col dont
 * do any thing
 */
public class _Tree_26_TopView {
}
