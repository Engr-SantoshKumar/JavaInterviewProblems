package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayDeque;

/**
 * Date: 3/6/19
 * Remember: print the root and push right, push left, this is the easiest of all traversals
 *
 *  *                 6
 *  *         ┌───────┴───────┐         // Ans : 6, 4, 2, 1, 3, 5, 8, 7, 9
 *  *         4               8
 *  *     ┌───┴───┐       ┌───┴───┐
 *  *     2       5       7       9
 *  *   ┌─┴─┐
 *  *   1   3
 *
 */
public class _Tree_31_PreOrderWORec_Easiest {
    public static void main(String args[]){
        Node root = TreePrint.create(new int[]{6,4,8,2,5,7,9,1,3});
        ArrayDeque<Node> stack = new ArrayDeque<>();
        preOrder(root, stack);

    }
    static void preOrder(Node root, ArrayDeque<Node> stack){
        stack.push(root);
        while(!stack.isEmpty()){
            Node r = stack.pop();
            System.out.print(", " +r.data);
            if(r.right != null){
                stack.push(r.right);
            }
            if(r.left!= null){
                stack.push(r.left);
            }
        }
    }
}
