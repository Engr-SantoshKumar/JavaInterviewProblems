package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/1/19
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_04_NthHighestinBST {
    static int n = 0;
    static Node result=null;
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{6, 4, 8, 2, 5, 7, 9, 1, 3});
        for (int i = 1; i < 12; i++) {
            n = i;
            Node rootCopy = r;
            Node result = F(rootCopy);
            System.out.println(i + " th highest is " + (result != null ? result.data : " not " +
                    "found"));
        }

        for (int i = 1; i < 12; i++) {
            int[] ar = new int[]{i, -1};
            Node rootCopy = r;
            F(rootCopy, ar);
            System.out.println(i + " th highest is " + ar[1]);
        }

        for (int i = 1; i < 12; i++) {
            //int[] ar = new int[]{i, -1};
            Node rootCopy = r;
            result = null;
            F(rootCopy, i);
            System.out.println(i + " th highest is " + (result!=null? result.data:-1));
        }
    }
    // Easiest way: this is same as considering both as global variables
    static void F(Node root, int[] ar) {
        if (root == null) {
            return;
        }
        F(root.right, ar);
        if (ar[1] > -1) {
            return;
        }
        if (--ar[0] == 0) {
            ar[1] = root.data;
        }
        F(root.left, ar);
    }

    // When you want to return the value as Node all the way to the root, and we also used
    // one global variable "n"
    static Node F(Node root) {
        if (root == null) {
            return null;
        }

        Node rr = F(root.right);
        if (rr != null) {
            return rr;
        }
        if (--n == 0) {
            return root;
        }
        return F(root.left);
        // note why no return required here, as when we are done with left we just want to return
        // to the caller
        // what happens when we do this    F(root.left) ;
                                         // return null;
        // if we do this then at 8 once it is done with right of 8 we go to 7 and then 7.right
        // 7.right returns null  and --n==0 satisfies for 7 hence from 7 i return Node(7)
        // but at 8 when F(root.left) returned 7, after that we return null, so the result is lost
        /*
              F(8) ->F(R)/ F(9) -> F(9.R) <- null
                   ->F(L)/ F(7) -> F(7.R) <- null
                           --n==0? yes return Node(7)
                   -> return null; // this throws the o/p returned by F(7)
        */
    }

    // method that exchanges N and decides the nth highest
    static int F(Node root, int n) {
        if (root == null) {
            return n;
        }
        if(result!=null){
            return n;
        }
        n = F(root.right, n);
        n--;
        if (n == 0) {
            result = root;
            return n;
        }

        return F(root.left, n);
    }
}
