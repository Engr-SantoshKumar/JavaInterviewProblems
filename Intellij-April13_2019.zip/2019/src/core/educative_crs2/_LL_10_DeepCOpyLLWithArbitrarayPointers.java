package core.educative_crs2;

import java.util.HashMap;
import java.util.Map;

/**
 * Date: 2/24/19
 * Problem Description:deep copy a LL when one node has regular next and also points to an arbitrary pointer
 * Solution: // first copy only nexts to new ll then copy arb pointers
 * // in hm make entry of <oldNode, newNode> to later update arb ponters
 */
public class _LL_10_DeepCOpyLLWithArbitrarayPointers {
    static LinkedListNode deepCopy(LinkedListNode head){
        Map<LinkedListNode, LinkedListNode> map = new HashMap<>();
        LinkedListNode newHead = null;
        LinkedListNode prev = null;
        while(head!=null){
            LinkedListNode newNode = new LinkedListNode(head.data);
            if(newHead == null){
                newHead = newNode;
                prev = newNode;
            }else{
                prev.next = newNode;
                prev = newNode;
            }
            // New node in new ll is just having data but still point arbitrary of old List Node's arb
            newNode.arbitrary_pointer = head.arbitrary_pointer;
            map.put(head, newNode);//in map <Original Node, New Node(d=1, next = another New Node, arb->other Orig Node>
            head = head.next;
        }
        System.out.println(" map size "+map.values());
        for(LinkedListNode x : map.values()){
            System.out.println(" ndoe "+x.data);// " next "+x.next.data);
        }
        LinkedListNode newHd = newHead;
        while(newHd != null){
            System.out.println(" new head "+newHd.data);
            if(newHd.arbitrary_pointer != null){
                // this is super confusing step map is currently <oldNode, newNode>
                // since in above step our new node' arb points to old nodes arb i.e v1.arb = k3
                // our goal is to now point v1.arb=v3
                // this v1 points to k3(the key) not v3(the value) when we do map.get(k3)
                // we actually get v3, and then we do newHead.arb = node; so v1.arb = v3
                /*    k1, v1(d=1, n=v2, arb=k3)
                      k2, v2
                      k3, v3
                // */
                LinkedListNode node = map.get(newHd.arbitrary_pointer);
                newHd.arbitrary_pointer = node;
            }
            newHd = newHd.next;
        }
        return newHead;
    }
    public static void main(String args[]){
        LinkedListNode node3 = new LinkedListNode(
                3, null, null);
        node3.hack = 15;
        LinkedListNode node2 = new LinkedListNode(
                2, node3, null);
        LinkedListNode node1 = new LinkedListNode(
                1, node2, node3);
        LinkedListNode list_head = new LinkedListNode(
                0, node1, node2);
        LinkedListNode list_head_2 =
                deepCopy(list_head);
        System.out.print("Original:\n ");
        while (list_head != null) {
            System.out.println(list_head + "  " + list_head.data + " list_head " + list_head.data + " arb " + list_head.arbitrary_pointer + " .. " + (list_head.arbitrary_pointer != null ? list_head.arbitrary_pointer.hack : -1));
            list_head = list_head.next;
        }
        System.out.print("Copied: \n");
        while (list_head_2 != null) {
            System.out.println(list_head_2 + "  " + list_head_2.data + " list_head " + list_head_2.data + " arb " + list_head_2.arbitrary_pointer + " .. " + (list_head_2.arbitrary_pointer != null ? list_head_2.arbitrary_pointer.hack : -1));
            list_head_2 = list_head_2.next;
        }
    }
}
class LinkedListNode{
    int data;
    LinkedListNode next;
    LinkedListNode arbitrary_pointer;
    int hack;
    public LinkedListNode(int data){
        this.data = data;
    }
    public LinkedListNode(int data , LinkedListNode next, LinkedListNode arbitrary_pointer){
        this.data = data;
        this.next = next;
        this.arbitrary_pointer = arbitrary_pointer;
    }
}