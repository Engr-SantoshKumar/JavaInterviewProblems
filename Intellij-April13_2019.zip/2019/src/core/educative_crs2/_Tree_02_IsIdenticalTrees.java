package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 2/26/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_02_IsIdenticalTrees {
    public static void main(String args[]) {
        Node r1 = TreePrint.create(new int[]{6, 4, 8, 2, 5, 7, 9, 1, 3});
        Node r2 = TreePrint.create(new int[]{6, 4, 8, 2, 5, 7, 9, 1, 3});
        Node r3 = TreePrint.create(new int[]{6, 4, 8, 2, 5, 7, 9, 1});
        System.out.println("identical trees "+identical(r1, r2)); // true
        System.out.println("identical trees "+identical(r1, r3)); // false
    }

    static boolean identical(Node root1, Node root2) {
        if (root1 == null && root2 == null) {
            return true;
        }
        if ((root1 == null && root2 != null) || (root1 != null && root2 == null)) {
            return false;
        }
        return root1.data == root2.data && identical(root1.left, root2.left) && identical(root1.right, root2.right);

    }
}
