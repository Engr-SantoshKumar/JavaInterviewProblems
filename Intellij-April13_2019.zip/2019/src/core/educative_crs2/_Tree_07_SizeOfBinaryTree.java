package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Date: 3/1/19
 * Runtime Complexity: o(N),    Space Complexity: o(1)
 * Problem: Find size with using recursion and without recursion
 */
public class _Tree_07_SizeOfBinaryTree {
    public static void main(String args[]) throws Exception{
        Node r = TreePrint.create(new int[]{6, 4, 8, 27, 5, 17, 22});
        System.out.println(size(r));
        System.out.println(sizeUsingBFS(r));
        System.out.println(sizeUsingBFS(null));

    }

    static int size(Node root) {
        if (root == null) {
            return 0;
        }
        return 1 + size(root.left) + size(root.right);
    }

    static int sizeUsingBFS(Node root) throws Exception{
        if(root == null){
            throw new Exception(" invalid input null array .....");
        }

        Queue<Node> q = new ArrayDeque<>();
        q.offer(root);
        int size=0;

        while (!q.isEmpty()){
            Node n = q.poll();
            size++;
            if(n.left!=null){
                q.offer(n.left);
            }
            if(n.right!=null){
                q.offer(n.right);
            }
        }
        return size;
    }
}
