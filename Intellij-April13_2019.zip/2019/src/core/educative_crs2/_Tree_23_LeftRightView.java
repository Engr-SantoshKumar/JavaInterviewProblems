package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/4/19
 *
 *                                 1
 *                 ┌───────────────┴───────────────┐
 *                 2                               3     Ans:  Left view .. 1, 2, 4, 8, 18, 17
 *         ┌───────┴───────┐                                  Right view .. 1, 3, 5, 6, 7, 17
 *         4               5
 *     ┌───┘           ┌───┘
 *     8               6
 *   ┌─┘               └─┐
 *  18                   7
 *                      ┌┘
 *                     17
 *
 *
 * Remember: // mark levels in each call and if this.level is > levelSoFar print,
 * Another way is to use BFS
 */
public class _Tree_23_LeftRightView {
    public static void main(String args[]) {
        Node root = TreePrint.getUnBalancedTree();
        leftView(root, 0);
        levelSoFar = -1;
        System.out.println();
        rightView(root, 0);
    }
    static int levelSoFar = -1;
    static void leftView(Node root, int level){
        if(root == null){
            return;
        }
        if(level>levelSoFar){
            levelSoFar = level;
            System.out.println(" .. "+root.data);
        }
        leftView(root.left, level+1);
        leftView(root.right, level+1);
    }
    static void rightView(Node root, int level){
        if(root == null){
            return;
        }
        if(level>levelSoFar){
            levelSoFar = level;
            System.out.print(", "+root.data);
        }
        rightView(root.right, level+1);
        rightView(root.left, level+1);
    }
}
