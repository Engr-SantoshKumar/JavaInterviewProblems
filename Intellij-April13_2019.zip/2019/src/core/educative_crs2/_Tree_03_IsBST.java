package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 2/26/19
 * Runtime Complexity: o(n),    Space Complexity: o(1)
 * <p>
 * Problem Description: Check if a tree is BST
 * Remember: remember low and up bounds
 */
public class _Tree_03_IsBST {
    public static void main(String[] args) {
        Node r1 = TreePrint.create(new int[]{6, 4, 8, 2, 12, 7, 9, 1, 3});
        int low = Integer.MIN_VALUE;
        int high = Integer.MAX_VALUE;
        System.out.println(isBst(r1, low, high)); // false
        System.out.println(isBstNaiveWrongResult(r1)); // true
    }

    static boolean isBst(Node root, int low, int high) {
        if (root == null) {
            return true;
        }
        return root.data > low && root.data <= high &&
                isBst(root.left, low, root.data) &&
                isBst(root.right, root.data, high);
    }

    // This gives **wrong** solution as we just check condition on current node with no high and
    // low bounds
    static boolean isBstNaiveWrongResult(Node root) {
        if (root == null) {
            return true;
        }
        int left = root.left == null ? Integer.MIN_VALUE : root.left.data;
        int right = root.right == null ? Integer.MAX_VALUE : root.right.data;
        return root.data > left && root.data <= right && isBstNaiveWrongResult(root.left)
                && isBstNaiveWrongResult(root.right);

    }
}
