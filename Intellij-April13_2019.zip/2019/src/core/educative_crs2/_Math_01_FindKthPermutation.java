package core.educative_crs2;

/**
 * Date: 2/25/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
// This question is same as _31_NextPermutation, refer there only thin g is it find next permutation or next
    // bigger number and this needs kth bigger number
public class _Math_01_FindKthPermutation {
}
