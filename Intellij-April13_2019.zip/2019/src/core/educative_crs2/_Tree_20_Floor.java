package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/4/19
                          90
 *             ┌───────────┴───────────┐
 *            50                      150
 *       ┌─────┴─────┐           ┌─────┴─────┐
 *      25          55          120         170
 *    ┌──┴──┐     ┌──┴──┐
 *   20    35    52    60
 */
public class _Tree_20_Floor {
    static int floor = Integer.MIN_VALUE;

    static void floorUsingGlobalVariable(Node root, int key) {
        if (root == null) {
            return;
        }
        if (key >= root.data) {
            floor = Math.max(floor, root.data);
            floorUsingGlobalVariable(root.right, key);
        } else {
            floorUsingGlobalVariable(root.left, key);
        }
    }

    static int floor(Node root, int key) {
        if (root == null) {
            return Integer.MIN_VALUE;
        }
        if (key >= root.data) {
            return Math.max(root.data, floor(root.right, key));
        }
        return floor(root.left, key);
    }

    // This is not preferred but if someone asks...
    static Node floor2(Node root, int key) {
        if (root == null) {
            return null;
        }
        if (key >= root.data) {
            Node x = floor2(root.right, key);
            if (x != null && x.data > root.data) {
                return x;
            }
            return root;
        }
        return floor2(root.left, key);
    }

    public static void main(String args[]) {
        int[] ar = new int[]{90, 50, 150, 25, 55, 120, 170, 20, 35, 52, 60};
        Node root = TreePrint.create(ar);
        floorUsingGlobalVariable(root, 53);
        System.out.println(" floor of 53 : " + floor);// 52
        System.out.println(" floor of 53 using floor method : " + floor(root, 53));
        floorUsingGlobalVariable(root, 53);
        System.out.println(" floor of 52 : " + floor);//52
        System.out.println(" floor of 52 using floor method : " + floor(root, 52));
        System.out.println(" floor of 53 using floor2 method : " + floor2(root, 53).data); //52
    }
}
