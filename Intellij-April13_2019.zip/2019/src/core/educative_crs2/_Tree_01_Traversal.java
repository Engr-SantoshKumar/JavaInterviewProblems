package core.educative_crs2;
import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 2/26/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_01_Traversal {
    public static void main(String args[]){
        Node r = TreePrint.create(new int[]{6,4,8,2,5,7,9,1,3});
        Node r1 = TreePrint.create(new int[]{10,5,20,3,8,15,50,1,4,6,9});
        TreePrint.print(r1);
        System.out.println();
        inOrder(r);
        System.out.println();
        preOrder(r);
        System.out.println();
        postOrder(r);
    }

    static void inOrder(Node root){
        if(root==null){
            return;
        }
        inOrder(root.left);
        System.out.print(", "+root.data);
        inOrder(root.right);
    }

    static void preOrder(Node root){
        if(root==null){
            return;
        }
        System.out.print(", "+root.data);
        preOrder(root.left);
        preOrder(root.right);
    }

    static void postOrder(Node root){
        if(root==null){
            return;
        }
        postOrder(root.left);
        postOrder(root.right);
        System.out.print(", "+root.data);
    }
}
