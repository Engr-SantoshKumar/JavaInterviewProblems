package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/3/19
 * Problem Description: special case of next sibling, ex: 5->7 and 9->8
 * Solution:
 *                 1                     next pointer of 1 is null
 *         ┌───────┴───────┐             next pointer of 2 is 3
 *         2               3             next pointer of 3 is null
 *     ┌───┴───┐           └───┐         next pointer of 4 is 5
 *     4       5               7         next pointer of 5 is 7
 *           ┌─┘               └─┐       next pointer of 9 is 8
 *           9                   8       next pointer of 8 is null
 *
 */
public class _Tree_18_RightNeighbour {
    public static void main(String args[]) {
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.left.right.left = new Node(9);
        root.right.right = new Node(7);
        root.right.right.right = new Node(8);
        Node[] ar = new Node[]{null};
        TreePrint.print(root);
        rightNeighbour(root);
        _Tree_17_NextSibling.printResult(root);
    }

    static void rightNeighbour(Node root) {
        if (root == null) {
            return;
        }
        if (root.left != null) {
            if (root.right != null) {
                root.left.nextSibling = root.right;
            } else {
                setRightNeighbour(root, root.left);
            }
        }
        if (root.right != null) {
            setRightNeighbour(root, root.right);
        }
        rightNeighbour(root.left);
        rightNeighbour(root.right);
    }

    static void setRightNeighbour(Node root, Node child) {
        Node sibling = root.nextSibling;
        while (sibling != null) {
            if (sibling.left != null) {
                child.nextSibling = sibling.left;
                break;
            } else if (sibling.right != null) {
                child.nextSibling = sibling.right;
                break;
            }
            sibling = sibling.nextSibling;
        }
    }
}
