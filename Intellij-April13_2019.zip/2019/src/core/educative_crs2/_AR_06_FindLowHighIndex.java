package core.educative_crs2;

import java.util.Arrays;
import java.util.HashSet;

//https://www.educative.io/collection/page/5642554087309312/5679846214598656/130003
/*Given a sorted array of integers, return the low and high index of the given key. Return -1 if not found. The array length can be in millions with lots of duplicates.*/

public class _AR_06_FindLowHighIndex {
	static HashSet<Integer> set = new HashSet<>();

	// This solution is from mycodeSchool
	// https://www.youtube.com/watch?v=OE7wUUpJw6I&list=PL2_aWCzGMAwL3ldWlrii6YeLszojgH77j&index=4
	// full BinarySearch series
	// https://www.youtube.com/playlist?list=PL2_aWCzGMAwL3ldWlrii6YeLszojgH77j
	static void findLoHiIdx(Integer[] ar, Integer key) {
		int lo = 0;
		int hi = ar.length - 1;
		int loIdx = -1;
		while (lo <= hi) {
			int mid = (lo + hi) / 2;
			System.out.println(" lo is " + lo + " hi " + hi + " mid is " + mid);
			if (ar[mid] > key) {
				hi = mid - 1;
			} else if (ar[mid] < key) {
				lo = mid + 1;
			} else if (ar[mid] == key) {
				loIdx = mid;// we got a temp result but will keep finding on left
				hi = mid - 1;
			}
		}
		System.out.println(" now hi becomes " + hi + " lo is " + lo + " lo index is " + loIdx);

	}

	// This solution is from mycodeSchool
	static void findHiIdx(Integer[] ar, Integer key) {
		int lo = 0;
		int hi = ar.length - 1;
		int hiIdx = -1;
		while (lo <= hi) {
			int mid = (lo + hi) / 2;
			System.out.println(" lo is " + lo + " hi " + hi + " mid is " + mid);
			if (ar[mid] > key) {
				hi = mid - 1;
			} else if (ar[mid] < key) {
				lo = mid + 1;
			} else if (ar[mid] == key) {
				hiIdx = mid;// we got a temp result but will keep finding on left
				lo = mid + 1;
			}
		}
		System.out.println(" now hi becomes " + hi + " lo is " + lo + " lo index is " + hiIdx);

	}

	public static void main(String[] args) {
		Integer[] ar = new Integer[] { 1, 2, 3, 3, 4, 5, 5, 5, 5, 5, 20, 20, 21 , 21, 22 };
		for(int i=0;i<ar.length ; i++) {
			System.out.print(","+ar[i]+"["+i+"]");
		}
		set.addAll(Arrays.asList(ar));
		for(Integer a : set) {
			System.out.println(" find for "+a+" .. ");
			findLoHiIdx(ar, a);
		}
		System.out.println(" find for "+25+" .. ");
		//System.out.println(find_low_index(ar, 21));
		findHiIdx(ar, 21);
	}
	
	/// I designed this first, but too verbose
	static void findLoHiIdx1(Integer[] ar, Integer key) {
		int lo = 0;
		int hi = ar.length - 1;
		int loIdx = -1;
		while (lo <= hi) {
			int mid = (lo + hi) / 2;
			System.out.println(" lo is " + lo + " hi " + hi + " mid is " + mid);
			if (ar[mid] > key) {
				hi = mid - 1;
			} else if (ar[mid] < key) {
				lo = mid + 1;
			} else if (ar[mid] == key) {
				if (mid == lo) {// in case of first element of array is key
					loIdx = lo;
					break;
				} else if (ar[mid] > ar[mid - 1]) {
					loIdx = mid;
					break;
				} else {
					hi = mid - 1;
				}
			}
		}
		System.out.println(" now hi becomes " + hi + " lo is " + lo + " lo index is " + loIdx);

	}

	static void findLoHiIndex(Integer[] ar, Integer key) {
		int lo = 0;
		int hi = ar.length - 1;
		int loIdx = -1;
		// find lower bound
		while (lo <= hi) {
			int mid = (lo + hi) / 2;
			// System.out.println(" lo "+lo+" mid "+mid +" hi "+hi);
			if (mid == 0 && ar[mid] == key) {
				loIdx = 0;
				break;
			} else if (mid > 0 && ar[mid] == key && ar[mid - 1] != key) {
				loIdx = mid;
				// System.out.println(" in ideal ");
				break;
				// return loInd;
			} else if (ar[mid] < key) {
				lo = mid + 1;
			} else {
				hi = mid - 1;
			}
		}
		System.out.println(" low index calculate as " + loIdx);
		int hiIdx = -1;
		lo = 0;
		hi = ar.length - 1;
		int count = 0;
		// find higher bound
		while (lo <= hi) {
			int mid = (lo + hi) / 2;
			// System.out.println(" lo.. "+lo+" mid "+mid +" hi "+hi);
			// System.out.println(" lo.. "+ar[lo]+" mid "+ar[mid] +" hi "+ar[hi]);
			// handle this as when lo = second last hi = last mid is cal as second last
			// this is an infinite loop condition ex lo=8 hi=9 mid=8
			if (ar[hi] == key) {
				hiIdx = hi;
				break;
			}
			if (mid == ar.length - 1 && ar[mid] == key) {
				hiIdx = ar.length - 1;
				break;
			} else if (mid <= ar.length - 2 && ar[mid] == key && ar[mid + 1] != key) {
				hiIdx = mid;
				// System.out.println(" in ideal "+hiIdx);
				break;
				// return loInd;
			} else if (ar[mid] > key) {
				// System.out.println(" hi to mid "+mid);
				hi = mid - 1;
			} else {
				// System.out.println(" increasinglo to mid "+mid);
				lo = mid + 1;
			}
		}
		System.out.println(" hi index calculate as " + hiIdx);
	}
	
}