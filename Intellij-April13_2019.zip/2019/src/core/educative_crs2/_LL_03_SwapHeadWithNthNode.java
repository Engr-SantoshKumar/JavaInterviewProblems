package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

public class _LL_03_SwapHeadWithNthNode {
	public static void main(String[] args) throws InterruptedException {
		MyLinkedList ll = new MyLinkedList();
		ll.addFirst(11);
		ll.addFirst(82);
		ll.addFirst(23);
		ll.addFirst(29);
		ll.addFirst(100);
		ll.addFirst(12);
		ll.addFirst(82);
		ll.iterate(ll.getFirst());// 82->12->100->29->23->82->11->
		
		Node t = swap(ll, 3);
		ll.iterate(t);
	}

	static Node swap(MyLinkedList ll, int n) {
		// find one elem before what to swap, swap 29 find 100
		Node beforeSwapNode = findxthNode(ll, n-1);
		Node head = ll.getFirst();
		
		Node headNext = head.next;
		Node temp = beforeSwapNode.next;
		Node nextToNext = temp.next;
		beforeSwapNode.next = head;
		head.next = nextToNext;
		head = temp;
		temp.next = headNext;
		return temp;
	}
	static Node findxthNode(MyLinkedList ll, int n) {
		Node head = ll.getFirst();
		Node temp = head;
		while(--n>0) {
			temp = temp.next;
		}
		return temp;
	}

}
