package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/2/19
 * Problem Description:  Greater sum tree is a tree in which every node contains the sum of all
 * the nodes which are greater than the node.
 * Remember: Global variable sum, it is very easy this way
 */
public class _Tree_12_GreaterSumTree {
    static int sum = 0;

    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{10, 5, 15, 2, 7, 12, 20});
        greaterSum(r);
        TreePrint.print(r);
    }

    static void greaterSum(Node root) {
        if (root == null) {
            return;
        }
        greaterSum(root.right);
        int temp = root.data;
        root.data = sum;
        sum += temp;
        greaterSum(root.left);
    }
}
