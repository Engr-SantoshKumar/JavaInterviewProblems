package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/2/19
 * Problem Description:Sum tree of a binary tree, is a tree where each node in the converted tree
 * will contains the sum of the left and right sub trees in the original tree.
 * Solution:
 * Remember:
 */
public class _Tree_11_SumTree {

    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{5, -1, 3, -2, 4, -6, 10});
        sum(r);
        TreePrint.print(r);
    }

    static int sum(Node root) {
        if (root == null) {
            return 0;
        }
        int l = sum(root.left);
        int r = sum(root.right);
        int temp = root.data;
        root.data = l + r;
        return temp + l + r;
    }
}
