package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

public class _LL_02_IntersectionPointOf2Lists {
	public static void main(String[] args) throws InterruptedException {
		MyLinkedList ll = new MyLinkedList();
		ll.addFirst(11);
		ll.addFirst(82);
		ll.addFirst(23);
		ll.addFirst(29);
		ll.addFirst(100);
		ll.addFirst(12);
		ll.addFirst(82);

		MyLinkedList ll2 = new MyLinkedList();
		ll2.addFirst(11);
		ll2.addFirst(82);
		ll2.addFirst(23);
		ll2.addFirst(13);
		ll2.addFirst(102);
		ll2.addFirst(25);
		ll2.addFirst(27);

		ll.iterate(ll.getFirst());// 82->12->100->29->23->82->11->
		ll.iterate(ll2.getFirst());// 27->25->102->13->23->82->11->

		Node intersection = intersectionNode(ll, ll2);
		System.out.println(" inter " + intersection.data);
		Node intersection2 = intersectionNode(null, null);
		System.out.println(" inter " + intersection);

		// Below will fail because this question requires that both
		// LLS will be same after intersection point to LL2 should be
		// 23->82->11
		MyLinkedList ll3 = new MyLinkedList();
		ll3.addFirst(23);
		Node intersection3 = intersectionNode(ll, ll3);
		System.out.println(" inter " + intersection3);
	}

	static Node intersectionNode(MyLinkedList ll1, MyLinkedList ll2) {
		if (ll1 == null || ll2 == null) {
			return null;
		}
		Node head1 = ll1.getFirst();
		Node head2 = ll2.getFirst();
		if (head1 == null || head2 == null) {
			return null;
		}
		advanceLarger(ll1, ll2);
		while (head1 != null && head2 != null) {
			if (head1.data == head2.data) {
				return head1;
			}
			head1 = head1.next;
			head2 = head2.next;
		}
		return null;
	}

	static int findLength(MyLinkedList ll) {
		Node head = ll.getFirst();
		if (head == null) {
			return 0;
		}
		int length = 0;
		while (head != null) {
			length++;
			head = head.next;
		}
		return length;
	}

	static void advanceLarger(MyLinkedList ll1, MyLinkedList ll2) {
		int length1 = findLength(ll1);
		int length2 = findLength(ll2);
		Node head1 = ll1.getFirst();
		Node head2 = ll2.getFirst();
		if (length1 > length2) {
			int diff = length1 - length2;
			while (diff != 0) {
				head1 = head1.next;
				diff--;
			}
		} else if (length2 > length1) {
			int diff = length2 - length1;
			while (diff != 0) {
				head2 = head2.next;
				diff--;
			}
		}
	}
}
