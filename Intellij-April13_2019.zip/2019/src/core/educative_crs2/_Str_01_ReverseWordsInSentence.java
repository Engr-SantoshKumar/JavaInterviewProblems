package core.educative_crs2;

import java.util.StringTokenizer;

/**
 * Date: 2/26/19
 * Problem Description:Reverse the order of words in a given sentence. Here are a few examples:
 * "Hello World" -> "World Hello"
 * "The quick brown fox jumped over the lazy dog." -> "dog. lazy the over jumped fox brown quick The"
 * Solution: first reverse every word, then reverse full sentence
 * Remember:
 */
public class _Str_01_ReverseWordsInSentence {
    public static void main(String args[]) {
        String sentence = "The quick brown fox jumped over the lazy dog.";
        // missing number
        System.out.println(reverseSentence(sentence));
        assert (reverseSentence(sentence).contentEquals("dog. lazy the over jumped fox brown quick The"));
        sentence = "Hello World";
        System.out.println(reverseSentence(sentence));
    }

    static String reverseSentence(String sentence) {
        StringTokenizer st = new StringTokenizer(sentence, " ");
        StringBuilder sb = new StringBuilder();
        // reverse every word
        while (st.hasMoreElements()) {
            String token = st.nextToken(); // st.nextElement() returns Object hence you need cast
            sb.append(reverse(token)).append(" ");
        }
        // reverse the full sentence
        String result = reverse(sb.toString());
        return result;
    }

    static String reverse(String sequence) {
        char[] ar = sequence.toCharArray();
        int i = 0;
        int j = ar.length - 1;
        while (i < j) {
            char temp = ar[i];
            ar[i] = ar[j];
            ar[j] = temp;
            i++;
            j--;
        }
        return new String(ar);
    }
}
