package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayList;

/**
 * Date: 3/2/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_14_SumOfAllLeftLeaves {
    static int sum = 0;
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{1, 2, 3, 7, 5, 6, 7});
        llSum(r, false);
        System.out.println(sum);
        System.out.println(llSum2(r, false));
    }
    static void llSum(Node root, boolean isLeft){
        if(root == null){return;}
        if(isLeft && root.left == null && root.right == null){
            sum += root.data;
        }
        llSum(root.left, true);
        llSum(root.right, false);
    }

    static int llSum2(Node root, boolean isLeft){
        if(root == null){return 0;}
        if(isLeft && root.left == null && root.right == null){
            return root.data;
        }
        int l = llSum2(root.left, true);
        int r = llSum2(root.right, false);
        return l+r;
    }
}
