package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 3/2/19
 * Problem Description: https://algorithms.tutorialhorizon.com/print-paths-in-binary-tree-with-sumx/
 * Given a binary tree and X, write an algorithm to Print all the paths starting from root so
 * that sum of all the nodes in path equals to a given number.
 * Remember:
 */
public class _Tree_13_All_PathWithSUm {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{1, 2, 3, 7, 5, 6, 7});
        printP(r, 10, new ArrayList<Integer>() , 0);
    }

    static void printP(Node root, int target, List<Integer> path, int index) {
        if (root == null) {
            return;
        }
        path.add(index, root.data);
        if (target - root.data == 0) {
            System.out.println(Arrays.toString(path.toArray()));
            path.remove(index);// this is important**
            return; // return is imp**
        }
        printP(root.left, target - root.data, path, index + 1);
        printP(root.right, target - root.data, path, index + 1);
        path.remove(index);
    }
}
