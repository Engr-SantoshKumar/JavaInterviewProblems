package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 2/23/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description: rotate a ll by given places
 * Solution:
 * Remember:
 */
// MINOR tweak is required to make this working ** dont rely on the _LL_01_NthFromLast
    // just try this: find n-1th from last node and make connections

public class _LL_08_RotateLL {
    public static void main(String args[]){
        testFor(new int[]{11, 12, 13, 14, 15}, 0); //11
        testFor(new int[]{11, 12, 13, 14, 15}, 1); //12
        testFor(new int[]{11, 12, 13, 14, 15}, 2); //13
        testFor(new int[]{11, 12, 13, 14, 15}, 7); //13 // 7-5=2 //13
        testFor(new int[]{11, 12, 13, 14, 15}, -1); //5-1=>4 => 12   // A
        testFor(new int[]{11, 12, 13, 14, 15}, -2); //5-2=>3 => 13   //B
        testFor(new int[]{11, 12, 13, 14, 15}, -3); //5-3=>4 => 14
        testFor(new int[]{11, 12, 13, 14, 15}, -4); //5-4=>4 => 15
        testFor(new int[]{11, 12, 13, 14, 15}, -5); //5-5=>0 => 11
        testFor(new int[]{11, 12, 13, 14, 15}, -6); //5-6=>5+(-6%5) => 5-1=>4 //eq A   12
        testFor(new int[]{11, 12, 13, 14, 15}, -7); //5-7=>5+(-7%5) => 3 // eq B       13
        testFor(new int[]{11, 12, 13, 14, 15}, -11); //5-11=>5-11%5 =>-1 // eq A 12
    }

    static Node rotate(Node head, int n, MyLinkedList ll){
        Node originalHead = head;
        // used n-1 to get prev node of rotation point
        Node node = _LL_01_NthFromlast.nthFromLastNode(head, n-1, ll);
        Node temp = node.next; // temp now points to rotation point
        Node newHead = temp;   // return this newHead at end
        System.out.println(" rotation befor "+node.data+ " temp "+temp.data);
        node.next = null;      // break from before rotation point
        // find last of this list
        while(temp!= null && temp.next!=null){
            temp = temp.next;
        }
        System.out.println(" end of list "+temp.data);
        temp.next = originalHead; // add the last of this list to start of list

        return newHead;
    }
    static void testFor(int[] ar, int n){
        if(ar==null || ar.length<1){
            System.out.println(" invalid input ");
            return;
        }
        MyLinkedList ll = new MyLinkedList();
        ll.add(ar);
        System.out.println("----\n"+"rotate arr by "+n);
        MyLinkedList.iterate(ll.getFirst());
        Node i = rotate(ll.getFirst(), n, ll);
        MyLinkedList.iterate(i);
        //System.out.println(" o/p : "+i.data);
    }
}
