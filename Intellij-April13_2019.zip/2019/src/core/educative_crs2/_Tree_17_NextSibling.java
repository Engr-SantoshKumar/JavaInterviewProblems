package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayDeque;

/**
 * Date: 3/3/19
 * Problem Description: Given a binary tree with three pointers left, right and nextSibling).
 * Write the program to provide the nextsibling pointers.
                              1               next pointer of 1 is null
                          ┌───┴───┐           next pointer of 2 is 3
                          2       3           next pointer of 3 is null
                        ┌─┴─┐   ┌─┴─┐         next pointer of 7 is 5
                        7   5   6   7         next pointer of 6 is 7
                                              next pointer of 7 is null
 */
public class _Tree_17_NextSibling {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{1, 2, 3, 7, 5, 6, 7});
        nextSibling(r);
        printResult(r);
    }

    static void nextSibling(Node root) {
        if (root == null) {
            return;
        }
        if (root.left != null) {
            root.left.nextSibling = root.right;
        }
        if (root.right != null && root.nextSibling != null) {
            root.right.nextSibling = root.nextSibling.left;
        }
        nextSibling(root.left);
        nextSibling(root.right);
    }

    static void printResult(Node root) {
        ArrayDeque<Node> st = new ArrayDeque<>();
        st.push(root);
        while (!st.isEmpty()) {
            Node t = st.pop();
            System.out.println(" next pointer of " + t.data + " is " + (t.nextSibling != null ?
                    t.nextSibling.data : null));
            if (t.left != null)
                st.push(t.left);
            if (t.right != null)
                st.push(t.right);
        }
    }
}
