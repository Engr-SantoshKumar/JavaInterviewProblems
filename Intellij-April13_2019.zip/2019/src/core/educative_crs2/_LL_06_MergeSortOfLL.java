package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 2/23/19
 * Runtime Complexity: o(n),    Space Complexity: o(1)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _LL_06_MergeSortOfLL {
    public static void main(String args[]){
        testMergeFor(new int[]{9,0,3,4,5,6,7,8,1}); // odd # of elems
        testMergeFor(new int[]{9,0,3,4,5,6,7,8}); // even # of elems
        testMergeFor(new int[]{9,0}); // 2 elems
        testMergeFor(new int[]{9}); // 1 elem
        testMergeFor(new int[]{}); // 0 elem
        testMergeFor(null); // null
    }

    static Node merge(Node head){
        if(head == null || head.next == null){
            return head;
        }
        Node mid = findMid(head);
        Node tempMid = mid.next;
        mid.next = null; // this is important to break the connection, now we have 2 lists to merge
        Node h1 = merge(head);
        Node h2 = merge(tempMid);
        Node head1 = _LL_04_Merge2SortedLists.mergeSortedListsWithGivenHeads(h1, h2);
        return head1;
    }
    static Node findMid(Node st){
        Node slow = st;
        Node fast = st;
        while(fast.next != null && fast.next.next!=null){ // imp to use next.next as when we have 1,2 we want o/p as 1
            slow = slow.next;
            fast = fast.next.next;
        }
        return slow;
    }

    static void testMergeFor(int[] ar){
        if(ar==null || ar.length<1){
            System.out.println(" invalid input ");
            return;
        }
        MyLinkedList ll = new MyLinkedList();
        ll.add(ar);
        MyLinkedList.iterate(ll.getFirst());
        Node head = merge(ll.getFirst());
        MyLinkedList.iterate(head);
    }
}
