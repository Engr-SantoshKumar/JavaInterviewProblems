package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/1/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_05_IsMirrorTree {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{6, 4, 8, 2, 5, 7, 9});
        Node r1 = TreePrint.create(new int[]{6, 8, 4, 9, 7, 5, 2});
        System.out.println(isMirror(r, r1));
    }

    static boolean isMirror(Node n1, Node n2) {
        if (n1 == null && n2 == null) {
            return true;
        }

        if (n1 == null && n2 != null || (n1 != null && n2 == null)) {
            return false;
        }
        return (n1.data == n2.data) && isMirror(n1.left, n2.right) && isMirror(n1.right, n2.left);
    }
}
