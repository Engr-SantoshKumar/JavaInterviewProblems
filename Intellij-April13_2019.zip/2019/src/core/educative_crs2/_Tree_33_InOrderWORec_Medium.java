package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayDeque;

/**
 * Date: 3/6/19
 * Solution: push root on stack and first time push all its lefts to stack
 * pop a node and push its right to stack, then push all the lefts of this node to stack
 *  *                 6
 *  *         ┌───────┴───────┐         // Ans : 1, 2, 3, 4, 5, 6, 7, 8, 9
 *  *         4               8
 *  *     ┌───┴───┐       ┌───┴───┐
 *  *     2       5       7       9
 *  *   ┌─┴─┐
 *  *   1   3
 */
public class _Tree_33_InOrderWORec_Medium {
    public static void main(String args[]){
        Node root = TreePrint.create(new int[]{6,4,8,2,5,7,9,1,3});
        inOrder(root);
    }
    static void inOrder(Node root){
        ArrayDeque<Node> st = new ArrayDeque<>();

        st.push(root);
        while(root.left!=null){
            st.push(root.left);
            root = root.left;
        }
        while(root!=null && !st.isEmpty()){
            Node temp = st.pop();   // pop the node then push its right and all its left to st
            if(temp.right != null){
                Node next = temp.right;
                st.push(temp.right); // push the right to stack
                while(next.left!=null){ // push all the lefts to the stack of this node
                    st.push(next.left);
                    next = next.left;
                }
            }
            System.out.print(", "+temp.data);
        }
    }
}
