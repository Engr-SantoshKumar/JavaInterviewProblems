package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 3/1/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_10_PrintRootToLeafPath {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{6, 4, 8, 27, 5, 17, 22, 25, 1,2 ,3,9,10,6, 4, 8, 27,
                5, 17, 22, 25, 1,2 ,3,9,10,6, 4, 8, 27, 5, 17, 22, 25, 1,2 ,3,9,10,6, 4, 8, 27, 5, 17, 22, 25, 1,2 ,3,9,10});
        print(r, "");
        List<Integer> list = new ArrayList<>();
        print2(r, list, 0);
        print3(r, new StringBuilder());
    }
    // not good because we create so many string objects
    static void print(Node root, String path) {
        if (root == null) {
            return;
        }
        path += ", " + root.data;
        if (root.left == null && root.right == null) {
            System.out.println(" ... " + path);
        }
        print(root.left, path);
        print(root.right, path);
    }

    // not good because we create so many string objects
    static void print3(Node root, StringBuilder path) {
        if (root == null) {
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append(path).append(root.data).append(", ");
        if (root.left == null && root.right == null) {
            System.out.println(" **** " + sb);
            return; // we should always return from meeting condition so no s
        }
        print3(root.left, sb );
        print3(root.right, sb );
    }

    // Better way because we remove the element after done with L and R subtree of a node
    static void print2(Node root, List<Integer> path, int index) {
        if (root == null) {
            return;
        }
        path.add(index, root.data); // we add at index and will remove elem from this index
        if (root.left == null && root.right == null) {
            System.out.println(" ### " + Arrays.toString(path.toArray()));
            path.remove(index);// this is the key
            return;
            // if the return stmt is not here then for leaf node it again goes in l/r null nodes
            // post that it tries to remove again (index) which creates ArIndxOO error.
        }
        print2(root.left, path, index+1);
        print2(root.right, path, index+1);
        path.remove(index); // this is the key, remember we remove from index,
        // A know bug** path.remove(root.data) -- which will be wrong and yield ArrayIndexOO error
    }
}
