package core.educative_crs2; /**
 * Date: 02/22/2019
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 * Lable:G
 */
import core.MyLinkedList;
import core.Node;
public class _LL_05_ReverseInPairs {
    public static void main(String args[]){
        MyLinkedList ll = new MyLinkedList();
        ll.add(new int[]{1,2,3,4,5,6,7,8});
        System.out.println(" rev in k");
        MyLinkedList.iterate(ll.getFirst());
        //1->2->3->4->5->6->7->
        //2->1->4->3->6->5->8->7->
        MyLinkedList.iterate(reverseINPairsRec(ll.getFirst()));
    }

    static Node reverseINPairsRec(Node head) {
        if(head==null) {  // both base case could be combined to say
            return null; // if(head ==null || head.next == null) return head;
        }                 // but for clarity we are not doing that
        if(head.next == null) { // This is important because when we have only one elem
            return head;         // in this case 7 then call should return 7
        }
        Node temp = head.next.next;
        Node newHead = head.next;
        newHead.next = head;
        head.next = reverseINPairsRec(temp);
        return  newHead;
    }
}
