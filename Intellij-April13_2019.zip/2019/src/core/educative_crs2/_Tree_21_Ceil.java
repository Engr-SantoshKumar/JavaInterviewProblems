package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/4/19
 *                    90
 *             ┌───────────┴───────────┐
 *            50                      150
 *       ┌─────┴─────┐           ┌─────┴─────┐
 *      25          55          120         170
 *    ┌──┴──┐     ┌──┴──┐
 *   20    35    52    60
 */
public class _Tree_21_Ceil {
    static int ceil = Integer.MAX_VALUE;

    static void ceilUsingGlobalVariable(Node root, int key) {
        if (root == null) {
            return;
        }
        if (key <= root.data) {
            ceil = Math.min(ceil, root.data);
            ceilUsingGlobalVariable(root.left, key);
        } else {
            ceilUsingGlobalVariable(root.right, key);
        }
    }

    static int ceil(Node root, int key) {
        if (root == null) {
            return Integer.MAX_VALUE;
        }
        if (key <= root.data) {
            return Math.min(root.data, ceil(root.left, key));
        }
        return ceil(root.right, key);
    }

    public static void main(String args[]) {
        int[] ar = new int[]{90, 50, 150, 25, 55, 120, 170, 20, 35, 52, 60};
        Node root = TreePrint.create(ar);
        ceilUsingGlobalVariable(root, 53);
        System.out.println(" ceil of 53 : " + ceil);//  55
        System.out.println(" ceil of 53 using ceil method : " + ceil(root, 53));
        ceilUsingGlobalVariable(root, 53);
        System.out.println(" ceil of 52 : " + ceil); //52
        System.out.println(" ceil of 52 using ceil method : " + ceil(root, 52));
        System.out.println(" ceil of 171 using ceil method : " + ceil(root, 171)); //Max_value

    }
}
