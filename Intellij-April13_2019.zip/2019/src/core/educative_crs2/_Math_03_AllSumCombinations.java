package core.educative_crs2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 2/25/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:Given a positive integer, print all possible sum combinations using positive integers.
 * For example, if we are given input '5', these are the possible sum combinations.
 *          [1, 1, 1, 1]
 *          [1, 1, 2]
 *          [1, 3]
 *          [2, 2]
 *          [4]
 * Remember: pay nextSibling attention to the for loop we do i=start and i<target, this brings unique results
 */
public class _Math_03_AllSumCombinations {
    public static void main(String args[]) {
        permute(1, 4, new ArrayList<>());
        permute(1, 6, new ArrayList<>());
    }

    static void permute(int start, int target, List<Integer> result) {
        if (target == 0) {
            // output
            System.out.println(Arrays.toString(result.toArray()));
            return;
        }
        // TO AVOID DUPLICATE RESULTS WE DID,  i=start and i<target ***imp
        for (int i = start; i <= target; i++) {
            int removedItem = i;//= list.get(i);
            if (target - removedItem < 0) {
                //System.out.println("continue");
                continue;
            }
            List<Integer> newResult = new ArrayList<>();
            newResult.addAll(result);
            newResult.add(removedItem);
            permute(i, target - removedItem, newResult);
        }
    }

}
