package core.educative_crs2;

/**
 * Date: 2/25/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description: Divide two integers without using '/' (division) or '*' (multiplication) operators.
 * Solution:
 * Remember:
 */
public class _Math_02_IntegerDivision {
    public static void main(String args[]) {
        testFor(7, 2 );
        testFor(40, 5 );
        testFor(43, 5 );
        testFor(46, 5);
        testFor(-6, 5);
        testFor(1, 0);
        testFor(0, 1);
    }

    static int divide(int divident, int divisor) {
        if(divisor == 0 ){
           // Divide By zero error
           return 0;
        }
        if (divisor > divident) {
            return 0;
        }
        if (divisor == divident) {
            return 1;
        }
        int times = 1;
        int target = divisor; // lets start target from divisor
        // multiply divisor * 2 (<<1) as many times to reach the divident
        while (target <= divident) {
            target = target << 1; // multiply by 2
            times = times << 1; // how many times we did divisor*2
        }

        if (target == divident) {
            return times;
        } else if (target > divident) { // if t>div we would have multiplied by 2 one extra time
            times = times >> 1;         // so now divide times/2 and divisor/2
            target = target >> 1 ;    // ex: t=80 divisor=5, div=40 then times calculated is 16 so 80/2=40, 16/2 = 8
        }
        return times + divide(Math.abs(target - divident), divisor);//Math.abs bcoz if divisor=46 't' is calc as 80 ini
        //tially so t/2=> 40 and times 16/2 = 8 now t<divisor so we send 6 and not -6 for next function call
    }

    static void testFor(int divident, int divisor){
        System.out.println(" "+divident +"/"+ divisor +" = "+divide(divident, divisor));
    }
}
