package core.educative_crs2;

/**
 * Date: 2/26/19
 * Problem Description:  You are given an array of positive numbers from 1 to n,
 * such that all numbers from 1 to n are present except one number 'x'. We have to find 'x'.
 * The input array is not sorted.
 * For example, let's look at the below array. {3, 7 ,1, 2, 8, 4, 5 } , missing number is 6
 * <p>
 * Solution: n(n+1)/2
 */
public class _Math_04_FindMissingNumber {
    public static void main(String args[]) {
        int[] ar = new int[]{3, 7, 1, 2, 8, 4, 5};
        // missing number
        System.out.println(missingNumber(ar, 8));// 6
    }

    static int missingNumber(int[] ar, int n) {
        int actualSum = 0;
        for (int elem : ar) {
            actualSum += elem;
        }
        int expectedSum = n * (n + 1) / 2;
        return expectedSum - actualSum;
    }
}
