package core.educative_crs2;

public class _AR_03_FindSmallestCommonNumber {
	public static void main(String[] args) {
		int[]  ar1 = new int[] {1, 4, 6, 7, 8, 10, 14};
		int[]  ar2 = new int[] {-1, 4, 5, 6, 7, 8, 50};
		int[]  ar3 = new int[] {0, 6, 7, 8, 10, 25, 30, 40};
		int t = leastCommonNumber.find_least_common_number(ar1, ar2, ar3);
		System.out.println(t);
	}
}

class leastCommonNumber {
	static Integer find_least_common_number(int[] arr1, int[] arr2, int[] arr3) {
		// TODO: Write - Your - Code
		if (arr1.length < 1 || arr2.length < 1 || arr3.length < 1) {
			return Integer.MAX_VALUE;
		}

		int p1 = 0;
		int p2 = 0;
		int p3 = 0;
		while (p1 < arr1.length && p2 < arr2.length && p3 < arr3.length) {
			if (arr1[p1] == arr2[p2] && arr1[p1] == arr3[p3]) {
				return arr1[p1];
			}
			// the <= is very imp, first i did just < which leads to infinte loop
			if(arr1[p1] <= arr2[p2] && arr1[p1] <= arr3[p3]) {
				p1++;
			}else if(arr2[p2] <= arr1[p1] && arr2[p2] <= arr3[p3]) {
				p2++;
			}else if(arr3[p3] <= arr1[p1] && arr3[p3] <= arr2[p2] ) {
				p3++;
			}
		}
		return Integer.MAX_VALUE; // Replace with actual smallest common value
	}
}