package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.HashMap;
import java.util.Map;

/**
 * Date: 3/4/19
 *  Remember: Use HashMap and "colums "+1 going right and -1 going left
 *                            1
 *  *                     ┌───┴─────────┐
 *  *                     2             3     Ans:  Bottom view .. 7, 17, 4, 3, 8, 18,
 *  *                ┌────┴───┐
 *  *               4         5
 *  *           ┌───┘     ┌───┘
 *  *           8         6
 *  *        ┌─┘          └───┐
 *  *       18                7
 *  *                     ┌───┘
 *  *                     17
 *  //////////////////////////////////////////////////////
 *  what if 2 nodes at same level
 *                 2                     // in this either one of 99 or 6 should come
 *         ┌───────┴───────┐             // even they are at same level we consider them
 *         4               5              // overlapping
 *     ┌───┴───┐       ┌───┘
 *     8      99       6
 */
public class _Tree_25_BottomView {
    static Map<Integer, Integer[]> map = new HashMap<>();
    public static void main(String args[]) {
        Node root = TreePrint.getUnBalancedTree();
        root.left.left.right=new Node(99);
        TreePrint.print(root);
        bottomView(root, 0, 0);
        for(Map.Entry<Integer, Integer[]> entry : map.entrySet()){
            System.out.print(", "+entry.getValue()[1]);
        }
    }

    static void bottomView(Node root, int col, int level) {
        if (root == null) {
            return;
        }
        if(map.containsKey(col)){
            if(map.get(col)[0] < level){
                map.put(col, new Integer[]{level, root.data}); // or use a pair object
            }
        }else{
            map.put(col, new Integer[]{level, root.data});
        }
        bottomView(root.left, col - 1, level+1);
        bottomView(root.right, col + 1, level +1);
    }
}
