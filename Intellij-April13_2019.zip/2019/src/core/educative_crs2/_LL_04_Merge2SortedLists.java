package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

public class _LL_04_Merge2SortedLists {
	public static void main(String[] args) throws InterruptedException {
		MyLinkedList ll = new MyLinkedList();
		ll.add(4);
		ll.add(8);
		ll.add(15);
		ll.add(19);
		MyLinkedList ll2 = new MyLinkedList();
		ll2.add(7);
		ll2.add(9);
		ll2.add(10);
		ll2.add(16);

		ll.iterate(ll.getFirst());//4->8->15->19->
		ll.iterate(ll2.getFirst());//7->9->10->16->
		//ll.iterate(mergeSortedListsOneElemAtATime(ll, ll2));
		ll.iterate(mergeSortedLists(ll, ll2));
	}

	static Node mergeSortedLists(MyLinkedList ll1, MyLinkedList ll2) {
		if (ll1 == null || ll2 == null) {
			return null;
		}
		Node head1 = ll1.getFirst();
		Node head2 = ll2.getFirst();
		if (head1 == null || head2 == null) {
			return null;
		}
		Node newHead = null;
	    if(head1 != null && head2 != null ) {
	    	if (head1.data <= head2.data) {
	    		newHead = head1;
	    	}else {
	    		newHead = head2;
	    	}
	    }
	    while (head1 != null && head2 != null) {
				Node prevHead = null;
				while (head1!=null && head2!=null && head1.data <= head2.data) {
					prevHead = head1;
					head1 = head1.next;
				}
				if(prevHead != null) {
					prevHead.next = head2;
				}
			
				prevHead = null;
				while (head1!=null && head2!=null && head2.data <= head1.data) {
					prevHead = head2;
					head2 = head2.next;
				}
				if(prevHead != null) {
					prevHead.next = head1;
				}
		}
		return newHead;
	}
	static Node mergeSortedListsWithGivenHeads(Node head1, Node head2) {
		if (head1 == null || head2 == null) {
			return null;
		}
		Node newHead = null;
		if(head1 != null && head2 != null ) {
			if (head1.data <= head2.data) {
				newHead = head1;
			}else {
				newHead = head2;
			}
		}
		while (head1 != null && head2 != null) {
			Node prevHead = null;
			while (head1!=null && head2!=null && head1.data <= head2.data) {
				prevHead = head1;
				head1 = head1.next;
			}
			if(prevHead != null) {
				prevHead.next = head2;
			}

			prevHead = null;
			while (head1!=null && head2!=null && head2.data <= head1.data) {
				prevHead = head2;
				head2 = head2.next;
			}
			if(prevHead != null) {
				prevHead.next = head1;
			}
		}
		return newHead;
	}
	// NOT WORKING...
	static Node mergeSortedListsOneElemAtATime(MyLinkedList ll1, MyLinkedList ll2) {
		if (ll1 == null || ll2 == null) {
			return null;
		}
		Node head1 = ll1.getFirst();
		Node head2 = ll2.getFirst();
		if (head1 == null || head2 == null) {
			return null;
		}
		Node newHead = null;
	    if(head1 != null && head2 != null ) {
	    	if (head1.data <= head2.data) {
	    		newHead = head1;
	    	}else {
	    		newHead = head2;
	    	}
	    }
	    while (head1 != null && head2 != null) {
	    	Node prevHead = null;
				if (head1.data <= head2.data) {
					prevHead = head1;
					head1 = head1.next;
					prevHead.next = head2;
					System.out.println("\n1 prv "+prevHead.data+" --> "+(head2!=null?head2.data:null));
					System.out.println("new head1 "+(head1==null?null:head1.data));
					System.out.println("new head2 "+(head2==null?null:head2.data));
					System.out.println();
				}else {
					prevHead = head2;
					head2 = head2.next;
					prevHead.next = head1;
					System.out.println("2 prv "+prevHead.data+" --> "+(head1!=null?head1.data:null));
					System.out.println("new head2 "+(head2==null?null:head2.data));
					System.out.println("new head1 "+(head1==null?null:head1.data));
				}
		}
		return newHead;
	}

}
