package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Date: 3/3/19
 * Problem Description: https://algorithms.tutorialhorizon.com/search-the-element-in-a-binary-tree-with-and-without-recursion/
 * - Given a binary tree and a given number x, Write an recursive algorithm to search the
 * - element in the tree.
 * Remember: for w/o recursion you can use queue or stack, without that it is not possible
 */
public class _Tree_16_Search_In_BinaryTree {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{6, 4, 8, 27, 5, 17, 22, 25});
        Node s = search(r, 17);
        System.out.println(s.data);
        System.out.println(isPresent(r, 77));
        System.out.println(searchWithoutRecursion(r, 17));
    }

    static Node search(Node root, int key) {
        if (root == null) {
            return null;
        }
        if (root.data == key) {
            return root;
        }
        Node l = search(root.left, key);
        if (l != null) {
            return l;
        }
        Node r = search(root.right, key);
        if (r != null) {
            return r;
        }
        return null;
    }

    static boolean isPresent(Node root, int key) {
        if (root == null) {
            return false;
        }
        return (root.data == key) || isPresent(root.left, key) || isPresent(root.right, key);
    }

    static boolean searchWithoutRecursion(Node root, int key){
        if(root == null){
            return false;
        }
        ArrayDeque<Node> st = new ArrayDeque<Node>();
        st.push(root);
        while(!st.isEmpty()){
            Node top = st.pop();
            if(top.data == key){
                return true;
            }
            if(top.left!=null){
                st.push(top.left);
            }
            if(top.right!=null){
                st.push(top.right);
            }
        }
        return false;
    }

}
