package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/1/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description: This is Binary Tree and not BST
 * Solution:
 * Remember:
 */
public class _Tree_06_MaxElementINBinaryTree {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{6, 4, 8, 27, 5, 17, 9});
        Node r2 = TreePrint.create(new int[]{4});
        System.out.println(max(r));
        System.out.println(max(null));
        System.out.println(max(r2));
    }

    static int max(Node root) {
        if (root == null) {
            return Integer.MIN_VALUE;
        }
        return Math.max(root.data, Math.max(max(root.left), max(root.right)));
    }
}
