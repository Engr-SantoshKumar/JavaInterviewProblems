package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/1/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_08_FindHeightOfBt {
    public static void main(String args[]) throws Exception {
        Node r = TreePrint.create(new int[]{6, 4, 8, 27, 5, 17, 22, 25});
        System.out.println(height(r));
    }

    static int height(Node root) {
        if (root == null) {
            return -1;// leaf node height is 0
        }
        return 1 + Math.max(height(root.left), height(root.right));
    }

}

