package core.educative_crs2;
import core.api.Node;
import core.api.TreePrint;

import java.util.Arrays;

/**
 * Date: 3/2/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Tree_15_DeepestNodeInBinaryTree {
    static int maxDepth=0;
    public static void main(String args[]){
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.right.left = new Node(6);
        root.right.right = new Node(7);
        root.right.right.right = new Node(8);
        Node[] ar = new Node[]{null};
        TreePrint.print(root);
        deepest(root, 0, ar);
        System.out.println(ar[0].data);
        deepestLeftNode(root, 0, ar);
        System.out.println(ar[0].data);
    }
    static void deepest(Node root, int depth, Node[] ar){
        if(root == null){ return ;}
        if(root.left == null && root.right == null && depth>maxDepth){
            ar[0] = root;
        }
        deepest(root.left, depth+1, ar);
        deepest(root.right, depth+1, ar);
    }

    static void deepestLeftNode(Node root, int depth, Node[] ar){
        if(root == null){ return ;}
        deepest(root.left, depth+1, ar);
        if(depth>maxDepth){
            ar[0] = root;
        }
        deepest(root.right, depth+1, ar);
    }


}
