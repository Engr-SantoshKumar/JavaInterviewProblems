package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/1/19
 * Remember:different ways to handle 2 variables
 */
public class _Tree_09_DepthOfANod {
    public static void main(String args[]){
        Node r = TreePrint.create(new int[]{6, 4, 8, 27, 5, 17, 22, 25});
        for (int a : new int[]{6, 4, 8, 27, 5, 17, 22, 25}) {
            Result result = depthOfNode(r, a, 0);
            System.out.println("depth  " + result.depth + " .. node " + result.node.data);
        }
        for (int a : new int[]{6, 4, 8, 27, 5, 17, 22, 25}) {
            int result = depthOfANode2(r, a, 0);
            System.out.println("depth  " + result + " .. node " + a);
        }
    }
    // Just a demo of using an object when we have 2 variables
    static Result depthOfNode(Node root, int key, int depth) {
        if (root == null) {
            return null;
        }
        if (root.data == key) {
            return new Result(root, depth);
        }
        Result l = depthOfNode(root.left, key, depth + 1);
        if (l != null) {
            return l;
        }
        Result r = depthOfNode(root.right, key, depth + 1);
        if (r != null) {
            return r;
        }
        return null;// when we use result of both calls we can use return null;
    }

    static int depthOfANode2(Node root, int key, int depth) {
        if (root == null) {
            return -1;
        }
        if (root.data == key) {
            return depth;
        }
        int l = depthOfANode2(root.left, key, depth + 1);
        if (l != -1) {
            return l;
        }
        int r = depthOfANode2(root.right, key, depth + 1);
        if (r != -1) {
            return r;
        }
        return -1;// when we use result of both calls we can use return null;
    }
}

class Result {
    Node node;
    int depth;

    public Result(Node node, int depth) {
        this.node = node;
        this.depth = depth;
    }
}
