package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 2/24/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description: first node represent the LSB, so just strt adding
 * from begining and pass carry to next level
 */
public class _LL_09_AddNumbsAsLL {
    public static void main(String args[]) {
        testFor(new int[]{1, 0, 9, 9}, new int[]{7, 3, 2}); //83101
        testFor(new int[]{9,9,9}, new int[]{9,9,9}); //8991
        testFor(new int[]{9,9,9}, new int[]{0}); //999
    }

    static Node add(Node head1, Node head2) {
        int c = 0;
        Node result = null;
        Node resultHead = null;
        while (head1 != null ||  head2!= null || c!=0) {
            int a = head1 == null ? 0 : head1.data;
            int b = head2 == null ? 0 : head2.data;
            int total = (a+ b + c);
            int sum = total % 10;
            c = total / 10;
            Node n = new Node(sum);
            if (result != null) {
                result.next = n;
            } else {
                resultHead = n;
            }
            result = n;
            head1 = head1!= null ? head1.next: null;
            head2 = head2!= null ? head2.next: null;
        }

        return resultHead;
    }

    static void testFor(int[] ar1, int[] ar2) {
        if (ar1 == null || ar1.length < 1) {
            System.out.println(" invalid input ");
            return;
        }
        MyLinkedList ll1 = new MyLinkedList();
        ll1.add(ar1);
        MyLinkedList ll2 = new MyLinkedList();
        ll2.add(ar2);
        Node h = add(ll1.getFirst(), ll2.getFirst());
        System.out.println("----\n" + "add lls ");
        MyLinkedList.iterate(h);
    }
}
