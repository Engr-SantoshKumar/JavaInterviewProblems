package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 2/23/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _LL_06_MergeSortOfLL22222222 {
    public static void main(String args[]){
        MyLinkedList ll = new MyLinkedList();
        ll.add(new int[]{9,0,3,4,5,6,7,8,1,2});
        System.out.println(" rev in k");
        MyLinkedList.iterate(ll.getFirst());
        //1->2->3->4->5->6->7->
        //2->1->4->3->6->5->8->7->
       // MyLinkedList.iterate(merge(ll.getFirst()));
        //System.out.println("find mid "+findMid(ll.getFirst(), findLast(ll.getFirst())).data);
        System.out.println("find mid "+findMid(ll.getFirst(), ll.getFirst().next.next.next.next.next).data);
        Node mid = findMid(ll.getFirst(), findLast(ll.getFirst()));
        Node head = merge(ll.getFirst(), mid);
        MyLinkedList.iterate(head);
    }

    static Node merge(Node head1, Node head2){
        if(head1 == null){
            System.out.println(" return ..1..."+head2+head2!=null?head2.data:null);
            return head2;
        }
        if(head2 == null){
            System.out.println(" return ..2..."+head1+head1!=null?head1.data:null);
            return head1;
        }
        if(head1.data == head2.data){
            System.out.println(" return ..3..."+head1+head1!=null?head1.data:null);
            return head1;
        }
        Node mid = findMid(head1, head2);
        System.out.println(" merge call for "+ head1.data+", "+head2.data+" mid is "+mid.data);
        Node tempMid = mid.next;
        mid.next = null;
        MyLinkedList.iterate(head1);
        MyLinkedList.iterate(tempMid);
        System.out.println(" before merge call for "+ head1.data+", "+mid.data);
        Node h1 = merge(head1, mid);
        System.out.println(" before merge call for "+ tempMid.data+", "+head2.data);
        Node h2 = merge(tempMid, head2);
        Node head = _LL_04_Merge2SortedLists.mergeSortedListsWithGivenHeads(h1, h2);
        return head;
    }
    static Node findMid(Node st, Node end){
        if(st.data == end.data){
            return st;
        }
        System.out.println(" calling mid for "+st.data+"   "+end.data);
        Node slow = st;
        Node fast = st;
        if(slow.next!=null && slow.next.data == end.data){
            return slow;
        }
        while(fast!=null && fast.next!=null && slow.data!= end.data && fast.data != end.data){
            //System.out.println(" slow "+slow.data);
            //System.out.println(" fast "+fast.data);
            slow = slow.next;
            if(fast.next != null){
                if(fast.data == end.data || fast.next.data == end.data){
                    break;
                }
                fast = fast.next;
            }
            fast = fast.next;
        }
        return slow;
    }
    static Node findLast(Node st){
        while(st!=null && st.next!=null){
            st = st.next;
        }
        System.out.println(" last is "+st.data);
        return st;
    }
}
