package core.educative_crs2;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 2/23/19
 * Runtime Complexity: o(n),    Space Complexity: o(K - num of even elems)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 * // first make a linked list of even nodes
 * // reverse this list
 * // for every even element in original list, merge
 */
public class _LL_07_MergeEvenNodes {

    public static void main(String args[]) {
        testFor(new int[]{9, 0, 3, 4, 5, 6, 7, 8, 1}); // odd # of elems
        // o/p: 9->8->3->6->5->4->7->0->1->
        testFor(new int[]{9, 0, 3, 4, 5, 6, 7, 8}); // even # of elems
        testFor(new int[]{9, 0}); // 2 elems
        testFor(new int[]{9}); // 1 elem
        testFor(new int[]{}); // 0 elem
        testFor(null); // null
    }
    static Node mergeEvenNodes(Node head) {
        Node t = head;
        Node evenNode = null;
        Node evenHead = null;
        int count = 0;
        while (t != null) {
            if (++count % 2 == 0) {
                Node even = new Node(t.data);
                if (evenNode == null) {
                    evenNode = even;
                    evenHead = evenNode;
                } else {
                    evenNode.next = even;
                    evenNode = evenNode.next;
                }
            }
            t = t.next;
        }
        // reverse even list
        evenHead = reverse(evenHead);
        Node te = evenHead;
        MyLinkedList.iterate(evenHead);

        //merge
        t = head;
        count = 0;
        while (t != null) {
            if (++count % 2 == 0) {
                System.out.print(" " +t.data);
                t.data = evenHead.data;
                System.out.print(" new " +t.data);
                evenHead = evenHead.next;
            }
            t = t.next;
        }
        System.out.println();
        return head;
    }

    static Node reverse(Node head) {
        if (head == null) {
            return null;
        }
        if (head.next == null) {
            return head;
        }
        Node h = reverse(head.next);
        head.next.next = head;
        head.next = null;
        return h;
    }
    static void testFor(int[] ar) {
        if (ar == null || ar.length < 1) {
            System.out.println(" invalid input ");
            return;
        }
        MyLinkedList ll = new MyLinkedList();
        ll.add(ar);
        MyLinkedList.iterate(ll.getFirst());
        Node head = mergeEvenNodes(ll.getFirst());
        MyLinkedList.iterate(head);
    }

}
