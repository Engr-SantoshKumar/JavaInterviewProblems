package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/4/19
 *                          90
 *  *             ┌───────────┴───────────┐
 *  *            50                      150
 *  *       ┌─────┴─────┐           ┌─────┴─────┐
 *  *      25          55          120         170
 *  *    ┌──┴──┐     ┌──┴──┐
 *  *   20    35    52    60
 * Remember:
 */
public class _Tree_28_LCA_BST {
    public static void main(String args[]){
        int[] ar = new int[]{90, 50, 150, 25, 55, 120, 170, 20, 35, 52, 60};
        Node root = TreePrint.create(ar);
        System.out.println(lca(root, 20, 25).data);
    }
    static Node lca(Node root, int a, int b){
        if(a>b){
            return lcaa(root, b, a);
        }
        return lcaa(root, a, b);
    }
    static Node lcaa(Node root, int a, int b){
        if(root == null){
            return null;
        }
        if(root.data == a || root.data == b){
            return root;
        }
        if(root.data > a && root.data < b ){
            return root;
        }else if(root.data > a && root.data > b){
            return lcaa(root.left, a, b);
        }
        return lcaa(root.right, a, b);
    }
}
