package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/4/19
 * Problem Description: super balanced if lh-rh>1

                                1                         is not balanced at 1 lh 4 rh 0
                ┌───────────────┴───────────────┐
                2                               3
        ┌───────┴───────┐
        4               5                                 is not balanced at 4 lh 1 rh -1
    ┌───┘           ┌───┘                                 is not balanced at 5 lh 2 rh -1
    8               6                                     is not balanced at 6 lh -1 rh 1
  ┌─┘               └─┐
 18                   7
                     ┌┘
                    17                          is balanced false

*
* */
public class _Tree_22_IsSuperBalanced {
    static boolean isBalanced = true;

    static int isSuperBalanced(Node root) {
        if (root == null) {
            return -1;
        }
        int leftHeight = isSuperBalanced(root.left);
        int rightHeight = isSuperBalanced(root.right);
        if (Math.abs(leftHeight - rightHeight) > 1) {
            System.out.println(" is not balanced at " + root.data + " lh " + leftHeight + " rh " + rightHeight);
            isBalanced = false;
        }
        return 1 + Math.max(leftHeight, rightHeight);
    }

    public static void main(String args[]) {
        Node root = new Node(1);
        root.left = new Node(2);
        root.right = new Node(3);
        root.left.left = new Node(4);
        root.left.right = new Node(5);
        root.left.right.left = new Node(6);
        root.left.right.left.right = new Node(7);
        root.left.right.left.right.left = new Node(17);
        root.left.left.left = new Node(8);
        root.left.left.left.left = new Node(18);
        TreePrint.print(root);
        isSuperBalanced(root);
        System.out.println(" is balanced " + isBalanced);
    }
}
