package core.educative_crs2;

/**
 * Date: 2/26/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _Str_02_RemoveDups {
    public static void main(String args[]) {
        String sentence = "abbabcddbabcdeedebc";//"abbabcddbabcdeedebc"; // "aabbbc"
        System.out.println(removeDups(sentence));  // abcbbc
    }
    // This removes concecutive dups and not dups from entire array, for that we need to use hashset
    static String removeDups(String sentence) {
        char[] ar = sentence.toCharArray();
        int i = 0;
        int j = 1;
        while (j < ar.length) {
            System.out.println(" i "+i+ " j "+j);
            if(ar[i] != ar[j]) {
                i++; j++;
            }else{
                while(j<ar.length && ar[i]==ar[j]){
                    j++;
                }
                System.out.println(" now moved j "+j);
                if(j<ar.length){
                    ar[++i] = ar[j];
                }
            }
        }
        String result="";
        for(int x=0; x<=i; x++){
            result+=ar[x];
        }
        return result;
    }
}
