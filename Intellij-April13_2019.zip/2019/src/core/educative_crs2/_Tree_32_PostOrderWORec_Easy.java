package core.educative_crs2;

import core.api.Node;
import core.api.TreePrint;

import java.util.ArrayDeque;

/**
 * Date: 3/6/19
 * * Date: 3/6/19
 *  * Remember: Use 2 stacks, push root on st1 then pop and put to st2, and put left and right on
 *  * st1, repeat for all nodes and at the end the st2 has post order stored on it
 *  *
 *  *  *                 6
 *  *  *         ┌───────┴───────┐         // Ans : 1, 3, 2, 5, 4, 7, 9, 8, 6
 *  *  *         4               8
 *  *  *     ┌───┴───┐       ┌───┴───┐
 *  *  *     2       5       7       9
 *  *  *   ┌─┴─┐
 *  *  *   1   3
 */
public class _Tree_32_PostOrderWORec_Easy {
    public static void main(String args[]){
        Node root = TreePrint.create(new int[]{6,4,8,2,5,7,9,1,3});
        postOrder(root);
    }

    static void postOrder(Node root){
        ArrayDeque<Node> stack1 = new ArrayDeque<>();
        ArrayDeque<Node> stack2 = new ArrayDeque<>();

        stack1.push(root);
        while(!stack1.isEmpty()){
            Node node = stack1.pop(); //  we pop from st1 and push to st2
            stack2.push(node);        // ** imp
            if(node.left!=null){
                stack1.push(node.left);
            }
            if(node.right!=null){
                stack1.push(node.right);
            }
        }

        while(!stack2.isEmpty()){
            Node x = stack2.pop();
            System.out.print(", "+x.data);
        }
    }
}
