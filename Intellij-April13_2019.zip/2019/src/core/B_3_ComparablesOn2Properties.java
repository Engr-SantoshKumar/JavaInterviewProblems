package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class B_3_ComparablesOn2Properties {

	public static void main(String[] args) {
		Kiwi a = new Kiwi("ared", 1);
		Kiwi b = new Kiwi("green", 3);
		Kiwi c = new Kiwi("blue", 5);
		Kiwi d = new Kiwi("ared", 0);
		
		System.out.println(a.equals(b));
		List<Kiwi> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		Collections.sort(list);
		for(Kiwi Kiwi : list) {
			System.out.println(String.format("color:%s & size:%s", Kiwi.color, Kiwi.size));
		}
		//Output
		/*color:ared & size:0
		  color:ared & size:1
		  color:blue & size:5
		  color:green & size:3*/
	}
}

class Kiwi implements Comparable<Kiwi> {
	String color;
	Integer size;

	public Kiwi(String color, int size) {
		this.color = color;
		this.size = size;
	}

	@Override
	public int compareTo(Kiwi that) {
		// natural order with this.compareTo(that) or for this.size-that.size
		// if color is same sort on basis of size
		if (this.color.compareTo(that.color) == 0) {
			return this.size - that.size;
			// or return this.size.compareTo(that.size);
		}
		return this.color.compareTo(that.color);
	}
}