package core;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class MyLinkedList implements Iterator<Node>, Iterable<Node> {
	Node head = null;
	Node last = null;

	// this is addLast
	
	/**
	 * *** ADDS to last of LinkedList
	 * Same as AddLast method
	 */
	public Node add(Integer value) {
		//System.out.println("adding "+value+" last "+last);
		Node current =  new Node(value);
		if (head == null) {
			last = current;
			return head = current;
		}
		last.next = current;
		last = current;
		return current;
	}
	public void add(int[] ar) {
		//System.out.println("adding "+value+" last "+last);
		for(int i : ar){
			add(i);
		}
	}
	
	public Node addFirst(Integer value) {
		//System.out.println("adding "+value+" last "+last);
		Node current =  new Node(value);
		if (head == null) {
			last = current;
			return head = current;
		}
		current.next = head;
		head = current;
		return head;
	}
	// removes the head element
	public Node removeFirst() {
		if (head != null) {
			Node temp = head;
			head = head.next;
			return temp;
		}
		return null;
	}
	 
	public Node getFirst() {
		return head;
	}
	 
	public Node getLast() {
		return last;
	}
		
	/**
	 *  This method is because of Iterator class implementation
	 * to use the remove method use the removeFirst
	 * to handle this situation you should create separate class for MyIterator and 
	 * instead of writing "return this" in the Iterable's ->iterator() method, should return new MyIterator() 
	 * @see Iterator#remove()
	 */
	@Override
	public void remove() {// Unsupported
	}

	public boolean hasNext() {
		return head!=null;
	}

	public Node next() {
		Node temp = head;
		head = head.next;
		return temp;
	}

	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.add(5);
		ll.add(6);
		ll.add(7);
		ll.removeFirst();
		Iterator<Node> it = ll.iterator();
		while(it.hasNext()) {
			System.out.println(it.next().data);
		}
	}

	@Override
	public Iterator<Node> iterator() {
		return this;
	}
	
	public static void iterate(Node head)  {
		while (head != null) {
			//Thread.sleep(200);
			System.out.print( head.data+"->");
			/*if(head.next!=null)
			System.out.println( "next is " +head.next.value+"->");
			*/head = head.next;
		}
		System.out.println();
	}
	
	public static MyLinkedList getDefaultMyLinkedList() {
		MyLinkedList ll = new MyLinkedList();
		ll.add(5);
		ll.add(7);
		ll.addFirst(8);
		ll.addFirst(9);
		return ll;
	}
	public int size() {
		Node h = head;
		int i=0;
		while(h!=null) {
			i++;
			h = h.next;
		}
		return i;
	}

}

/*class Node {
	Node next;
	Integer value;

	public Node(Integer value) {
		this.value = value;
	}
}*/