package core;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;

public class E_3_PQWithComparatorExp {
	public static void main(String[] args) {
		Transaction2 t1 = new Transaction2(1, 12);
		Transaction2 t2 = new Transaction2(1, 15);
		Transaction2 t3 = new Transaction2(1, 10);
		Transaction2 t4 = new Transaction2(1, 17);
		List<Transaction2> list = new ArrayList<>();
		list.add(t1);
		list.add(t2);
		list.add(t3);
		list.add(t4);

		// in pq there is no method to specify size its just initial capacity
		PriorityQueue<Transaction2> pq = new PriorityQueue<>(new TransactionComparator());

		for (Transaction2 t : list) {
			pq.offer(t);
		}
		while (!pq.isEmpty()) {
			System.out.println(" Transaction : " + pq.poll().amount);
		}

	}
	// By default pq is min pq, 
	/* Transaction : 17
	 Transaction : 15
	 Transaction : 12
	 Transaction : 10
	 */
	
	private static class TransactionComparator implements Comparator<Transaction2> {
		public int compare(Transaction2 a, Transaction2 b) {
			return b.amount - a.amount;
		}
	}
}
