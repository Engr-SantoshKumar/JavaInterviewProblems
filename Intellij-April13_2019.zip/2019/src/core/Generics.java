package core;

public class Generics {
public static void main(String[] args) {
	// no problem in creating array of any class type but 
	// see problem in creating array of Generic like Item
	AX[] array;
	array = new AX[0];
}
}

class AX<Item>{
	//Cannot create a generic array of Item, limitation on below line
	//Item[] item = new Item[0];
	
	// hence right way is as below
	Item[] item = (Item[])new Object[0];
	
}
