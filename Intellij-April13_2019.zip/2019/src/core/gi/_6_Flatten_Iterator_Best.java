package core.gi;

import java.util.*;

/**
 * Date: 3/17/19
 */
public class _6_Flatten_Iterator_Best {
    public static void main(String args[]) {
        Integer[] ar1 = new Integer[]{1, 2, 3};
        Integer[] ar2 = new Integer[]{4, 5};
        Integer[] ar3 = new Integer[]{6, 7, 8, 9};
        Integer[] ar4 = new Integer[]{10};
        Integer[] ar5 = new Integer[]{};
        Integer[] ar6 = null;
        List<Integer> l1 = Arrays.asList(ar1);
        List<Integer> l2 = Arrays.asList(ar2);
        List<Integer> l3 = Arrays.asList(ar3);
        List<Integer> l4 = Arrays.asList(ar4);
        List<Integer> l5 = Arrays.asList(ar5);
        Iterator<Integer> a = l1.iterator();
        Iterator<Integer> b = l2.iterator();
        Iterator<Integer> c = l3.iterator();
        Iterator<Integer> d = l4.iterator();
        Iterator<Integer> e = l5.iterator();
        List<Iterator<Integer>> ll = new ArrayList<>();
        ll.add(a);
        ll.add(b);
        ll.add(c);
        ll.add(d);
        ll.add(e);
        MyIter1 iter = new MyIter1(ll.iterator());
        while (iter.hasNext()) {
            System.out.println(iter.next());
        }
        iter.next();
    }
}

class MyIter1 implements Iterator<Integer> {
    Iterator<Iterator<Integer>> ll;
    Iterator<Integer> current;

    Iterator<List<Integer>> i;

    public MyIter1(Iterator<Iterator<Integer>> ll) {
        this.ll = ll;
        advance();
    }

    @Override
    public boolean hasNext() {
        if (!ll.hasNext()) {
            System.out.println(" now ll is exhausted");
            return false;
        }

        if (!current.hasNext()) {
            return false;
        }
        return true;
    }

    @Override
    public Integer next() throws NoSuchElementException{
        // If you still call the next method after ll is exhausted then throw this error
        if(!ll.hasNext()){
            throw new NoSuchElementException();
        }
        Integer result = current.next();
        advance();
        return result;
    }

    public void advance() {
        if (current == null || !current.hasNext()) {
            if (ll.hasNext()) {
                current = ll.next();
            }
        }
    }
}
