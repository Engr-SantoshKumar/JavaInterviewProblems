package core.gi;

import java.util.Arrays;

/**
 * Date: 3/5/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */

// NOT COMPLETE
public class _7_CharArrayAddOne {
    public static void main(String args[]){

        // char to integer c-'0'
        // integer to char c+'0'
        char t = '9';
        System.out.println(" what prints when you directly prints char "+t); //9
        int t2 = t;
        System.out.println(" when u directly assing char to int then you get ascill freq "+t2);//57
        // to convert you need following
        int t1 = '9' - '0';
        System.out.println(" \'9\' - \'0\' => "+t1);

        // now convert t1 back to char '9'
        char s = (char)(t1+'0');
        System.out.println((s+1));

        int x = '0';
        int y = '9';
        System.out.println(" x "+x+" y is "+y);
        int xx = (char)(9 + '0');
        System.out.println(" yy is "+xx+"..");
        System.out.println(xx);

        System.out.println('9'-'0');

        char[] car = new char[] { '1', '2', '3', '4' };
        addOne(car);
        addOne(new char[] { '9', '9' });

    }
    static void addOne(char[] car){

        char[] result = new char[car.length + 1];
        int carry = 1;
        int i = car.length-1;
        while(i>=0){
            int a = car[i] - '0';

            int res = (a + carry)%10;
            carry = (a + carry)/10;
            result[i+1] = (char) (res + '0');
            i--;
        }
        result[0] =(char) (carry + '0');
        System.out.println(Arrays.toString(result));
    }
}
