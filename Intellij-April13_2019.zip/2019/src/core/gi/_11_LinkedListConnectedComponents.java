package core.gi;


import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 3/12/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * We are given head, the head node of a linked list containing unique integer values.
 * We are also given the list G, a subset of the values in the linked list.
 * Return the number of connected components in G, where two values are connected if they appear
 * consecutively in the linked list.
 */
public class _11_LinkedListConnectedComponents {
    public static void main(String[] args) {
        //LinkedList ll = new LinkedList(new Integer[] { 1, 2, 3, 4, 5, 6, 7, 8});
        MyLinkedList ll = new MyLinkedList();
        ll.add(1);
        ll.add(2);
        ll.add(3);
        ll.add(4);
        ll.add(5);
        ll.add(6);
        ll.add(7);

        Set<Integer> set = new HashSet<>();
        //input 1,3,2,5z
        set.add(1);
        set.add(3);
        set.add(2);
        set.add(6);
        System.out.println(connected(ll, set));
    }
    static int connected(MyLinkedList ll, Set<Integer> set){
        Node head = ll.getFirst();
        int count=0;
        while(head !=null){
            Node startHead = head;
            while(head != null && set.contains(head.data)){
                head = head.next;
            }
            if(startHead != head){
                count++;
            }
            if(head != null){
                head = head.next;
            }
        }
        return count;
    }
}
