package core.gi;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Date: 3/13/19
 * Find most frequent words in a document
 * Remember:
 */
public class _15_Most_Freq_Word_In_Document {
    private static final String SINGLE_SPACE = " ";
    public static void main(String[] args) {
        String stream = "l l l l l i i i i i i i i j j j k k k k m m ";
        //String stream = "l";
        printTopKWorkds(stream, 3);
    }

    static void printTopKWorkds(String str, int k){
        // Base Case
        if(str.length()==0){
            return;
        }
        // when only one element in document
        if(str.length()==1){
            System.out.println(" only one element"+str+" fre 1");
            return;
        }
        Map<String, Integer> map = new HashMap<>();
        String[] ar = str.split(SINGLE_SPACE);
        for(String s : ar){
            if(!map.containsKey(s)){
                map.put(s, 1);
            }else{
                map.put(s, map.get(s)+1);
            }
        }
        // priority queue that holds "k" elements(notice the size in constructor
        // pq will be sorted on basis of freq
        PriorityQueue<Pair> pq = new PriorityQueue<>(k, new Comparator<Pair>(){
            public int compare(Pair one, Pair two){
                return one.freq - two.freq;
            }
        });

        for(Map.Entry<String, Integer> entry : map.entrySet()){
            if(k-- > 0){
                pq.offer(new Pair(entry.getKey(), entry.getValue()));
            }else{
                Pair top = pq.peek();
                if(top.freq < entry.getValue()){
                    pq.poll();
                    pq.offer(new Pair(entry.getKey(), entry.getValue()));
                }
            }
        }
        while(!pq.isEmpty()){
            Pair p = pq.poll();
            System.out.println(" entry "+p.word +", "+p.freq);
        }

    }
    static class Pair{
        String word;
        int freq;
        public Pair(String s, int value){
            this.word = s;
            this.freq = value;
        }
    }
}
