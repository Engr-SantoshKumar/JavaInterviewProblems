package core.gi;

import java.util.HashMap;
import java.util.Map;

/**
 * Date: 3/10/19
 * TODO : RUN ON LEETCODE
 * Solution:
 * Remember:
 */
public class _1_LongestSubstringWithAtMostTwoDistinctChars {
    public static void main(String[] args) {
        // "abcbbbbcccbdddadacb", the longest substring that contains 2 unique
        // character is "bcbbbbcccb".
        String s = "abcbbbbcccbdddadacb";
        longestSubstr(s, 2);
    }

    static String longestSubstr(String s, int k) {
        Map<Character, Integer> map = new HashMap<>();
        String result = "";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char cur = s.charAt(i);
            sb.append(cur);
            map.put(cur, !map.containsKey(cur) ? 1 : map.get(cur) + 1);
            String t = sb.toString();
            int j = 0;
            System.out.println("\n----------------------------");
            while (map.size() > k) { // should put j<s.lenght to keep prevention but not required
                char x = t.charAt(j);
                System.out.println(" \nlook for "+x+" j is "+j);
                printMap(map);
                int count = map.get(x);
                if (count == 1) {
                    System.out.println(" in count 1");
                    map.remove(x);
                    printMap(map);
                } else {
                    map.put(x, count - 1);
                }
                j++;
            }
            if (map.size() == k) {
                String res = t.substring(j);
                sb = new StringBuilder(res);   // Most Important as now our string truncated first
                if (res.length() > result.length()) { //char or multiple chars that are not required
                    result = res;
                    System.out.println(" result so far "+result);
                }
            }
        }
        System.out.println("final result "+result);
        return result;
    }

    static void printMap(Map<Character, Integer> map){
        System.out.println("\n{");
        for(Map.Entry<Character, Integer> entry : map.entrySet()){
            System.out.print("["+entry.getKey()+", "+entry.getValue()+"]");
        }
        System.out.print("}");
    }
    // OLD IMPlementation, but because of no check for size==k it will print "a" for input "a"
    // ans should be blank in that case
    static void findAtmostKDistinctCharsX(String str, int k) {
        System.out.println("ere " + str);
        Map<Character, Integer> map = new HashMap<>();
        String s = "";
        String max = "";
        for (int i = 0; i < str.length(); i++) {
            s = s + str.charAt(i);
            addOrUpd(map, str.charAt(i));
            int t = 0;
            while (map.size() > 2 && t < s.length()) {
                // remove the first char from curr string and reduce/ remove from map
                decKey(map, s.charAt(0));
                t++;
            }
            s = s.substring(t);
            max = max.length() > s.length() ? max : s;
            System.out.println(" s at this stage " + s);
        }
        System.out.println(" FINAL rsult " + max);
    }

    static void addOrUpd(Map<Character, Integer> map, char c) {
        if (map.containsKey(c)) {
            map.put(c, map.get(c) + 1);
        } else {
            map.put(c, 1);
        }
    }

    static void decKey(Map<Character, Integer> map, char c) {
        if (map.containsKey(c)) {
            if (map.get(c) == 1) {
                map.remove(c);
            } else if (map.get(c) > 1) {
                map.put(c, map.get(c) - 1);
            }
        }
    }
}
