package core.gi;

import java.util.Arrays;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _55_Three_Colors_Flag {
    public static void main(String[] args) {

        int[] nums = new int[]{1, 2, 0, 2, 2, 1, 0, 1, 0, 0, 1};
        System.out.println("input => " + Arrays.toString(nums));
        sortColors(nums);
        System.out.println("output => " + Arrays.toString(nums));
        int[] nums2 = new int[]{1, 2, 0, 2, 2, 1, 0, 1, 0, 0, 1};
        System.out.println("input => " + Arrays.toString(nums2));
        sortColors(nums2, nums.length);
        System.out.println("output => " + Arrays.toString(nums2));
    }

    static void sortColors(int[] ar) {
        int p1 = 0;
        int p2 = ar.length - 1;
        int i = 0;
        while (i < p2) { // This is super important, if you do i-> o--ar.len then ans is wrong
            if (ar[i] == 0) { // it will again merge p2s that are already sorted
                swap(i, p1, ar);
                i--;
                p1++;
            }
            if (ar[i] == 2) {
                swap(i, p2, ar);
                i--;
                p2--;
            }
            i++;
        }
    }

    static void swap(int i, int j, int[] ar) {
        // System.out.println(" swapping " + i + " with " + j);
        int temp = ar[i];
        ar[i] = ar[j];
        ar[j] = temp;
    }

    // this is count sort not sure how it works
    static void sortColors(int A[], int n) {
        int red = -1, white = -1, blue = -1;
        for (int i = 0; i < n; i++) {
            if (A[i] == 0) {
                A[++blue] = 2;
                A[++white] = 1;
                A[++red] = 0;
                //System.out.println("c1.."+Arrays.toString(A));
            } else if (A[i] == 1) {
                A[++blue] = 2;
                A[++white] = 1;
                //System.out.println("c2.."+Arrays.toString(A));
            } else if (A[i] == 2)
                A[++blue] = 2;
            //System.out.println("c3.."+Arrays.toString(A));
        }
    }
}
