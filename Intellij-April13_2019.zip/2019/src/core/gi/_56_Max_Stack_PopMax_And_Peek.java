package core.gi;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/**
 * Date: 3/16/19
 * Implement max stack with popMax and peek
 * Remember: use the Object version and not the 2 stack method(it complicates)
 */
public class _56_Max_Stack_PopMax_And_Peek {
    static Deque<Integer> st1 = new ArrayDeque<>();
    static Deque<Integer> st2 = new ArrayDeque<>();
    static Deque<Pair> stPair = new ArrayDeque<>();
    public static void main(String args[]) {
      try {
          testFor(new int[]{1, 2});
          testFor(new int[]{1, 2, 3});
          testFor(new int[]{5, 3, 7, 0, 4});
          testFor(new int[]{1});
          testFor(new int[]{});
      }catch(InvalidException e){
          System.out.println(" invalid input provided "+e.getMessage());
      }
      /*  prepare(ar);
        popMax(ar);
        */

    }
    static void testFor(int[] ar) throws  InvalidException{
        stPair.clear();
        System.out.println("input array "+ Arrays.toString(ar));
        prepareMaxPair(ar);
        System.out.println("pop max pair "+popMax()+" ");
        System.out.println("pop max pair "+popMax()+" \n -------------------");
    }

    static void prepareMaxPair(int[] ar) throws  InvalidException{
        if(ar == null || ar.length==0){
            throw new InvalidException(" invalid input ");
        }
        for(int a : ar){
            stPair.push(new Pair(a, Math.max(a, stPair.isEmpty()? a: stPair.peek().max)));
        }
        System.out.println("stack prepared as "+stPair);
    }
    static int popMax() throws InvalidException{
        if(stPair.isEmpty()){
            throw new InvalidException("Stack is Empty");
        }
        Deque<Pair> temp = new ArrayDeque<>();
        while(stPair.peek().max != stPair.peek().value ){
            temp.push(stPair.pop());
        }
        Pair result = stPair.pop();
        while(!temp.isEmpty()){
            Pair top = temp.pop();
            stPair.push(new Pair(top.value, Math.max(top.value,
                    stPair.isEmpty()? top.value : stPair.peek().max)));
        }
        System.out.println(stPair);
        return result.value;
    }

    static void prepare(int[] ar) {
        for (int i = 0; i < ar.length; i++) {
                st1.push(ar[i]);
                st2.push(Math.max(ar[i], st2.isEmpty()? ar[i] : st2.peek()));
        }
        System.out.println(st1);
        System.out.println(st2);
    }

    static int popMax(int[] ar) {
        Deque<Integer> temp = new ArrayDeque<>();
        int b = st2.peek();
        while(st1.peek()!=b){
            temp.push(st1.pop());
            st2.pop();
        }
        int result = st1.pop();
        st2.pop(); // throw the corresponding max

        // push back
        while(!temp.isEmpty()){
            st1.push(temp.pop());
            st2.push(Math.max(st1.peek(), st2.isEmpty() ? st1.peek() : st2.peek()));
        }
        System.out.println(" popmax st1 => " +st1);
        System.out.println(" popmax st2 => " +st2);

        return result;
    }

    static class Pair{
        int value;
        int max;

        public Pair(int value, int max) {
            this.value = value;
            this.max = max;
        }
        @Override
        public String toString(){
            return "("+this.value + ", "+this.max+")";
        }
    }
}
/*
input array [1]
stack prepared as [(1, 1)]
[]
pop max pair 1
 -------------------
input array [1, 2]
stack prepared as [(2, 2), (1, 1)]
[(1, 1)]
pop max pair 2
 -------------------
input array [1, 2, 3]
stack prepared as [(3, 3), (2, 2), (1, 1)]
[(2, 2), (1, 1)]
pop max pair 3
 -------------------
input array [5, 3, 7, 0, 4]
stack prepared as [(4, 7), (0, 7), (7, 7), (3, 5), (5, 5)]
[(4, 5), (0, 5), (3, 5), (5, 5)]
pop max pair 7
 -------------------
input array []
 invalid input provided  invalid input
 */