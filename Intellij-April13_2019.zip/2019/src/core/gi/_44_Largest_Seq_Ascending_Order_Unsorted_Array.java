package core.gi;

import java.util.Arrays;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _44_Largest_Seq_Ascending_Order_Unsorted_Array {

    public static void main(String args[]) {
        int[] ar = new int[]{3, 27, 4, 5, 6, 12, 17, 9, 22, 23, 24, 25, 26, 58};
        testFor(ar);
        testFor(new int[]{4,7,9});
        testFor(new int[]{4,5,8});
        testFor(new int[]{4});
        testFor(new int[]{});
    }
    static void testFor(int ar[]){
        System.out.println("--------\n input "+ Arrays.toString(ar));
        largetSeq(ar);
    }

    // because in inner while we mention j< ar.len and j starts from 1 this program works for
    // blank input or 1 element as well.
    static void largetSeq(int[] ar) {
        int m1 = 0;
        int m2 = 0;
        int i = 0;
        int j = 1;
        while (j < ar.length) {
            while (j < ar.length && ar[j] - ar[j - 1] == 1) { // always check inner loop not to
                j++;                                          // exceed the ar length
            }
            if ((j - 1) - i > m2 - m1) {  // remember to keep j-1 as above loop already incr to
                m1 = i;                   // next num after continuous seq
                m2 = j - 1;              // m2 should be (j-1)
            }
            i = j;
            j = j + 1;
        }
        System.out.println(" m1 = " + m1 + " m2 = " + m2);
        if(m1!=m2){
            System.out.println(" m1 = " + ar[m1] + " m2 = " + ar[m2]);
        }

    }
}
