package core.gi;

import core.api.Node;
import core.api.TreePrint;

/**
 * 22 67987700
 *
 * ifsc code UTIB0000245
 * ACFOUNT TYPE LOAN
 * REMARKS - NAME OF THE LOAN HOALDER
 * AXIS BANK LTD
 *
 * 91 406717 4100 - NRI ACCOUNT ENQUIRY
 *
 * Date: 3/25/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _47_Tree_Max_Sum_Neighbor_Restriction {
    public static void main(String args[]){
        Node r1 = TreePrint.create(new int[]{3,100,400,5,7});
        Pair2 pair = maxSumHelper(r1);
        System.out.println(pair.first);
        System.out.println(pair.second);
        r1 = TreePrint.create(new int[]{3,100,400,5,7});
        pair = max1(r1);
        System.out.println(pair.first);
        System.out.println(pair.second);
    }
    // SImplified 2nd condition
    static Pair2 max1(Node root){
        if (root==null)
        {
            Pair2 sum=new Pair2(0, 0);
            return sum;
        }

        Pair2 leftPart = max(root.left);
        Pair2 rightPart = max(root.right);

        // include this node, then include grandchilds
        int sumSelfAndGrandChilds = root.data + leftPart.second + rightPart.second;
        // exclude this node then choose the max of (a+b'second, (b+a'second)
        // reduced condition is chooose max of a and b + max of a.second+b.second
        int childAndTheirGrandchild =
                Math.max(leftPart.first, leftPart.second) +
                        Math.max(rightPart.first, rightPart.second);
        return new Pair2(sumSelfAndGrandChilds, childAndTheirGrandchild);
    }

    static Pair2 max(Node root){
        if (root==null)
        {
            Pair2 sum=new Pair2(0, 0);
            return sum;
        }

        Pair2 leftPart = max(root.left);
        Pair2 rightPart = max(root.right);

        // include this node, then include grandchilds
        int sumSelfAndGrandChilds = root.data + leftPart.second + rightPart.second;
        // exclude this node then choose the max of (a+b'second, (b+a'second)
        // this below can be reduced to only 2 conditions
        int childAndTheirGrandchild = Math.max( Math.max(leftPart.first+rightPart.second,
                rightPart.first+leftPart.second),
                Math.max(leftPart.first+rightPart.first, leftPart.second+rightPart.second));
        return new Pair2(sumSelfAndGrandChilds, childAndTheirGrandchild);
    }

    public static Pair2 maxSumHelper(Node root)
    {
        if (root==null)
        {
            Pair2 sum=new Pair2(0, 0);
            return sum;
        }
        Pair2 sum1 = maxSumHelper(root.left);
        Pair2 sum2 = maxSumHelper(root.right);
        Pair2 sum=new Pair2(0,0);

        // This node is included (Left and right children
        // are not included)
        sum.first = sum1.second + sum2.second + root.data;

        // This node is excluded (Either left or right
        // child is included)
        sum.second = Math.max(sum1.first, sum1.second) +
                Math.max(sum2.first, sum2.second);

        return sum;
    }

    // Returns maximum sum from subset of nodes
    // of binary tree under given constraints
    public static int maxSum(Node root)
    {
        Pair2 res=maxSumHelper(root);
        return Math.max(res.first, res.second);
    }
}
class Pair2
{
    int first,second;
    Pair2(int first,int second)
    {
        this.first=first;
        this.second=second;
    }
}

class S {
    int self, childSum;

    S(int self, int rightSum) {
        this.self = self;
        this.childSum = childSum;
    }
}

/*
root
sum = root.left.second + root.right.second + root
or max root.left + root.right.second, root.right + root.left.second



100+0+0 || 400 + 5+7 || 3 + 5+7
sfsdf*/
