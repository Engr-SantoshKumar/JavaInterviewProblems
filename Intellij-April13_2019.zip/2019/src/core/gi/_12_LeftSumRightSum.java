package core.gi;

import java.util.Arrays;

/**
 * Date: 3/12/19
 */
public class _12_LeftSumRightSum {
    public static void main(String[] args) {
        int[] ar = new int[]{1, 4, 2 , 5};

        System.out.println(ar[leftRightUsingPrefixArray(ar)]);
    }

    static int leftSumRightSum(int[] ar) {
        if (ar.length == 0) {
            return -1;
        }
        int totalSum = 0;
        for (int i = 0; i < ar.length; i++) {
            totalSum += ar[i];
        }
        int leftSum = 0;
        for (int i = 0; i < ar.length; i++) {
            int rightSum = totalSum - ar[i] - leftSum;
            if (rightSum == leftSum) {
                return i;
            }
            leftSum += ar[i];
        }
        return -1;
    }

    static int leftRightUsingPrefixArray(int[] ar){
        int[] leftSum = new int[ar.length];
        leftSum[0] = ar[0];
        for (int i = 1; i < ar.length; i++) {
            leftSum[i] = leftSum[i-1] + ar[i];
        }
        System.out.println(Arrays.toString(leftSum));

        int rightSum = 0;
        for (int i = ar.length-1; i>=0; i--) {
            rightSum += ar[i];
            if(rightSum == leftSum[i]){
                return i;
            }
        }
        return -1;
    }
}
