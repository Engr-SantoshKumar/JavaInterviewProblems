package core.gi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Date: 3/10/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _6_FlatenIterator_NOT_GOOD {
    public static void main(String args[]){
        Integer[] ar1 = new Integer[]{1, 2, 3};
        Integer[] ar2 = new Integer[]{4, 5};
        Integer[] ar3 = new Integer[]{6, 7, 8, 9};
        List<Integer> l1 = Arrays.asList(ar1);
        List<Integer> l2 = Arrays.asList(ar2);
        List<Integer> l3 = Arrays.asList(ar3);
        Iterator<Integer> a = l1.iterator();
        Iterator<Integer> b = l2.iterator();
        Iterator<Integer> c = l3.iterator();
        List<List<Integer>> ll = new ArrayList<>();
        ll.add(l1);
        ll.add(l2);
        ll.add(l3);
//        Iterator<List<Integer>> iterOfIter = MyIter.iterator();
        MyIter iter = new MyIter(ll);
        Iterator<List<Integer>> i = iter.iterator();

        while(i.hasNext()){
            Iterator<Integer> it = i.next().iterator();
            while(it.hasNext()){
                System.out.println(it.next());
            }
        }

    }
}

class MyIter implements  Iterable<List<Integer>>{
    List<List<Integer>> ll = new ArrayList<>();
    public MyIter(List<List<Integer>> ll ){
        this.ll = ll;
    }
    @Override
    public Iterator<List<Integer>> iterator(){
        return ll.iterator();
    }
}