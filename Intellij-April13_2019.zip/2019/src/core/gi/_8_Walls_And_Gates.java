package core.gi;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Queue;

/**
 * Date: 3/10/19
 * -1 - A wall or an obstacle.
 * 0 - A gate.
 * INF - Infinity means an empty room. We use the freq 231 - 1 = 2147483647 to represent INF as
 * you may assume that the distance to a gate is less than 2147483647.
 * Fill each empty room with the distance to its nearest gate. If it is impossible to reach a
 * gate, it should be filled with INF.
 * Remember:
 * Output:
 *       [3, -1, 0, 1]
 *       [2, 2, 1, -1]
 *       [1, -1, 2, -1]
 *       [0, -1, 3, 4]
 */
public class _8_Walls_And_Gates {
    static int[] R = new int[]{0, 0, 1, -1};
    static int[] C = new int[]{1, -1, 0, 0};

    public static void main(String args[]) {
        int[][] A = {
                {Integer.MAX_VALUE, -1, 0, Integer.MAX_VALUE},
                {Integer.MAX_VALUE, Integer.MAX_VALUE, Integer.MAX_VALUE, -1},
                {Integer.MAX_VALUE, -1, Integer.MAX_VALUE, -1},
                {0, -1, Integer.MAX_VALUE, Integer.MAX_VALUE}};
        for (int[] x : A) {
            System.out.println(Arrays.toString(x));
        }
        dfs(A);
        for (int[] x : A) {
            System.out.println(Arrays.toString(x));
        }
    }

    static void dfs(int[][] A) {
        for (int row = 0; row < A.length; row++) {
            for (int col = 0; col < A[0].length; col++) {
                if (A[row][col] == 0) {
                    boolean[][] visited = new boolean[A.length][A[0].length];
                    dfs(row, col, visited, A, 0);
                }
            }
        }
    }

    static void dfs(int row, int col, boolean[][] visited, int[][] A, int path) {
        if (row < 0 || row >= A.length || col < 0 || col >= A[0].length || visited[row][col]
                || A[row][col] == -1) { // This condition is very imp to ignore cells of val -1
            return;
        }
        visited[row][col] = true;
        A[row][col] = Math.min(A[row][col], path);
        for (int i = 0; i < R.length; i++) {
            dfs((row + R[i]), (col + C[i]), visited, A, path + 1);
            // IMP (row + R[i]) not (row + i)   ** it is very big bug***
        }
    }

    // this is preferred method
    static void bfs(int[][] A) {
        // input all zeros in the queue
        // we will only change entries when it is INF, and becoz of bfs only nearest entries get
        // updated, so once 0 at A(0,2) updates its closest 2 elements, the queue is
        // 0,0|neighboour of first 0|
        // when first 0 is removed it updated its nearest 2 elements and then the next in queue
        // is the 0 at A(2,0) so it updates the next 2 nearest entries
        Queue<Cell> q = new ArrayDeque<>();

        // put all 0s in the queue
        for (int row = 0; row < A.length; row++) {
            for (int col = 0; col < A[0].length; col++) {
                if (A[row][col] == 0) {
                    q.offer(new Cell(row, col));
                }
            }
        }

        while (!q.isEmpty()) {
            Cell c = q.poll();
            for (int i = 0; i < R.length; i++) {
                int rowT = c.row + R[i];
                int colT = c.col + C[i];
                if (rowT < 0 || rowT >= A.length || colT < 0 || colT >= A[0].length) {
                    continue;
                }

                if (A[rowT][colT] == Integer.MAX_VALUE) {
                    A[rowT][colT] = A[c.row][c.col] + 1;
                    q.offer(new Cell(rowT, colT));
                }
            }
        }
    }

    static void bfsWithQSize(int[][] A) {
        for (int row = 0; row < A.length; row++) {
            for (int col = 0; col < A[0].length; col++) {
                if (A[row][col] == 0) {
                    boolean[][] visited = new boolean[A.length][A[0].length];
                    bfsWithQSize(row, col, visited, A);
                }
            }
        }
    }

    // this is just practice for exhausting queue for one level
    static void bfsWithQSize(int row, int col, boolean[][] visited, int[][] A) {
        ArrayDeque<Cell> q = new ArrayDeque<>();
        q.push(new Cell(row, col));
        int count = 0;
        while (!q.isEmpty()) {
            int size = q.size();
            count++;
            while (size-- > 0) {
                Cell c = q.poll();
                System.out.println(" polled " + A[c.row][c.col]);
                visited[c.row][c.col] = true;
                for (int i = 0; i < R.length; i++) {
                    int tRow = c.row + R[i];
                    int tCol = c.col + C[i];
                    System.out.println(" new row " + tRow + ", " + tCol);
                    if (tRow < 0 || tRow >= A.length || tCol < 0 || tCol >= A[0].length || visited[tRow][tCol]
                            || A[tRow][tCol] == -1) { // This condition is very imp to ignore cells
                        // of val -1
                        System.out.println();
                        System.out.println(".continue for ..." + " new row " + tRow + ", " + tCol);
                        continue;
                    }
                    q.offer(new Cell(tRow, tCol));
                    A[tRow][tCol] = Math.min(A[tRow][tCol], count);
                }
            }
        }
    }
}

class Cell {
    int row;
    int col;

    public Cell(int row, int col) {
        this.row = row;
        this.col = col;
    }
}
