package core.gi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * Date: 3/14/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _28_Selective_Iterator_Using_List {
    public static void main(String args[]){
        ArrayList<Number> al = new ArrayList<>();
        al.add(new Double(2.5D));
        al.add(new Long(4L));
        al.add(new Integer(1));
        al.add(new Integer(2));
        al.add(new Integer(3));
        SelectionListIterator sl = new SelectionListIterator(al);
        while(sl.hasNext()){
            System.out.println(sl.next());
        }
    }
}

class SelectionListIterator implements Iterator<Number> {
    ArrayList<Number> al;
    Iterator<Number> it;
    Number curr;
    public SelectionListIterator(ArrayList<Number> al) {
        this.al = al;
        it = al.iterator();
        advance();
    }

    @Override
    public boolean hasNext(){
        return curr != null;
    }

    @Override
    public Integer next(){
        if(curr == null) {
         throw new NoSuchElementException();
        }
        Integer temp = (Integer) curr;
        curr = null; // This is very imp, as for last element curr will hold 3 and when u go to
        advance();  // advance method here then it will not nullify curr, making infinite loop
        return temp;
    }

    void advance(){
        while(it.hasNext()){
            Number t = it.next();
            if(select(t)){
                curr = t;
               break;
            }
        }
    }

    boolean select(Number n){
        return n instanceof Integer;
    }
}