package core.gi;

import java.util.PriorityQueue;

/**
 * Date: 3/16/19
 */
public class _50_Top_K_Elems {
    public static void main(String args[]) {
        int[] ar = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9};
        int k = 3;
        topK(ar, k);
    }

    static void topK(int[] ar, int k) {
        PriorityQueue<Integer> pq = new PriorityQueue<>(k);
        for (int a : ar) {
            if (pq.size() < k) {
                pq.offer(a);
            } else {
                pq.poll();
                pq.offer(a);
            }
        }
        while (!pq.isEmpty()) {
            System.out.println(pq.poll());
        }

    }
}
