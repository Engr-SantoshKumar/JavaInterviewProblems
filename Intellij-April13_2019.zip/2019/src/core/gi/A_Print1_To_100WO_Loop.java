package core.gi;

import java.util.Arrays;
import java.util.Iterator;

/**
 * Date: 3/14/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class A_Print1_To_100WO_Loop {

    static int i = 1;

    public static void main(String args[]) {
        // you can write 1 to 100 sops
        Printer1.print100();
        System.out.println();
        new Printer().printTill100();
        // load nums from 1 to 100 in array and print like below
        int[] ar = new int[]{1,2,3,4,5};
        System.out.println("\n"+Arrays.toString(ar));

    }


}

class Printer1 {
    static int i;

    static void print1() {
        System.out.print(", " + i++);
    }

    static void print3() {
        print1();
        print1();
        print1();
    }

    static void print10() {
        print3();
        print3();
        print3();
        print1();
    }

    static void print30() {
        print10();
        print10();
        print10();
    }

    static void print100() {
        print30();
        print30();
        print30();
        print10();
    }
}

class Printer implements Iterator<Integer> {
    int i = 0;

    @Override
    public boolean hasNext() {
        return i < 100;
    }

    @Override
    public Integer next() {
        return ++i;
    }

    void printTill100() {
        while (hasNext()) {
            System.out.print(",.." + next());
        }
    }
}