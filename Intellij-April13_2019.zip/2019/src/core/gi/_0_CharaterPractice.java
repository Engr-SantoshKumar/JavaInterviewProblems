package core.gi;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _0_CharaterPractice {
    public static void main(String args[]) {
        int a = 65;
        char c = (char) a;
        System.out.println(c); // A

        char c1 = '?';
        int x = c1;
        System.out.println(x); //65

        System.out.println("is letter Z "+isLetter('Z')); // true
        System.out.println("is letter ? "+isLetter('?')); // true

        //fetch numeric value from char object -> '1' fetch 1 as int
        char c2 = '5';
        int x1 = Character.getNumericValue(c2);
        System.out.println("int value hidden in \'5\' is =>"+x1);
        System.out.println("int value hidden in \'5\' is =>"+Integer.valueOf(String.valueOf(c2)));

    }

    static boolean isLetter(char c) {
        return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z');
    }
}
