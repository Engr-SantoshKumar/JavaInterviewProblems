package core.gi;

/**
 * Date: 3/13/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class ____19_TelephoneKeypad {
    public static void main(String args[]){
        long c = System.currentTimeMillis();
     int x = (int) c;
        System.out.println(" .. x "+x);
        System.out.println(" .. y "+c);
        System.out.println(" .. x "+Integer.MIN_VALUE);
        System.out.println(" .. x "+Integer.MAX_VALUE);
        System.out.println(" .. x.. "+(int)(2147483648l));
        System.out.println(" .. x "+(int)(2147483650l));
        System.out.println(" .. x "+(int)(c% Integer.MAX_VALUE));
        System.out.println(" .. x "+(int)(1553832917312l%2147483647));}
}
