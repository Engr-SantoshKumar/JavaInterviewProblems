package core.gi;

import java.util.Arrays;

/**
 * Date: 3/13/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _25_Recover_Rotated_Array {
    public static void main(String[] args) {
        int[] ar = new int[]{4,5,6,7,7,1,2,3,3};
        //testForRotation(ar);
        int[] ar1 = new int[]{7,1,2,3,3};
        testForRotation(ar1);
        int[] ar2 = new int[]{7,6};
        testForRotation(ar2);
        int[] ar3 = new int[]{7};
        testForRotation(ar3);

    }
    static void testForRotation(int[] ar){
        getSortedArray(ar);
        System.out.println(Arrays.toString(ar));
    }
    static void getSortedArray(int[] ar){
        int rotation = rotationPoint(ar);
        System.out.println(rotation);
        reverse(0, rotation, ar);
        reverse(rotation+1, ar.length-1, ar);
        reverse(0, ar.length-1, ar);
    }

    static int rotationPoint(int[] ar) {
        int lo = 0;
        int hi = ar.length - 1;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            // when there are 3 elements, compare mid >= as it says i-1 and i are equal so this
            // is the right most element in case of dups
            if (mid > 0 && mid < ar.length - 1 && ar[mid] >= ar[mid - 1] && ar[mid] > ar[mid + 1]) {
                return mid;
            }
            // when hi and lo are next to each other
            if (hi - lo == 1) {
                return ar[hi] >= ar[lo] ? hi : lo;
            } else if (ar[mid] >= ar[lo]) { // >= because of reason explained above, prefer
                // condition in _13_maxinincreasing array
                lo = mid + 1;
            } else {
                hi = mid - 1;
            }
        }
        return -1;
    }
    static void reverse(int lo, int hi, int[] ar){
        System.out.println("calling rotationa for "+lo+" , "+hi) ;
        int i=lo; int j=hi;
        while(i<j){
            int temp = ar[i];
            ar[i] = ar[j];
            ar[j] = temp;
            i++; j--;
        }
    }
}
