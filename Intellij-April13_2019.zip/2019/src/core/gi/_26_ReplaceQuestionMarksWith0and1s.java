package core.gi;

/**
 * Date: 3/14/19
 */
public class _26_ReplaceQuestionMarksWith0and1s {
    public static void main(String[] args) {
            String str = "1?00?101";
            func(str);
        }

        private static void func(String s){
            if(s == null){
                return;
            }
            if( s.indexOf("?") == -1){
                System.out.println(s);
                return;
            }
            func(s.replaceFirst("\\?", "0"));
            func(s.replaceFirst("\\?", "1"));
        }
}
