package core.gi;

import java.util.Arrays;

/**
 * Date: 3/14/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 * First char of input string is first char of repeated substring
 * Last char of input string is last char of repeated substring
 * Let S1 = S + S (where S in input string)
 * Remove 1 and last char of S1. Let this be S2
 * If S exists in S2 then return true else false
 * Let i be index in S2 where S starts then repeated substring length i + 1 and repeated
 * substring S[0: i+1]
 */
public class ____34_Periodic_String {
    public static void main(String args[]){
     String x = "abcabc";
        System.out.println(repeatedSubstringPattern(x));
        String x1 = "abcd";
        System.out.println(repeatedSubstringPattern(x1));
        System.out.println("..."+Arrays.toString(computeTemporaryArray("abcdabca".toCharArray())));

        System.out.println(repeatedSubstringPattern2("abcd"));
        System.out.println(repeatedSubstringPattern2("abdabc"));

        // RUN KMP herex
        /*String str = "abcxabcdabcdabcy";
        String subString = "abcdabcy";
        SubstringSearch ss = new SubstringSearch();
        boolean result = ss.KMP(str.toCharArray(), subString.toCharArray());
        System.out.print(result);*/
    }

    static boolean repeatedSubstringPattern(String str) {
        String s = str + str;
        return s.substring(1, s.length() - 1).contains(str);
    }

    //kmp temp array formation
    // if char at index and i matches then ar[i] is index+1 else go to value of index
    // and check at that index char matches with i's char if yes index+1 else index
    static int[] computeTemporaryArray(char pattern[]){
        int [] lps = new int[pattern.length];
        int index =0;
        for(int i=1; i < pattern.length;){
            if(pattern[i] == pattern[index]){
                lps[i] = index + 1;
                index++;
                i++;
            }else{
                if(index != 0){
                    index = lps[index-1];
                }else{
                    lps[i] =0;
                    i++;
                }
            }
        }
        return lps;
    }

    /**
     * KMP algorithm of pattern matching.
     */
    public boolean KMP(char []text, char []pattern){

        int lps[] = computeTemporaryArray(pattern);
        int i=0;
        int j=0;
        while(i < text.length && j < pattern.length){
            if(text[i] == pattern[j]){
                i++;
                j++;
            }else{
                if(j!=0){
                    j = lps[j-1];
                }else{
                    i++;
                }
            }
        }
        if(j == pattern.length){
            return true;
        }
        return false;
    }

    // Based on KMP find if a string is periodic
    static boolean repeatedSubstringPattern2(String s) {
        //System.out.println(" ------\npattern 2 method ... input .."+s);
        System.out.print(" p2...");
        int prefixTable[] = new int[s.length()];
        int i = 0;
        int j = 1;
        while (j < s.length()) {
            if (s.charAt(i) == s.charAt(j)) {
                prefixTable[j++] = ++i;
            } else if (i > 0) {
                i = prefixTable[i - 1];
            } else if (i == 0) {
                j++;
            } else
                i = 0;
        }
        System.out.print(" "+Arrays.toString(prefixTable));
        //System.out.println((prefixTable[s.length() - 1] > 0)+"  "+ s.length() );
        return prefixTable[s.length() - 1] > 0 && s.length() % (s.length() - prefixTable[s.length() - 1]) == 0;
    }

}
