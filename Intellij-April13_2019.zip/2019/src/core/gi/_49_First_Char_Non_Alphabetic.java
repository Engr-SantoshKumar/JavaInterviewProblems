package core.gi;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _49_First_Char_Non_Alphabetic {
    public static void main(String args[]){
     String s = "Beehive";
     firstNonAlpha(s);
    }

    static void firstNonAlpha(String s){
        char[] ar = s.toLowerCase().toCharArray();
        char prev = ar[0];
        for(int i = 1; i<ar.length; i++){
            if(ar[i] < prev){
                System.out.println(" out is "+ar[i]+ " at index "+i);
                return;
            }
            prev = ar[i];
        }
        System.out.println(" good string");
    }
}
