package core.gi;

import java.util.ArrayList;
import java.util.List;

/**
 * Date: 3/5/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _2_MergeIntervals {
    public static void main(String args[]) {
        Interval in = new Interval(4, 13);
        List<Interval> list = insertInterval(createIntervalList(), in);
        for(Interval interval : list){
            System.out.println(interval.start+", "+interval.end);
        }
    }

    static List<Interval> insertInterval(List<Interval> list, Interval newInterval){
        List<Interval> result = new ArrayList<>();
        if(list == null || list.size() == 0){
            list = new ArrayList<Interval>();
        }
        for(Interval current : list){
            if(current.end < newInterval.start){
                result.add(current);
            }else if(newInterval.end < current.start){
                result.add(newInterval);
                newInterval = current;
            }else{
                Interval merged = new Interval(Math.min(current.start, newInterval.start),
                        Math.max(current.end, newInterval.end));
                newInterval = merged;
            }
        }
        System.out.println("below line is very important else the last interval will be lost****");
        result.add(newInterval);
        return result;
    }

    static private List<Interval> createIntervalList() {
        List<Interval> list = new ArrayList<Interval>();
        list.add(new Interval(1, 5));
        list.add(new Interval(7, 10));
        list.add(new Interval(15, 20));
        list.add(new Interval(25, 35));
        System.out.println("Initial interval List");
        return list;
    }
}

class Interval {
    int start;
    int end;

    public Interval() {
        start = 0;
        end = 0;
    }

    public Interval(int start, int end) {
        this.start = start;
        this.end = end;
    }
}
