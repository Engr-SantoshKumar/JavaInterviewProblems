package core.gi;

import java.util.Comparator;
import java.util.PriorityQueue;

/**
 * Date: 3/16/19
 */
public class _48_Sorting_String_Max_Count_Letters {
    public static void main(String args[]) {
        String s = "THISISnnnnGOoooOOD";
        countAndScan(s.toCharArray(), 4);
        countAndScan2(s.toCharArray(), 4);
    }
    static void countAndScan(char[] carray, int k) {
        int[] ar = new int[127];
        PriorityQueue<Pair> pq = new PriorityQueue<>(k, new Comparator<Pair>() {
            @Override
            public int compare(Pair a, Pair b) {
                return a.count - b.count;
            }
        });
        for (char c : carray) {
                ar[c] = ar[c] + 1;
        }
        for (int i = 0; i < ar.length; i++) {
            if (pq.size() < k) {
                pq.offer(new Pair(i, ar[i]));
            } else {
                pq.poll();
                pq.offer(new Pair(i, ar[i]));
            }
        }
        System.out.println(" pq size " + pq.size());
        while (!pq.isEmpty()) {
            Pair top = pq.poll();
            int index = top.index;
            char ch = (char) index;
            int count = top.count;
            System.out.println(" ch .." + ch + " count " + count);
        }
    }
    // There is very high chance of mistake here

    static void countAndScan2(char[] carray, int k) {
        int[] ar = new int[52];
        PriorityQueue<Pair> pq = new PriorityQueue<>(k, new Comparator<Pair>() {
            @Override
            public int compare(Pair a, Pair b) {
                return a.count - b.count;
            }
        });
        for (char c : carray) {
            boolean x = Character.isUpperCase(c);
            if (x) {
                ar[c - 'A'] = ar[c - 'A'] + 1;
            } else {
                ar[c - 'a' + 26] = ar[c - 'a' + 26] + 1; // can make mistake here
            }
        }
        for (int i = 0; i < ar.length; i++) {
            if (pq.size() < k) {
                pq.offer(new Pair(i, ar[i]));
            } else {
                pq.poll();
                pq.offer(new Pair(i, ar[i]));
            }
        }
        System.out.println(" pq size " + pq.size());
        while (!pq.isEmpty()) {
            Pair top = pq.poll();
            int idx = top.index;
            int count = top.count;
            char ch;
            if (idx < 26) {
                ch = (char) (idx + 'A');
            } else {
                ch = (char) (idx - 26 + 'a'); // this is point of mistake
            }
            System.out.println(" ch .." + ch + " count " + count);
        }
    }
}

class Pair {
    int index;
    int count;

    public Pair(Integer index, int count) {
        this.index = index;
        this.count = count;
    }
}