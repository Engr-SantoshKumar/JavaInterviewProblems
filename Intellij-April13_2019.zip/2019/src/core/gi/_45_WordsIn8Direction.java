package core.gi;

import java.util.*;

/**
 * Date: 3/10/19
 * you will see multiple entries for result as if I try for HNSUN, one time N will call(SUN)
 * then one time H will call (NSUN)
 */
public class _45_WordsIn8Direction {
                               // N, S, E, W    NE  SE  NW   SW
    static int[] c1 = new int[] {-1, 1, 0, 0,  -1,  1,  -1,   1};
    static int[] c2 = new int[] {0,  0, 1, -1,  1,  1,  -1,  -1};
    static Map<Coordinate, String> memory = new HashMap<>();
    static Set<String> dict = new HashSet<>();
    static char[][] M = new char[][]{
            {'I', 'N', 'D', 'A', 'N'},
            {'C', 'L', 'E', 'U', 'S'},
            {'A', 'S', 'S', 'T', 'A'},
            {'Q', 'N', 'I', 'A', 'N'},
            {'H', 'A', 'M', 'A', 'M'}};

    public static void main(String args[]) {
        dict.add("SUN");
        dict.add("SAM");
        dict.add("INDAN");
        dict.add("ASSTA");
        dict.add("DESIM");
        dict.add("HNSUN");
        dict.add("ILSAM");
        for (int row = 0; row < M.length; row++) {
            for (int col = 0; col < M[0].length; col++) {
                for (int k = 0; k < c1.length; k++) {
                    dfs(k, row, col);
                }
            }
        }
    }

    static String dfs(int direction, int row, int col) {
        if (!inRange(row, col, direction)) {
            return "";
        }
        String t = memory.get(new Coordinate(row + c1[direction], col + c2[direction], direction));
        if (t == null) {
            t = dfs(direction, row + c1[direction], col + c2[direction]);
            memory.put(new Coordinate(row + c1[direction], col + c2[direction], direction), t);
        }
        if (dict.contains(M[row][col] + t)) {
            System.out.println(" dict elem found =>" + M[row][col] + t);
        }
        return M[row][col] + t;
    }

    static boolean inRange(int row, int col, int direction) {
        return row < M.length && row >= 0 && col >= 0 && col < M[0].length && direction < c1.length;
    }

}

// Implement equals and hashCode as we kept Coordinate obj as key in hashmap
class Coordinate {
    Integer row;
    Integer col;
    Integer dir;

    public Coordinate(Integer row, Integer col, Integer dir) {
        this.row = row;
        this.col = col;
        this.dir = dir;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        Coordinate that = (Coordinate) o;
        return row.equals(that.row) &&
                col.equals(that.col) &&
                dir.equals(that.dir);
    }

    @Override
    public int hashCode() {
        return Objects.hash(row, col, dir);
    }
}