package core.gi;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/5/19
 *         5
 *     ┌───┴───┐
 *    -1       3          ans -> 13
 *   ┌─┴─┐   ┌─┴─┐
 *  -2   4  -6  10
 *
 * Problem Description:
 */
public class B_WeightedSum {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{5, -1, 3, -2, 4, -6, 10});
        System.out.println(sum(r));
    }

    static int sum(Node root) {
        if (root == null) {
            return 0;
        }
        return root.data + sum(root.left) + sum(root.right);
    }
}
