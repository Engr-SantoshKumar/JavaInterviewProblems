package core.gi;

import java.util.Arrays;

/**
 * Date: 3/16/19
 * Problem Description: Find the maximum sum subarray
 * Solution: Kadanes Algorithm
 * Remember: I will not add prev sum to me if it was negative
 */
public class _53_Kadanes_Largest_Sum_Subarray {
    public static void main(String[] args) {

        int[] ar = new int[]{-1, -2, 3, 4, -5, 6};
        testFor(ar);
        testFor(new int[]{1});
        testFor(new int[]{-1, 1});
        testFor(new int[]{-1, -2, 4});
        testFor(new int[]{});

        Interval inter = kadanesInterval(ar);
        System.out.println(" Intervalx "+inter.start+", "+inter.end+" => "+inter.sum);

        Interval inter2 = kadanesInterval(new int[]{1});
        System.out.println(" Intervalx "+inter2.start+", "+inter2.end+" => "+inter2.sum);

        Interval inter3 = kadanesInterval(new int[]{});
        System.out.println(" Intervalx "+inter3.start+", "+inter3.end+" => "+inter3.sum);
    }

    static void testFor(int[] ar){
        System.out.println(" ar "+ Arrays.toString(ar)+"  o/p => "+kadanes(ar));
    }

    static int kadanes(int[] ar) {
        int curr_sum = Integer.MIN_VALUE;
        int max_sum = Integer.MIN_VALUE;
        // I will not add prev sum to me if it was negative
        for (int i = 0; i < ar.length; i++) {
            if (curr_sum >= 0) {
                curr_sum += ar[i];
            } else {
                curr_sum = ar[i];     //reset if prev sum was not positive
            }
            max_sum = Math.max(max_sum, curr_sum);
        }
        return max_sum;
    }

    static Interval kadanesInterval(int[] ar) {
        Interval curr = new Interval(-1, -1, Integer.MIN_VALUE);
        Interval max = new Interval(-1, -1, Integer.MIN_VALUE);
        for (int i = 0; i < ar.length; i++) {
            if (curr.sum >= 0) {
                curr.end = i;
                curr.sum = curr.sum + ar[i];
            } else {
                curr = new Interval(i, i, ar[i]);
            }
            max = curr.sum > max.sum ? curr : max;
        }
        return max;
    }

    static class Interval {
        int start;
        int end;
        int sum;

        public Interval(int start, int end, int sum) {
            this.start = start;
            this.end = end;
            this.sum = sum;
        }
    }
}
