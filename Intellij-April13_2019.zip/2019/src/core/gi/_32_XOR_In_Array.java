package core.gi;

import java.util.Arrays;

/**
 * Date: 3/14/19
 * ANOTHER way, load it to set, then 2*unique - sum of all elems in array is ANS
 * Problem Description: In an array every number occurs twice except one, find it
 *  input array [3, 3, 16, 16, 12, 12, 10] .. o/p..10
 *  input array [1] .. o/p..1
 *  input array [1, 1] .. o/p..-2147483648
 *  input array [1, 1, 0] .. o/p..0
 *
 * **  IMPORTANT to note that if xor is 0 it i/p could be {1,1} or {1,1,0} then check if num of
 *  elems is even then the o/p is not 0
 */
public class _32_XOR_In_Array {
    public static void main(String[] args) throws InvalidException{
        int[] ar = new int[]{3, 3, 16, 16, 12, 12, 10};
        testFor(ar);
        testFor(new int[]{1});
        testFor(new int[]{1,1});
        testFor(new int[]{1,1, 0});
        testFor(null);
    }
    static void testFor(int[] ar) throws  InvalidException{
        System.out.println(" input array "+ Arrays.toString(ar)+" .. o/p.."+findSingleNumber(ar));

    }

    static int findSingleNumber(int[] ar) throws InvalidException{
        if(ar == null || ar.length==0){
            throw new InvalidException("invalid input");
        }
        int xor = ar[0];
        for (int i = 1; i < ar.length; i++) {
            xor= xor^ar[i];
        }
        // when o/p is 0 meaning it could be {1,1} or {1,1,0} in first case 0 is not right ans
        if(xor == 0){
            if(ar.length%2 == 0){
                return Integer.MIN_VALUE;
            }
        }
        return xor;
    }
}
