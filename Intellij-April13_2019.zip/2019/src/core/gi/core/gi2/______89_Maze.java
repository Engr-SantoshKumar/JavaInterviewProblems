package core.gi.core.gi2;

import java.util.ArrayDeque;
import java.util.LinkedHashSet;
import java.util.Objects;

/**
 * Date: 4/6/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 * Another similar problem:
 * https://leetcode.com/problems/unique-paths/discuss/23193/My-DFS-solution-for-unique-paths
 */
public class ______89_Maze {

    static int[] R = {1, -1, 0, 0};
    static int[] C = {0, 0, 1, -1};

    public static void main(String args[]) {
        int[][] M =
                {       {0, 1, 1, 0},
                        {0, 0, 0, 0},
                        {0, 0, 0, 1},
                        {1, 1, 0, 1},
                        {0, 0, 0, 0}};
                   /*{{0, 0, 1, 0, 0},
                    {0, 0, 0, 0, 0},
                    {0, 0, 0, 1, 0},
                    {1, 1, 0, 1, 1},
                    {0, 0, 0, 0, 0}};*/
        findPath(M);
    }

    static void findPath(int[][] M) {
        Pair start = new Pair(0, 0);
        start.path = new LinkedHashSet<>();
        Pair dest = new Pair(4, 3);
        dest.path = new LinkedHashSet<>();

        ArrayDeque<Pair> q = new ArrayDeque<Pair>();
        q.push(start);
        while (!q.isEmpty()) {
            Pair top = q.poll();
            if(top.equals(dest)){
                System.out.println(top.path);
                break;
            }
            for (int row = 0; row < R.length; row++) {
                int r = top.row + R[row];
                int c = top.col + C[row];
                Pair p = new Pair(r,c);
                System.out.println(p+" path "+p.path);
                if (top.path.contains(p) || !inRange(r, c, M.length, M[0].length, M)){
                    continue;
                }
                else{
                    p.path = new LinkedHashSet<>();
                    p.path.addAll(top.path);
                    p.path.add(top);
                    if(p.equals(dest)){
                        System.out.println("=================="+p.path);
                    }
                    q.push(p);
                }
            }
        }


    }
        static boolean inRange(int row, int col, int R, int C, int[][] M) {
            //System.out.println(" is in range "+ row+" ci :"+col);
            return row < R && col < C && row > -1 && col > -1;
        }


    static class Pair {
        int row;
        int col;
        LinkedHashSet<Pair> path;
        public Pair(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public boolean equals(Object o) {
            if (o == this) {
                return true;
            }
            Pair curr = (Pair) o;
            return curr.col == this.col && curr.row == this.row;
        }

        public String toString(){
            return "M["+row+", "+col+"] : "+path;
        }
        @Override
        public int hashCode() {
            return Objects.hash(row, col);
        }
    }
}
