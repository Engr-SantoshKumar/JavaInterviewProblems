package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 4/6/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _106_Eval_Infix_Prefix_PostFix {
    public static void main(String args[]) {
        char x = (char) ('d' - 'a');
        int t = (int) x;
        System.out.println(x);
        System.out.println(t);

        char y = 'A';
        int tt = y - 'A';
        System.out.println(tt);
        String exp = "(+7(* 8 12))"; // 103
        String exp1 = "(+7(* 8 12)(*2(+9 4)7)3)"; // 288
        String exp2 = "(* 3 4 5)"; // 60
        String exp3 = "(+1 2)"; //3
        String exp4 = "(+3 4 5)"; //12
        String exp5 = "(*2(+3 5))"; // 16
        eval(exp);
        eval(exp1);
        eval(exp2);
        eval(exp3);
        eval(exp4);
        eval(exp5);

    }

    static void eval(String expr) {
        StringBuilder sb = new StringBuilder();
        ArrayDeque<Character> ops = new ArrayDeque<>();
        ArrayDeque<Integer> vals = new ArrayDeque<>();
        boolean prev = false;
        for (char c : expr.toCharArray()) {
            boolean isDigit = false;
            if (c == ' ') {
                prev = false;
                continue;
            } else if (c == '(') {
                ops.push(c);
                vals.push(Integer.MIN_VALUE); // push this as a token to stop fetching ints from
            } else if (c == ')') { // stack, else it fetches all ints from stack
                compute(ops, vals);

            } else if (Character.isDigit(c)) {
                if (prev) {
                    int x = vals.pop() * 10 + Integer.parseInt(String.valueOf(c));// note conversion
                    vals.push(x);
                } else {
                    vals.push(Integer.parseInt(String.valueOf(c)));
                }
                isDigit = true;
            } else {
                ops.push(c);
            }
            if(isDigit){ // if current is digit then in next iter indicate last was digit
                prev = true;
            }else{
                prev = false;
            }
        }
        System.out.println(vals.pop());
    }

    static void compute(ArrayDeque<Character> ops, ArrayDeque<Integer> vals) {
        char oper = '(';
        while (!ops.isEmpty()) {
            char top = ops.pop();
            if (top == '(') {
                break;
            } else {
                oper = top;
            }
        }

        // doing this way is also correct, but i do not like the fetching first value
        /*int val = Integer.MIN_VALUE;
        if(!vals.isEmpty()){ // fetch first value to be operated
            val = vals.pop();
        }
        while (!vals.isEmpty()){
            int x = vals.pop();
            if(x == Integer.MIN_VALUE){
                break;
            }
            if (oper == '+') {
                val += x;
            }
            if (oper == '-') {
                val -= x;
            }
            if (oper == '*') {
                if (val == Integer.MIN_VALUE) {
                    val = 1;
                }
                val *= x;
            }
            if ( oper == '/'){
                if(x == 0){
                    throw new
                            UnsupportedOperationException("Cannot divide by zero");
                }
            }
        }*/
        while(!vals.isEmpty()){
            int a; int b;
            if(vals.size() >= 2) {
                a = vals.pop();
                b = vals.pop();
                if(b == Integer.MIN_VALUE){
                    vals.push(a);
                    break;
                }

                if (oper == '+') {
                    vals.push(a + b);//val += x;
                }
                if (oper == '-') {
                    vals.push(a - b);
                }
                if (oper == '*') {
                    vals.push(a * b);
                }
                if (oper == '/') {
                    if (b == 0) {
                        throw new
                                UnsupportedOperationException("Cannot divide by zero");
                    }
                    vals.push(a / b);
                }
            }
        }
    }

}


class EvaluateString {
    // Returns true if 'op2' has higher or same precedence as 'op1',
    // otherwise returns false.
    public static boolean hasPrecedence(char op1, char op2) {
        if (op2 == '(' || op2 == ')')
            return false;
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-'))
            return false;
        else
            return true;
    }

    // A utility method to apply an operator 'op' on operands 'a'
    // and 'b'. Return the result.
    public static int applyOp(char op, int b, int a) {
        switch (op) {
            case '+':
                return a + b;
            case '-':
                return a - b;
            case '*':
                return a * b;
            case '/':
                if (b == 0)
                    throw new
                            UnsupportedOperationException("Cannot divide by zero");
                return a / b;
        }
        return 0;
    }


    // This is from some site and is NOT PART of solution, just to take idea from, use precedence
    // code from here
    public int evaluate(String expression) {
        char[] tokens = expression.toCharArray();

        // Stack for numbers: 'values'
        Stack<Integer> values = new Stack<Integer>();

        // Stack for Operators: 'ops'
        Stack<Character> ops = new Stack<Character>();

        for (int i = 0; i < tokens.length; i++) {
            // Current token is a whitespace, skip it
            if (tokens[i] == ' ')
                continue;

            // Current token is a number, push it to stack for numbers
            if (tokens[i] >= '0' && tokens[i] <= '9') {
                StringBuffer sbuf = new StringBuffer();
                // There may be more than one digits in number
                while (i < tokens.length && tokens[i] >= '0' && tokens[i] <= '9')
                    sbuf.append(tokens[i++]);
                values.push(Integer.parseInt(sbuf.toString()));
            }

            // Current token is an opening brace, push it to 'ops'
            else if (tokens[i] == '(')
                ops.push(tokens[i]);

                // Closing brace encountered, solve entire brace
            else if (tokens[i] == ')') {
                while (ops.peek() != '(')
                    values.push(applyOp(ops.pop(), values.pop(), values.pop()));
                ops.pop();
            }

            // Current token is an operator.
            else if (tokens[i] == '+' || tokens[i] == '-' ||
                    tokens[i] == '*' || tokens[i] == '/') {
                // While top of 'ops' has same or greater precedence to current
                // token, which is an operator. Apply operator on top of 'ops'
                // to top two elements in values stack
                while (!ops.empty() && hasPrecedence(tokens[i], ops.peek()))
                    values.push(applyOp(ops.pop(), values.pop(), values.pop()));

                // Push current token to 'ops'.
                ops.push(tokens[i]);
            }
        }

        // Entire expression has been parsed at this point, apply remaining
        // ops to remaining values
        while (!ops.empty())
            values.push(applyOp(ops.pop(), values.pop(), values.pop()));

        // Top of 'values' contains result, return it
        return values.pop();
    }
}
