package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class _0_kp {
    public static void main(String args[]){
        final List<Object[]> data = new ArrayList<>();
        data.add(new Object[]{"NL", "Rotterdam", "Kees", 38});
        data.add(new Object[]{"NL", "Rotterdam", "Peter", 54});
        data.add(new Object[]{"NL", "Rotterdam", "Tom", 17});
        data.add(new Object[]{"NL", "Amsterdam", "Suzanne", 51});

        final Map<String, List<Object[]>> map = data.stream().collect(
                Collectors.groupingBy(row -> row[0].toString() + ":" + row[1].toString()));

        for (final Map.Entry<String, List<Object[]>> entry : map.entrySet()) {
            final double average = entry.getValue().stream()
                    .mapToInt(row -> (int) row[3]).average().getAsDouble();
            System.out.println("Average age for " + entry.getKey() + " is " + average);
        }
    }
}
