package core.gi.core.gi2;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This is not correct to have prune method inside the custom class because when HM does not says
 * int the Entry<K,V> K or V should be comparable, its user who has to take care of it
 * if he does not pass the comparable objects to entry then the result is out of control
 * that is why we extends comparable in our objects or write comparator
 */
public class _91_HashMap_With_Expiring_Values_V2 {
    public static void main(String args[]) {
       /* TimePair<Long, Long> t = new TimePair<>();
        MHM2<Integer, TimePair<Long, Long>> map = new MHM2<Integer, TimePair<Long, Long>>();*/
        //map.put()
      /*  Long x = 5L;
        Long y = 6L;
        x.compareTo(y);
        long currTime = 6000L;
        map.put(3, new TimePa 3000L);
        map.put(4, 4000L);
        map.put(6, 6000L);
        map.put(7, 7000L);
        map.put(8, 8000L);
        map.prune(1000L, currTime);

        for (Map.Entry<Integer, Long> entry : map.map.entrySet()) {
            System.out.println(" " + entry.getKey() + " : " + entry.getValue());
        }*/

       /* Map<Integer, String> treeMap = new TreeMap<Integer, String>(
                new Comparator<Integer>() {

                    @Override
                    public int compare(Integer o1, Integer o2) {
                        return o2.compareTo(o1);
                    }

                }) {
            @Override
            public String put(Integer k, String v) {

                return v;
            }*/


            /*Map<Integer, TimePair> treeMap1 = new TreeMap<Integer, TimePair>(
                    new Comparator<Integer, TimePair>() {

                        @Override
                        public int compare(Map.Entry<Integer, TimePair> o1, Map.Entry<Integer, TimePair>o2) {
                            return 1;
                        }

                    });*//* {
                @Override
                public TimePair put(Integer k, TimePair v) {

                    return v;
                }
*/;

         TreeMap<Integer, TimePair> map =
              new TreeMap<Integer, TimePair>(){
          @Override
            public TimePair put(Integer k , TimePair v){
              System.out.println(" putting "+k);
              TimePair t = this.get(k);
              if(this.containsKey(k) && v.time > t.time){
                  return super.put(k, v);
              }
              if(!this.containsKey(k)){
                  return super.put(k, v);
              }
              return null;
          }
        };

        map.put(3, new TimePair(3000L,3000L));
        map.put(3, new TimePair(3500L,3500L));
        map.put(4, new TimePair(4000L,4000L));
        map.put(6, new TimePair(6000L,6000L));
        map.put(8, new TimePair(8000L,8000L));
        map.put(7, new TimePair(7000L,7000L));
        //map.prune(1000L, currTime);
        SortedSet<TimePair> values = new TreeSet<>(map.values());
        System.out.println(map.size());
        System.out.println(map);
        /*Collections.sort( map, new Comparator<TimePair>(){
            @Override
            public int compare(TimePair a, TimePair b){
                return b.time.compareTo(a.time);
            }
        });*/


/*class MHM2<K, TimePair> extends ConcurrentHashMap<K, TimePair> {
    ConcurrentHashMap<K, TimePair> map;

    public MHM2() {

    }

    ConcurrentHashMap<K, TimePair> getInstance() {
        map = new ConcurrentHashMap<K, TimePair>();
        return map;
    }

    @Override
    public TimePair put(K key, TimePair value) {
        TimePair t = map.get(key);
        if (map.containsKey(key) && t.tim
           // map.put(key, value);
        }
*//*
        if (!map.containsKey(key)) {
            map.put(key, value);
        }
*//*
        return value;
    }

}*/
        }

    }
class ValueComparator<Integer> implements Comparator<Integer>{
    @Override
    public int compare(Integer o, Integer t1) {
return 1;
    }
}
class Entry<K, V extends Comparable, TimePair > {
    K key;
    TimePair pair;
}

class TimePair implements Comparable<TimePair>{
   public Long time;
    public Long timeout;
    public TimePair(Long time , Long timeout){
        this.time = time;
        this.timeout = timeout;
    }

    @Override
    public int compareTo(TimePair that) {
        return that.time.compareTo(this.time);
    }

    public String toString(){
        return this.time.toString();
    }
}
