package core.gi.core.gi2;

/**
 * Find Closest number using binary search
 */
public class _0_Find_Closest_Index {
    public static void main(String args[]) {
        int[] ar = {1, 4, 6, 8, 8, 10, 12, 15, 24, 45};
        for (int i = 0; i <= 25; i++) {
            testFor(ar, i);
        }

    }

    static void testFor(int[] ar, int key) {
        int index = findClosestIndex(ar, key);
        System.out.println(" input : " + key + " closest num is " + (index == -1 ? "none" :
                ar[index]));
    }

    static int findClosestIndex(int[] ar, int key) {
        int lo = 0;
        int hi = ar.length - 1;
        int closest = -1;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            if (key == ar[mid]) {
                closest = mid;
                return closest;
            } else if (key > ar[mid]) {
                lo = mid + 1;
                closest = mid;
            } else {
                hi = mid - 1;
            }
        }
        return closest;
    }

}
