package core.gi.core.gi2;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class _0_Stream {
    public static void main(String args[]){
      Stream.of("aa", "bb")
      .forEach(System.out :: println);

        Stream.of("aa", "bb")
                .forEach(x-> System.out.println(x));

      /*List<String> list = new ArrayList<>();
      list = Stream.of("aa", "CC", "bb")
              .collect(Collectors.toList());
        System.out.println(Arrays.toString(list.toArray()));*/
        List<String> list = new ArrayList<>();
        list.add("dd");
        Stream.of(list)
                .sorted(Comparator.comparing(s -> !s.equals("d")))
                .findFirst()
                .ifPresent(System.out :: print);
                ///.forEach(System.out :: print);

    }
}
