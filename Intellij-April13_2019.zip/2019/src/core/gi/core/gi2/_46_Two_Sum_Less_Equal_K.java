package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 4/6/19
 */

public class _46_Two_Sum_Less_Equal_K {
    int x;

    public static void main(String args[]) {
        int[] ar = {1, 4, 6, 8, 8, 10, 12, 15, 24, 45};
        //testFor(b, 5);
        findSumLessThanK(ar, 16);
    }

    static void testFor(int[] ar, int k) {
        System.out.println(" testing for sum" + k + " in " + Arrays.toString(ar));
        //twoSum2(ar, k);
    }

    static void findSumLessThanK(int[] ar, int k) {
        int left = 0;
        int right = ar.length - 1;
        List<Pair> list = new ArrayList<>();
        //left=0, ci=index of 15, make pairs of 0 with(4....15)
        // left = 4 ci = index of 12, make pairs of 4 with (6....12) and so on
        while (left < right && ar[left] < k) {// make all pairs from 0 to complement, then 1 till
            // its
            // complement, and so on
            int complement = k - ar[left];
            int closestIndex = _0_Find_Closest_Index.findClosestIndex(ar, complement);
            computePairs(ar, left, closestIndex, k, list);
            left++;
        }
        System.out.println(Arrays.toString(list.toArray()));
    }

    static void computePairs(int[] ar, int left, int right, int k, List<Pair> list) {

        for (int i = left + 1; i <= right; i++) {
            if (ar[left] + ar[i] <= k) {
                list.add(new Pair(ar[left], ar[i]));
            }
        }
    }

    static class Pair {
        int s;
        int e;
        public Pair(int s, int e) {
            this.s = s;
            this.e = e;
        }

        public String toString() {
            return "\n{" + s + ", " + e + "}";
        }
    }

}
/*{1, 4},
 {1, 6},
 {1, 8},
 {1, 8},
 {1, 10},
 {1, 12},
 {1, 15},
 {4, 6},
 {4, 8},
 {4, 8},
 {4, 10},
 {4, 12},
 {6, 8},
 {6, 8},
 {6, 10},
 {8, 8}
 */
