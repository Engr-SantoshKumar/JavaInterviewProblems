package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 4/10/19
 */
public class _0_Onhand_Dealer2 {
   /* public static void main(String args[]) {
        OnHand o1 = new OnHand(new Item("Book"), "RCV", "ORG1", 2);
        OnHand o2 = new OnHand(new Item("Book"), "stores", "ORG1", 10);
        OnHand o3 = new OnHand(new Item("Book"), "RCV", "ORG1", 2);
        //OnHand o3 = new OnHand(new Item("Book"), "staging", "ORG1", 4);
        OnHand o4 = new OnHand(new Item("Pencil"), "stores", "ORG1", 5);
        OnHand o5 = new OnHand(new Item("Pencil"), "staging", "ORG1", 6);

        OnHand o11 = new OnHand(new Item("Book"), "RCV", "ORG2", 1);
        OnHand o12 = new OnHand(new Item("Book"), "stores", "ORG2", 9);
        OnHand o13 = new OnHand(new Item("Book"), "staging", "ORG2", 3);
        OnHand o14 = new OnHand(new Item("Pencil"), "stores", "ORG2", 4);
        OnHand o15 = new OnHand(new Item("Pencil"), "staging", "ORG2", 5);
        OnHand[] oA = new OnHand[]{o1, o2, o3, o4, o5, o11, o12, o13, o14, o15};
        List<OnHand> list = new ArrayList<OnHand>(Arrays.asList(oA));
        processOnhand(list);
    }

    static void processOnhand(List<OnHand> list) {
        OnhandP p = new OnhandP();
        for (OnHand oh : list) {
            String org = oh.org;
            String sub = oh.subInventory;
            Item item = oh.item;
            int qty = oh.quantity;

            Set<Org> orgSet = p.getOrg();
            Org org1 = new Org(org);
            if (!orgSet.contains(org1)) {
                orgSet.add(org1);
            } else {
                Iterator<Org> it = orgSet.iterator();
                while (it.hasNext()) {
                    Org or = it.next();
                    if (or.equals(org1)) {
                        org1 = or;
                    }
                }
            }
            Sub sub1 = new Sub(sub);
            Set<Sub> subSet = org1.getSub();
            if (!subSet.contains(sub1)) {
                subSet.add(sub1);
            } else {
                Iterator<Sub> it = subSet.iterator();
                while (it.hasNext()) {
                    Sub s = it.next();
                    if (s.equals(sub1)) {
                        sub1 = s;
                    }
                }
            }

            Map<Item, Integer> itemsMap = sub1.getItems();
            if (!itemsMap.containsKey(item)) {
                itemsMap.put(item, qty);
            } else {
                itemsMap.put(item, itemsMap.get(item) + qty);
            }
        }
        System.out.println(p);
    }
}

class OnhandP {
    Set<Org> orgs;

    public OnhandP() {
        orgs = new HashSet<>();
    }

    public Set<Org> getOrg() {
        return orgs;
    }
}

class Org {
    String name;
    Set<Sub> subs;

    public Org(String name) {
        subs = new HashSet<>();
        this.name = name;
    }

    public Set<Sub> getSub() {
        return subs;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        Org s = (Org) o;
        return s.name.equals(this.name);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.name);
    }
}

class Sub {
    String name;
    String item;
    Map<Item, Integer> itemsMap;

    public Sub(String name) {
        this.name = name;
        this.itemsMap = new HashMap<>();
    }

    void setItem(String name, Integer qty) {
        if (!itemsMap.containsKey(name)) {
            itemsMap.put(new Item(name), qty);
        }
    }

    Map<Item, Integer> getItems() {
        return itemsMap;
    }

    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        Sub s = (Sub) o;
        return s.name.equals(this.name);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(this.name);
    }
*/}
