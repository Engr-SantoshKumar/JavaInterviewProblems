package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 4/1/19
 * BADABC
 * ABC
 *        A  B  C  D  E  F .........
 * counts[1, 1, 1, 0, 0, 0..........
 *
 * now                       A  B  C  D  E  F .........        total
 * start               counts[1, 1, 1, 0, 0, 0..........         3
 * * i=0   B           counts[1, 0, 1, 0, 0, 0..........         2
 * * i=1   A           counts[0, 0, 1, 0, 0, 0..........         1
 * * i=2   D           counts[0, 0, 1, -1, 0, 0..........        1  BAD, adding D makes D=-1
 * * i=2   D           counts[0, 1, 1, -1, 0, 0..........        1  BAD, remove B ,makes B=1
 * * i=3   A           counts[-1, 1, 1, -1, 0, 0..........       1  ADA, added A, makes A=-1
 * * i=3   A           counts[0, 1, 1, -1, 0, 0..........        1  DA, remove A, makes A=0
 * * i=4   B           counts[0, 0, 1, -1, 0, 0..........        1  DAB, add B, makes B=0
 * * i=4   B           counts[0, 0, 1, 0, 0, 0..........         1 AB remove D, makes D=0
 * * i=5   C           counts[0, 0, 0, 0       ..........        1 ABC add C, makes C=0    res=3
 * * i=5   C           counts[1, 0, 0, 0       ..........        1 remove A not required
 *
 *
 */
public class _14_TARZAN {

    public static void main(String args[]) {

        int x = 5;
        System.out.println(" find " + (--x == 5));
        System.out.println(" --x = " + (--x));
        System.out.println(" x-- = " + (x--));
        System.out.println(x);
        String pat = "TAR";
        //String pat = "ABC";
        String s = "TAZTARRTARZAN";
        //String s = "BADABC";
        perform2(s, pat);
        findAnagrams(s, pat);
        findAnagrams2(s, pat);
    }
    // THIS IS SIMPLIFIED VERSION OF FINDaNAGRAMS AND IS WORKING VERY GOOD
    static List<Integer> findAnagrams2(String s, String p) {
        int[] counts = new int[256];                            // Total counts for chars needed
        for (char c : p.toCharArray())
            (counts[c])++;
        int n = s.length(), m = p.length(), total = m;
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            int cnt = counts[s.charAt(i)];


            if (cnt > 0) { // means this was part of pattern then total--
                total--;
            }
            counts[s.charAt(i)]--; // "A" always do -- to the current char in counts array
            // for char that are 1 e.g required then do 0 for others that are already 0 do -1/-2...
            System.out.println("=========================== i "+i+".."+s.charAt(i));
            print(counts);

            if (i >= m - 1) { // if pat len is m=3 and i is at 2 or3 meaning 4th char we need to
                             // shrink
                if(total == 0 ){
                    result.add(i-m+1);
                }
                // now shrink the right side by retaining the counter
                cnt = counts[s.charAt(i - m + 1)]; // if cnt==-1 meaning it was not a required char
                if(cnt >= 0){ // if it is 0 means there was 1 earlier but due to "A" it became 0
                    total++;
                }
                counts[s.charAt(i - m + 1)]++;
                print(counts);
            }
        }
        System.out.println(" in find anam methods " + Arrays.toString(result.toArray()));
        return result;
    }

    static List<Integer> findAnagrams(String s, String p) {
        int[] counts = new int[256];                            // Total counts for chars needed
        for (char c : p.toCharArray())
            (counts[c])++;
        int n = s.length(), m = p.length(), total = m;
        List<Integer> result = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            if (counts[s.charAt(i) ]-- > 0)
                total--;             // 1. Add right border
            if (i >= m - 1) {
                if (total == 0)
                    result.add(i - m + 1);          // 2. Update Result
                if (++counts[s.charAt(i - m + 1) ] > 0)
                    total++; // 3. Remove left border
            }
            System.out.println(" ..  " + Arrays.toString(counts));
        }
        System.out.println(" in find anam methods " + Arrays.toString(result.toArray()));
        return result;
    }

    static void print(int[] counts){
        String s = "["+(counts['A'])+", "+(counts['B'])+", "+(counts['C'])+", "+(counts['D'])+", ";
        System.out.println(s);
    }

    // THis only WORKS WHEN UNIQUE STR IN PATTERN AND UNIQUE IN STRING
    static void perform2(String s, String pat) {
        Set<Character> pSet = new HashSet<>();
        for (char c : pat.toCharArray()) {
            pSet.add(c);
        }
        Set<Character> ss = new HashSet<>();
        int start = 0;
        int end = 0;
        for (int i = 0; i < s.length(); i++) {
            if (pSet.contains(s.charAt(i))) {
                if (ss.size() == 0) {
                    start = i;
                }
                ss.add(s.charAt(i));
            } else {
                ss.clear();
            }
            if (pSet.size() == ss.size()) {
                end = i;
                System.out.println(" index of match " + start + ", " + end);
                ss.clear();
                i = start + 1; // very imp to handle overlapping results
            }
        }
    }

}
