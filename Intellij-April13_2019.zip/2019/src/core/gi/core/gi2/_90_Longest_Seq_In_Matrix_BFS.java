package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 3/31/19
 * ****** Don't pass result as a param to BFS it always keep changing as it is a local variable
 * Find the longest sequence length from nxn matrix
 * 129
 * 538
 * 467
 * <p>
 * This contains three sequences of adjacent numbers
 * [1,2,3],[4,5],[6,7,8,9] longest sequence length is 4
 */
public class _90_Longest_Seq_In_Matrix_BFS {
    static int[] R = {0, 0, -1, 1};
    static int[] C = {1, -1, 0, 0};
    static List<Integer> res = new ArrayList<>();

    public static void main(String args[]) {
        int[][] M = new int[][]{
                {1, 2, 9},
                {5, 3, 8},
                {4, 6, 7}};
        bfs(M);
        System.out.println(" final result:" + Arrays.toString(res.toArray()));
    }

    static void bfs(int[][] M) {
        for (int row = 0; row < M.length; row++) {
            for (int col = 0; col < M[0].length; col++) {
                Set<Cell> visited = new HashSet<>();
                bfs(row, col, M, visited);
            }
        }
    }

    static void bfs(int row, int col, int[][] M, Set<Cell> visited){
        List<Integer> path1 = new ArrayList<>();
        path1.add(M[row][col]);
        Cell root = new Cell(row, col, path1);
        visited.add(root);
        Queue<Cell> q = new ArrayDeque<>();
        q.offer(root);

        while(!q.isEmpty()){
            Cell cell = q.poll();
            for (int i = 0; i < R.length; i++) {
                int r = cell.row + R[i];
                int c = cell.col + C[i];
                List<Integer> path = new ArrayList<>();
                path.addAll(cell.path);
                Cell newCell = new Cell(r, c, path);
                if (isValidCell(M, r, c, visited, newCell)) {
                    path.add(M[r][c]);
                    if (M[r][c] - M[cell.row][cell.col] == 1) {
                        if (path.size() > res.size()) {
                            res = path;
                            System.out.println(" result updated to: " + Arrays.toString(res.toArray()));
                        }
                        q.offer(newCell);
                    }
                }
            }
        }
    }

    static boolean isValidCell(int[][] M, int row, int col, Set<Cell> visited, Cell cell) {
        return row >= 0 && row < M.length && col >= 0 && col < M[0].length && !visited.contains(cell);
    }
}
