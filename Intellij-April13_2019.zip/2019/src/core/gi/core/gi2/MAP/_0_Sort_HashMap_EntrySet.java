package core.gi.core.gi2.MAP;

import java.util.*;

/**
 * Sort a map by its entry, needs following
 * First convert map.entrySet() into a list - O(N)
 * then sort this list - O(NlogN)
 * so total time is N + NlogN ~ NlogN
 *
 * ** cannot pass entrySet() directly to Collections.sort() because it expects only lists
 * why java uses Merge sort for object sort and Quick sort for primitives
 * https://stackoverflow.com/questions/15154158/why-collections-sort-uses-merge-sort-instead-of-quicksort
 */
public class _0_Sort_HashMap_EntrySet {
    public static void main(String args[]){

        // emp, salary
        Map<Employee, Integer> map = new HashMap<>();
        map.put(new Employee(1,"ZAZA"), 5000);
        map.put(new Employee(2,"YAYA"), 6000);
        map.put(new Employee(3,"XAXA"), 7000);
        map.put(new Employee(4,"DADA"), 8000);
        map.put(new Employee(5,"CACA"), 9000);
        map.put(new Employee(6,"BABA"), 9500);
        List<Map.Entry<Employee, Integer>> list =
                new ArrayList<Map.Entry<Employee, Integer>>(map.entrySet());
        // you cannot directly pass map.entrySet() to collectsons directly becuase it it not right.
        Collections.sort(list,
                new Comparator<Map.Entry<Employee, Integer>>(){
            @Override
            public int compare(Map.Entry<Employee, Integer> a, Map.Entry<Employee, Integer> b){
                return a.getKey().name.compareTo(b.getKey().name);
            }
        });

        // UNSORTED
        System.out.println(" Before sorting ");
        for(Map.Entry<Employee, Integer> entry : map.entrySet()){
            System.out.println("["+entry.getKey().id+", "+entry.getKey().name+"]"+" : "+entry.getValue());
        }

        // SORTED
        System.out.println(" After sorting Full map \"on Names\" Entries looks like\n " +
                "{[Employee]," +
                " Salary}" +
                "  ");
        for(Map.Entry<Employee, Integer> entry: list){
            System.out.println("["+entry.getKey().id+", "+entry.getKey().name+"]"+" : "+entry.getValue());
        }
    }
}
class Employee{
    Integer id;

    public Employee(Integer id, String name) {
        this.id = id;
        this.name = name;
    }

    String name;
}

/*
 Before sorting
[5, CACA] : 9000
[1, ZAZA] : 5000
[6, BABA] : 9500
[3, XAXA] : 7000
[4, DADA] : 8000
[2, YAYA] : 6000
 After sorting Full map "on Names" Entries looks like
 {[Employee], Salary}
[6, BABA] : 9500
[5, CACA] : 9000
[4, DADA] : 8000
[3, XAXA] : 7000
[2, YAYA] : 6000
[1, ZAZA] : 5000
*/
