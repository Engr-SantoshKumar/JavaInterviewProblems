package core.gi.core.gi2.MAP;

import java.util.*;

/**
 * Date: 4/5/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _0_Sort_HashMap_Keys_Only {
    public static void main(String args[]){ // emp, salary
        Map<Employee, Integer> map = new HashMap<>();
        map.put(new Employee(1,"ZAZA"), 5000);
        map.put(new Employee(2,"YAYA"), 6000);
        map.put(new Employee(3,"XAXA"), 7000);
        map.put(new Employee(4,"DADA"), 8000);
        map.put(new Employee(5,"CACA"), 9000);
        map.put(new Employee(6,"BABA"), 9500);
        List<Employee> list1  = new ArrayList<>(map.keySet());
        Collections.sort(list1,
                new Comparator<Employee>(){
                    @Override
                    public int compare(Employee a, Employee b){
                        return a.name.compareTo(b.name);
                    }
                });

        System.out.println(" Before sorting ");
        for(Map.Entry<Employee, Integer> entry : map.entrySet()){
            System.out.println("{"+entry.getKey().id+", "+entry.getKey().name +"} : "+entry.getValue());
        }
        // SORTED
        System.out.println(" After sorting ** Notice no salary can be here,\n because we only " +
                "are " +
                "sorting the key and if you need value you have to do \na call to map for each key");
        for(Employee entry: list1){
            System.out.println(entry.id+" : "+entry.name);
        }

        System.out.println(" FETCH SALARY NOW USING A CALL HERE SINCE WE DID NOT FETCHED ENTRY");
        for(Employee entry: list1){
            System.out.println(entry.id+" : "+entry.name+" : "+map.get(entry));
        }
    }
}
/*
 Before sorting
{5, CACA} : 9000
{1, ZAZA} : 5000
{6, BABA} : 9500
{3, XAXA} : 7000
{4, DADA} : 8000
{2, YAYA} : 6000
 After sorting ** Notice no salary can be here,
 because we only are sorting the key and if you need value you have to do
a call to map for each key
6 : BABA
5 : CACA
4 : DADA
3 : XAXA
2 : YAYA
1 : ZAZA
 FETCH SALARY NOW USING A CALL HERE SINCE WE DID NOT FETCHED ENTRY
6 : BABA : 9500
5 : CACA : 9000
4 : DADA : 8000
3 : XAXA : 7000
2 : YAYA : 6000
1 : ZAZA : 5000

Process finished with exit code 0
*/
