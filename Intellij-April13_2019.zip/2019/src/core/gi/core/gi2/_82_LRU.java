package core.gi.core.gi2;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;

/**
 * Date: 4/6/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _82_LRU {
    public static void main(String args[]) {
        LRU cache = new LRU(2);
        cache.put(1, 1);
        cache.put(2, 2);
        cache.get(1);       // returns 1
        cache.put(3, 3);    // evicts key 2
        System.out.println(" get 2 from cache " +cache.get(2));       // returns -1 (not found)
        cache.put(4, 4);    // evicts key 1
        cache.get(1);       // returns -1 (not found)
        cache.get(3);       // returns 3
        cache.get(4);       // returns 4
    }
}

class LRU {
    int capacity;
    int size = 0;
    LinkedList<Node> ll = new LinkedList<>();
    Map<Integer, Node> map = new HashMap<>();

    public LRU(int capacity) {
        if (capacity < 1) {
            System.out.println(" not good");
        }
        this.capacity = capacity;
    }

    public void put(int key, int value) {
        // check if cache is full, if yes evict, if key exist make it most recent
        if (isPresentInCache(key)) {
            makeMostRecent(key);
            return;
        } else {
            if (isFull()) {
                evict();
            }
            addNew(key, value);
        }
        print();
    }

    public void addNew(int key, int value) {
        Node newNode = new Node(value, key);
        map.put(key, newNode);
        ll.addFirst(newNode);
        size++;
    }

    public int get(int key) {
        if (isPresentInCache(key)) {
            Node n = map.get(key);
            return n.data;
        }
        return -1;
    }

    public boolean isFull() {
        return size >= capacity;
    }

    public void evict() {
        map.remove(ll.getLast().key);
        ll.removeLast();
        size--;
    }

    public void makeMostRecent(int key) {
        Node node = map.get(key);
        ll.remove(node);
        ll.addFirst(node);
    }

    public boolean isPresentInCache(int key) {
        return map.containsKey(key);
    }

    void print() {
        Iterator<Node> it = ll.iterator();
        while (it.hasNext()) {
            System.out.print(it.next().data + " ->");
        }
        System.out.println();
    }

    class Node {
        int data;
        int key;

        public Node(int data, int key) {
            this.data = data;
        }
    }

}
