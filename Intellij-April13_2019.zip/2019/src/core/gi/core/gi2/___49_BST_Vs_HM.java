package core.gi.core.gi2;

/**
 * todo
 * SINGLETON PATTERN
 * synchronized keyword how to use and where to put it
 * CASTING CONCEPTS
 * MATCHER AND REGEX
 * BITCOUNT CONCEPT, https://www.ideserve.co.in/learn/find-the-element-that-appears-once-in-an-array
 * @Autovalue
 * rest web service basics and methods
 *
 *
 */
public class ___49_BST_Vs_HM {
}
