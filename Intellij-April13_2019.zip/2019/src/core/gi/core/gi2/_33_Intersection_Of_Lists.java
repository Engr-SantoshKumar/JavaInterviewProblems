package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Solution:
 * Iterator 1 = [0,1,2,3,4,5,6]
 * Iterator 2 = [2,6,7,8,9,11]
 * Remember:
 */
public class _33_Intersection_Of_Lists {
    public static void main(String args[]) {
        Integer[] a1 = new Integer[]{0, 1, 2, 3, 4, 5, 6};
        Integer[] a2 = new Integer[]{2, 6, 7, 8, 9, 11};
        testFor(a1, a2);
        testFor(new Integer[]{1}, new Integer[]{2});
        testFor(new Integer[]{1}, new Integer[]{1});
        testFor(new Integer[]{1}, new Integer[]{});
        testFor(new Integer[]{}, new Integer[]{});
    }

    static void testFor(Integer[] a1, Integer[] a2){
        List<Integer> l1 = Arrays.asList(a1);
        List<Integer> l2 = Arrays.asList(a2);
        List<Integer> result = intersection(l1, l2);
        System.out.println(" ------------- \n input : "+Arrays.toString(a1));
        System.out.println(" input : "+Arrays.toString(a2));
        System.out.println(" result : " + Arrays.toString(result.toArray()));
    }

    static List<Integer> intersection(List<Integer> l1, List<Integer> l2) {
        List<Integer> result = new ArrayList<>();
        Iterator<Integer> i1 = l1.iterator();
        Iterator<Integer> i2 = l2.iterator();

        int s1 = Integer.MAX_VALUE;
        int s2 = Integer.MAX_VALUE;
        if (i1.hasNext()) {
            s1 = i1.next();
        }
        if (i2.hasNext()) {
            s2 = i2.next();
        }
        if(s1 == Integer.MAX_VALUE || s2 == Integer.MAX_VALUE){
            return new ArrayList<Integer>();
        }
        while (i1.hasNext() && i2.hasNext()) {
            if (s1 == s2) {
                result.add(s1);
                s1 = i1.next();
                s2 = i2.next();
            } else if (s1 < s2) {
                s1 = i1.next();
            } else {
                s2 = i2.next();
            }
        }
        if(s1 == s2){
            result.add(s1);
        }
        return result;
    }
}
