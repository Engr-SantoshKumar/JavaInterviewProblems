package core.gi.core.gi2;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * This is not correct to have prune method inside the custom class because when HM does not says
 * int the Entry<K,V> K or V should be comparable, its user who has to take care of it
 * if he does not pass the comparable objects to entry then the result is out of control
 * that is why we extends comparable in our objects or write comparator
 */
public class _91_HashMap_With_Expiring_Values {
    public static void main(String args[]) {
        MHM<Integer, Long> map = new MHM<>();
        //map.put()
        Long x = 5L;
        Long y = 6L;
        x.compareTo(y);
        long currTime = 6000L;
        map.put(3, 3000L);
        map.put(4, 4000L);
        map.put(6, 6000L);
        map.put(7, 7000L);
        map.put(8, 8000L);
        map.prune(1000L, currTime);

       for(Map.Entry<Integer, Long > entry : map.map.entrySet()){
           System.out.println(" "+entry.getKey()+" : "+entry.getValue());
       }
    }

}
class MHM<K extends Comparable, V extends Comparable>  extends ConcurrentHashMap<K, V>{
    ConcurrentHashMap<K, V> map;
    public MHM(){
        map = new ConcurrentHashMap<K, V>();
    }
    @Override
    public V put(K key, V value){
        if(map.containsKey(key) && map.get(key).compareTo(value) > 0){
            map.put(key, value);
        }
        if(!map.containsKey(key)){
            map.put(key, value);
        }
        return value;
    }

    void prune(long timeout, long currentTime){
        for(Map.Entry<K, V> entry : map.entrySet()){
            System.out.println("here"+currentTime+"  "+((Long)entry.getValue()+timeout));
            if(currentTime > (Long)entry.getValue()+timeout){
                System.out.println(" removing ");
                map.remove(entry.getKey());
            }
            System.out.println(" map.size "+map.size());
        }
    }
}
