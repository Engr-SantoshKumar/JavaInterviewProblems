package core.gi.core.gi2;

import java.util.Arrays;

/**
 * [1, 4, 6, 8, 8, 10, 12, 15, 24, 45]
 *  key 1 iter: 0 rec:0
 *  key 4 iter: 1 rec:1
 *  key 6 iter: 2 rec:2
 *  key 8 iter: 4 rec:4
 *  key 8 iter: 4 rec:4
 *  key 10 iter: 5 rec:5
 *  key 12 iter: 6 rec:6
 *  key 15 iter: 7 rec:7
 *  key 24 iter: 8 rec:8
 *  key 45 iter: 9 rec:9
 */
public class _0_Binary_Search {
    public static void main(String args[]) {
        int ar[] = {1, 4, 45, 6, 10, 24, 8, 12, 8, 15};
        Arrays.sort(ar);
        System.out.println(Arrays.toString(ar));
        for (int x : ar) {
            testFor(ar, x);
        }
    }

    static void testFor(int[] ar, int key) {

        System.out.println(" key " + key + " iter: " + binarySearch(ar, key) + " rec:" +
                binarySearchRec(ar, key, 0, ar.length - 1));
    }

    static int binarySearch(int[] ar, int key) {
        if (ar == null || ar.length == 0) {
            return -1;
        }
        int lo = 0;
        int hi = ar.length - 1;

        while (lo <= hi) { // imp check for lo<=hi else in given array u cannot find 2nd,
            int mid = (lo + hi) / 2;// last or mid element element
            if (key == ar[mid]) {
                return mid;
            } else if (key < ar[mid]) {
                hi = mid - 1;
            } else if (key > ar[mid]) {
                lo = mid + 1;
            }
        }
        return -1;
    }

    static int binarySearchRec(int[] ar, int key, int lo, int hi) {
        if (hi < lo) {
            return -1;
        }
        int mid = (lo + hi) / 2;
        if (key == ar[mid]) {
            return mid;
        }
        if (key < ar[mid]) {
            return binarySearchRec(ar, key, lo, mid - 1);
        } else {
            return binarySearchRec(ar, key, mid + 1, hi);
        }
    }
}
