package core.gi.core.gi2;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/**
 * Date: 3/31/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _33_Intersection_Of_Iterator {
    public static void main(String args[]) {
        Integer[] a1 = new Integer[]{0, 1, 2, 3, 4, 5, 6};
        Integer[] a2 = new Integer[]{2, 6, 7, 8, 9, 11};
        testFor(a1, a2);
        testFor(new Integer[]{1}, new Integer[]{2});
        testFor(new Integer[]{1}, new Integer[]{1});
        testFor(new Integer[]{1}, new Integer[]{});
        testFor(new Integer[]{}, new Integer[]{});
    }

    static void testFor(Integer[] a1, Integer[] a2){
        List<Integer> l1 = Arrays.asList(a1);
        List<Integer> l2 = Arrays.asList(a2);
        System.out.println(" ------------- \n input : "+Arrays.toString(a1));
        System.out.println(" input : "+Arrays.toString(a2));
        System.out.println(" result : " );
        IntersectionIterator it = new IntersectionIterator(l1.iterator(), l2.iterator());
        while(it.hasNext()){
            System.out.print(", "+it.next());
        }
        System.out.println();
        /*List<Integer> result = intersection(l1, l2);
        System.out.println(" ------------- \n input : "+Arrays.toString(a1));
        System.out.println(" input : "+Arrays.toString(a2));
        System.out.println(" result : " + Arrays.toString(result.toArray()));
    */}
}
class IntersectionIterator<T extends Comparable> implements Iterator<T >{
    Iterator<T> it1; Iterator<T> it2;
    T next;
    public IntersectionIterator(Iterator it1, Iterator it2){
        this.it1 = it1;
        this.it2 = it2;
        advance();
    }
    @Override
    public boolean hasNext() {
        return next != null;
    }

    @Override
    public T next() {
        if(!hasNext()){
            throw new NoSuchElementException();
        }

       T temp = next;
        advance();
        return temp;
    }

    private void advance(){
        //System.out.println(" in advance");
        next = null;
        T a = null;
        T b = null;
        while(it1.hasNext() && it2.hasNext()){
            if(a == null && b == null){
                a = it1.next();
                b = it2.next();
                continue; // if no continue then at line it1.next(); it will fetch another token
            }             // and if there is no hasNext then NPE
            if(a.compareTo(b) == 0){
              next = a;
              break;
            }else if(a.compareTo(b) < 0){
                a = it1.next();
            }else{
                b= it2.next();
            }
        }//{4, 5, 6}, {2,6,7} it1->6 it2->6
        // when it go back in above loop since it1.hasNext is False, so we loose this last elem
        if(a != null && b != null && a.compareTo(b) == 0){// this cond help to get that
            next = a; // are same then
        }
       // System.out.println("next  "+next);
    }
}
