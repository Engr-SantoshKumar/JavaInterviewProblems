package core.gi.core.gi2;

import java.util.Arrays;

/**
 * Date: 4/1/19
 * <p>
 * MAJORITY ELEMENT IS AN ELEMENT WHOSE COUNT IN ARRAY IS (> N/2)
 * Input: arr[] = {1, 1, 2, 4, 4, 4, 6, 6} Output: 4
 * https://www.ideserve.co.in/learn/find-majority-element-in-an-array
 */
public class _12_Majority_Element {
    public static void main(String args[]) {
        //int[] ar = {1, 1, 2, 4, 4, 4, 6, 6, 6, 6, 1};
        int[] ar = {1, 2, 3};
        System.out.println(".. ides " + getMajorityElement(ar));

        //testFor(new int[]{});
        testFor(new int[]{1});
        testFor(new int[]{1, 2});
        testFor(new int[]{1, 2, 3});
        testFor(new int[]{1, 2, 3, 4});
        testFor(new int[]{1, 2, 3, 4, 1});
        testFor(new int[]{1, 2, 3, 4, 1, 1});
        testFor(new int[]{1, 2, 3, 4, 1, 1, 4, 4,});
        testFor(new int[]{1, 1, 1, 1, 1, 1, 1, 1, 1});

        testFor(new int[]{1, 2, 3, 4, 1, 2, 5}); // gives o/p as 5 which does not seems right
    }

    static void testFor(int[] ar) {
        System.out.println(" \n ------------------------input is \n" + Arrays.toString(ar));
        getMajorityElement(ar);
    }


    public static Integer getMajorityElement(int[] array) {

        if (array == null || array.length == 0) {
            return null;
        }

        // when count == 0 then update candidate and count=1
        // when count !=0, do not update candidate, but if
        // candidate == curr Element then count++
        // else count--;

        // Step 1: Find max element
        Integer candidate = null;
        int count = 0;
        for (int i = 0; i < array.length; i++) {
            if (count == 0) {
                candidate = array[i];
                count = 1;
                continue;
            } else {
                if (candidate == array[i]) {
                    count++;
                } else {
                    count--;
                }
            }
        }

        System.out.println(" book's candidate :" + candidate + " count : " + count);
        if (count == 0) {
            return null;
        }

        // Step 2: Check if candidate is majority element
        count = 0;
        for (int i = 0; i < array.length; i++) {
            if (candidate == array[i]) {
                count++;
            }
        }
        return (count > array.length / 2) ? candidate : null;
    }
}
