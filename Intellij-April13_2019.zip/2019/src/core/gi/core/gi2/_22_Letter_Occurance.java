package core.gi.core.gi2;

import java.util.*;

/**
 *Find frequency of Chars in the string and print in descending order
 */
public class _22_Letter_Occurance {
    public static void main(String args[]) {
        String s = "WOWTHISISSOGOOD";
        int i = 65;
        char c = (char) i; // prints "A"
        System.out.println(c);
        collectEasy(s);
        collect(s);
        collect2(s);
    }

    static void collectEasy(String s) {
        Map<Character, Integer> map = new HashMap<>();
        for (char c : s.toCharArray()) {
            if (!map.containsKey(c)) {
                map.put(c, 0);
            }
            map.put(c, map.get(c) + 1);
        }
        PriorityQueue<CC> pq = new PriorityQueue<>(new Comparator<CC>() {
            @Override
            public int compare(CC a, CC b) {
                return b.count - a.count;
            }
        });

        for (Map.Entry<Character, Integer> entry : map.entrySet()) {
            pq.offer(new CC(entry.getKey(), entry.getValue()));
        }

        while (!pq.isEmpty()) {
            CC top = pq.poll();
            System.out.println(top.c + " : " + top.count);
        }

    }

    static void collect(String s) {
        int[] carr = new int[127];
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            carr[c]++;
        }
        System.out.println(Arrays.toString(carr));

        PriorityQueue<CC> pq = new PriorityQueue<>(new Comparator<CC>() {
            @Override
            public int compare(CC a, CC b) {
                return b.count - a.count;
            }
        });
        for (int i = 0; i < carr.length; i++) {
            if (carr[i] > 0) {
                pq.offer(new CC((char) i, carr[i]));
            }
        }

        while (!pq.isEmpty()) {
            CC top = pq.poll();
            System.out.println(top.c + " : " + top.count);
        }
    }

    static void collect2(String s) {
        int[] carr = new int[26];
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            carr[c - 'A']++;
        }
        System.out.println(Arrays.toString(carr));

        PriorityQueue<CC> pq = new PriorityQueue<>(new Comparator<CC>() {
            @Override
            public int compare(CC a, CC b) {
                return b.count - a.count;
            }
        });
        for (int i = 0; i < carr.length; i++) {
            char curr = (char) (i + 'A');
            int count = carr[i];
            if (count > 0) {
                pq.offer(new CC(curr, count));
            }
        }

        while (!pq.isEmpty()) {
            CC top = pq.poll();
            System.out.println(top.c + " : " + top.count);
        }
    }

    static class CC {
        Character c;
        int count;

        public CC(Character c, int count) {
            this.c = c;
            this.count = count;
        }

    }
}
