package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 3/30/19
* SO many conditions required with DFS, better to go with BFS or try to build similar Pair object
 * where you store path in the object itself and use in DFS
 */
public class _83_All_Flights_From_Src_Dest {
    public static void main(String args[]){
        Flight a = new Flight("SFO", "LAX");
        Flight b = new Flight("SFO", "DEN");
        Flight c = new Flight("SFO", "NYC");
        Flight d = new Flight("LAX", "DEN");
        Flight e = new Flight("LAX", "IAH");
        Flight f = new Flight("DEN", "NYC");
        Flight g = new Flight("IAH", "NYC");
        Flight h = new Flight("DEN", "ABC");
        List<Flight> list = new ArrayList<>();
        list.add(h);list.add(a);list.add(b);list.add(c);list.add(d);list.add(e);list.add(f);list.add(g);

        // create map or graph
        Map<String, List<String>> G = new LinkedHashMap<>();
        for(Flight flight : list){
            List<String> dest;
            if(G.containsKey(flight.start)){
                dest = G.get(flight.start);
            }else{
                dest = new ArrayList<String>();
            }
            dest.add(flight.dest);
            G.put(flight.start, dest);
        }

        List<LinkedList<String>> result = dfs("SFO", "NYC", G);
        for(LinkedList<String> ll : result){
            System.out.println(ll);
        }
        //System.out.println(Arrays.toString(result.toArray()));
    }

    static List<LinkedList<String>> dfs(String source, String dest, Map<String, List<String>> G){

        List<LinkedList<String>> result = new ArrayList<>();
        for(String src : G.keySet()){
            if(src.equals(source)){
                    Set<String> visited = new HashSet<>();
                    LinkedList<String> path =  new LinkedList<String>();
                    path.addLast(source);
                    dfs(src, dest, G, visited, path, result);

            }
        }
        return result;
    }
    static void dfs(String source, String destination, Map<String, List<String>> G,
                    Set<String> visited,
                    LinkedList<String> ll, List<LinkedList<String>> result){
        if(visited.contains(source)){
            return;
        }
        visited.add(source);
        if(G.get(source) == null){ // to handle "ABC" as map does not contain key "ABC"
            return;
        }
        for(String d : G.get(source)){
           /* if(d == null){
                return;
            }*/
            ll.addLast(d);
            if(d.equals(destination)){
                result.add(new LinkedList(ll));
                ll.removeLast();
                visited.clear(); // this is imp, if SFO-> LAX-> DEN->NYC is done DEN is in visited
                continue;        // then SFO-> DEN->NYC will not move fwd.
            }
            dfs(d, destination, G, visited, ll, result);
            ll.removeLast(); // if removed [SFO, LAX, DEN, IAH, NYC] should be [SFO, LAX, IAH, NYC]
        }

    }

    /*static List<LinkedList<String>> dfs(String source, String dest, Map<String, List<String>> G){

        List<LinkedList<String>> result = new ArrayList<>();
        for(String src : G.keySet()){
            if(src.equals(source)){

                for(String d : G.get(source)){
                    Set<String> visited = new HashSet<>();
                    LinkedList<String> path =  new LinkedList<String>();
                    path.addLast(source);
                    path.addLast(d);
                    if(d.equals(dest)){
                        result.add(path);
                        continue;
                    }
                    dfs(d, dest, G, visited, path, result);
                }

            }
        }
        return result;
    }
    static void dfs(String source, String destination, Map<String, List<String>> G,
                 Set<String> visited,
                    LinkedList<String> ll, List<LinkedList<String>> result){
        if(visited.contains(source)){
            return;
        }
        visited.add(source);
        for(String d : G.get(source)){
            if(d == null){
                return;
            }
            ll.addLast(d);
            if(d.equals(destination)){
                result.add(new LinkedList(ll));
                ll.removeLast();
                continue;
            }
            dfs(d, destination, G, visited, ll, result);
            ll.removeLast(); // if removed [SFO, LAX, DEN, IAH, NYC] should be [SFO, LAX, IAH, NYC]
        }

    }*/
}
class Flight{
    public String getStart() {
        return start;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public String getDest() {
        return dest;
    }

    public void setDest(String dest) {
        this.dest = dest;
    }

    public Flight(String start, String dest) {
        this.start = start;
        this.dest = dest;
    }

    String start;
    String dest;
}