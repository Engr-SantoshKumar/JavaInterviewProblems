package core.gi.core.gi2;

/**
 * Date: 4/4/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _21_Share_Stock_Price_Drop {
    public static void main(String args[]) {
        double[] prices = {21.0, 24.0, 26.0, 25.0, 24.0, 23.0, 24.0, 22.0, 12.0, 27.0};
        findDropWithOneTransation(prices);
    }

    static void findDropWithOneTransation(double[] ar) {
        //double drop = Double.MIN_VALUE;
        double buy = 0;
        double sell = 0;
        int buyIdx = 0;
        int sellIdx = 0;
        double maxDrop = 0D;
        int[] result = new int[2];

        for (int i = 1; i < ar.length; i++) {
            double drop = ar[buyIdx] - ar[i];
            if( drop > maxDrop){
                    sellIdx = i;
                    maxDrop = drop;
                    result[0] = buyIdx;
                    result[1] = sellIdx;
            }
            buyIdx = ar[i] > ar[buyIdx] ? i : buyIdx;
        }
        System.out.println(" max drop " + maxDrop + " s " +result[0] + " e " + result[1]);
    }

    // this may be right implementation
    static void findDropWithMultiTransation(double[] ar) {
        double drop = Double.MIN_VALUE;
        int buy = 0;
        int sell = 0;
        double maxDrop = 0D;
        int[] result = new int[2];

        for (int i = 1; i < ar.length; i++) {
            if (ar[i] - ar[i - 1] < 0) {
                sell = i;
                if (ar[buy] - ar[sell] > maxDrop) {
                    result = new int[]{buy, sell};
                    maxDrop = ar[buy] - ar[sell];
                }
                //maxDrop = Math.max(maxDrop, ar[s] - ar[e]);
            } else {
                buy = i;
            }

        }
        System.out.println(" max drop " + maxDrop + " s " + result[0] + " e " + result[1]);
    }
}
