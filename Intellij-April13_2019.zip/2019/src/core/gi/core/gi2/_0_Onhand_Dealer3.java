package core.gi.core.gi2;
import core.gi.InvalidException;

import java.util.*;
/**
 * Date: 4/10/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _0_Onhand_Dealer3 {
    public static void main(String args[]) throws Exception{

        Onhand o1 = new Onhand(1L, new Item("Book"), "RCV", "ORG1", 2);
        Onhand o2 = new Onhand(2L, new Item("Book"), "stores", "ORG1", 10);
        Onhand o3 = new Onhand(3L, new Item("Book"), "staging", "ORG1", 4);
        Onhand o4 = new Onhand(4L, new Item("Pencil"), "stores", "ORG1", 5);
        Onhand o5 = new Onhand(5L, new Item("Pencil"), "staging", "ORG1", 6);

        Onhand o11 = new Onhand(6L, new Item("Book"), "RCV", "ORG2", 1);
        Onhand o12 = new Onhand(7L, new Item("Book"), "stores", "ORG2", 9);
        Onhand o13 = new Onhand(8L, new Item("Book"), "staging", "ORG2", 3);
        Onhand o14 = new Onhand(9L, new Item("Pencil"), "stores", "ORG2", 4);
        Onhand o15 = new Onhand(10L, new Item("Pencil"), "staging", "ORG2", 5);
        Onhand[] oA = new Onhand[]{o1, o2, o3, o4, o5, o11, o12, o13, o14, o15};
        List<Onhand> list = new ArrayList<Onhand>(Arrays.asList(oA));
        processOnhand(list);
    }

    static void processOnhand(List<Onhand> list) throws Exception{
        OnhandP p = OnhandP.getInstance();
        for (Onhand oh : list) {
            p.createOnhand(oh.org, oh.subInventory, oh.item, oh.quantity);
        }
        Collection<Org> col = p.getOrgMap();
        System.out.println(col);
    }
    static class Onhand {
        Long onHandId;
        Item item;
        String subInventory;
        Integer quantity;
        String org;
        public Onhand(Long onHandId, Item item, String subInventory, String org, Integer quantity) {
            this.onHandId = onHandId;
            this.item = item;
            this.subInventory = subInventory;
            this.quantity = quantity;
            this.org = org;
        }
    }
}

class OnhandP {
    private static Map<String, Org> orgs;
    private static OnhandP instance;
    public static OnhandP getInstance() {
        if(instance == null){
            instance = new OnhandP();
        }
        orgs = new HashMap<>();
        return instance;
    }
    void createOnhand(String orgName, String subInName, Item item, Integer qty){
        Org org = addOrg(orgName);
        Sub sub = org.addSub(subInName);
        sub.addItem(item, qty);
    }

    public Org addOrg(String orgName){
        if(!hasOrg(orgName)){
            orgs.put(orgName, new Org(orgName));
        }
        return orgs.get(orgName);
    }

    boolean hasOrg(String orgName){
        return orgs.containsKey(orgName);
    }

    Collection<Org> getOrgMap(){
        return orgs.values();
    }

}

class Org {
    String name;
    Map<String, Sub> subs;
    public Org(String name) {
        this.name = name;
        subs = new HashMap<>();
    }

    public Sub addSub(String subName){
        if(!hasSub(subName)){
            subs.put(subName, new Sub(subName));
        }
        return subs.get(subName);
    }

    public boolean hasSub(String subName){
        return subs.containsKey(subName);
    }
    @Override
    public boolean equals(Object o) {
        return Objects.equals(this.name, ((Sub)o).name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.name, this.name);
    }
}

class Sub {
    String name;
    Map<Item, Integer> itemMap;

    public Sub(String name) {
        this.name = name;
        this.itemMap = new HashMap<>();
    }

    public void addItem(Item item, Integer qty){
        if(!hasItem(item)){
            itemMap.put(item, qty);
        }else{
            itemMap.put(item, itemMap.get(item) + qty);
        }
    }

    boolean hasItem(Item item){
        return itemMap.containsKey(item);
    }
    @Override
    public boolean equals(Object o) {
        if (o == this) {
            return true;
        }
        Sub s = (Sub) o;
        return s.name.equals(this.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.name);
    }
}
