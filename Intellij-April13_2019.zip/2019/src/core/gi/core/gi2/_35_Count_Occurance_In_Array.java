package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 4/6/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */

//THIS IS ALREADY SOLVED IN SOME PLACE, JUST TESTED HERE HOW TO GET FIRST AND LAST ELEM IN
// ARRAYLIST, BUT SEEING INSIDE ARRAYLIST DOES LEANIER SCAN
public class _35_Count_Occurance_In_Array {
    public static void main(String args[]){
        Integer[] ar = {2, 5, 5, 5, 6, 6, 8, 9, 9, 9};
        Arrays.sort(ar);

        ArrayList<Integer> list = new ArrayList<Integer>();
        list.addAll(Arrays.asList(ar));
        int s = list.indexOf(5);
        int e = list.lastIndexOf(5);
        System.out.println("first "+s+" last "+e+" total occurance "+(e-s+1));
    }

}
