package core.gi.core.gi2;

/**
 * Date: 4/4/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _21_Shares_Buy_Sell {
    public static void main(String args[]) {
        int[] ar = new int[]{12, 4, 1, 6, 7, 15, 3};
        maxProfit1Transaction(ar);
        maxProfit1TransactionWithBuySellIdices(ar);
    }

    static void maxProfit1Transaction(int[] ar) {
        int buy = ar[0];
        int maxProfit = 0;
        for (int i = 1; i < ar.length; i++) {
            int profit = ar[i] - buy;
            maxProfit = Math.max(maxProfit, profit);
            buy = Math.min(buy, ar[i]);
        }
        System.out.println(" max profit " + maxProfit);
    }

    static void maxProfit1TransactionWithBuySellIdices(int[] ar) {
        int buy = ar[0];
        int maxProfit = 0;
        int buyIndex = 0;
        int[] result = new int[2];
        for (int i = 1; i < ar.length; i++) {
            int profit = ar[i] - buy;
            if (profit > maxProfit) {
                maxProfit = profit;
                result[0] = buyIndex; // because buy Index is changing we need to save buy of
                result[1] = i; // this transaction
            }
            if (ar[i] < buy) {
                buyIndex = i;
                buy = ar[i];
            }
        }
        System.out.println(" max profit " + maxProfit + " buy " + result[0] + " sell " + result[1]);
    }
}
