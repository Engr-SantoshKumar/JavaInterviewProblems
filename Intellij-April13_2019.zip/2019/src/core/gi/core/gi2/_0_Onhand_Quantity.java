package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 4/5/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _0_Onhand_Quantity {
    public static void main(String args[]){
     Onhand o1 = new Onhand(new Item("Book"), "RCV", 2);
        Onhand o2 = new Onhand(new Item("Book"), "stores", 10);
        Onhand o3 = new Onhand(new Item("Book"), "staging", 4);
        Onhand o4 = new Onhand(new Item("Pencil"), "stores", 56);
        Onhand o5 = new Onhand(new Item("Pencil"), "staging", 5);

        Onhand[] ar = {o1, o2, o3, o4, o5};
        aggregateByItem(Arrays.asList(ar));
        //aggregateBySubInventory(Arrays.asList(ar));

    }
    static void aggregateByItem(List<Onhand> rows){
        Map<Item, Integer> map = new HashMap<>();
        for(Onhand ob : rows){
            if(!map.containsKey(ob.item)){
                map.put(ob.item, ob.quantity);
            }else{
                map.put(ob.item, ob.quantity + map.get(ob.item));
            }
        }
        for(Map.Entry<Item, Integer> entry : map.entrySet()){
            System.out.println(entry.getKey().name + ": " +entry.getValue());
        }
    }
    static void aggregateBySubInventory(List<Onhand> rows){
        Map<Item, Integer> map = new HashMap<>();
        for(Onhand ob : rows){
            if(!map.containsKey(ob.item)){
                map.put(ob.item, ob.quantity);
            }else{
                map.put(ob.item, ob.quantity + map.get(ob.item));
            }
        }
        for(Map.Entry<Item, Integer> entry : map.entrySet()){
            System.out.println(entry.getKey().name + ": " +entry.getValue());
        }
    }
}
class Onhand{
    public Onhand(Item item, String subInventory, Integer quantity) {
        this.item = item;
        this.subInventory = subInventory;
        this.quantity = quantity;
    }

    Item item;
    String subInventory;
    Integer quantity;

}

class Item{
    public Item(String name) {
        this.name = name;
    }
    String name;
    @Override
    public boolean equals(Object o){
        Item that = (Item)o;
        return Objects.equals(this.name, that.name);
    }

    @Override
    public int hashCode(){
        return Objects.hashCode(name);
    }
}