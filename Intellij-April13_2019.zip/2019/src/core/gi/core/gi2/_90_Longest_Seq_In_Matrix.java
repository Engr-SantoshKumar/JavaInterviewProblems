package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 3/31/19
 * ****** Don't pass result as a param to DFS it always keep changing as it is a local variable
 * Find the longest sequence length from nxn matrix
 * 129
 * 538
 * 467
 * <p>
 * This contains three sequences of adjacent numbers
 * [1,2,3],[4,5],[6,7,8,9] longest sequence length is 4
 */
public class _90_Longest_Seq_In_Matrix {
    static int[] R = {0, 0, -1, 1};
    static int[] C = {1, -1, 0, 0};
    static List<Integer> res = new ArrayList<>();

    public static void main(String args[]) {
        List<Integer> l = new ArrayList<>();
        //List<Integer>[] a =  (List<Integer>[]) new ArrayList[4]; // valid
        l.add(1);
        Cell one = new Cell(0, 1, l);
        Cell two = new Cell(0, 1, l);
        Set<Cell> visited = new HashSet<>();
        visited.add(one);
        visited.add(two);
        System.out.println(visited.size());
        int[][] M = new int[][]{{1, 2, 9}, {5, 3, 8}, {4, 6, 7}};
        dfs(M);
        System.out.println(" final result:"+Arrays.toString(res.toArray()));
    }

    static void dfs(int[][] M) {
        for (int row = 0; row < M.length; row++) {
            for (int col = 0; col < M[0].length; col++) {
                List<Integer> path = new ArrayList<>();
                path.add(M[row][col]);
                Cell cell = new Cell(row, col, path);
                Set<Cell> visited = new HashSet<>();
                dfs(M, cell, visited);
            }
        }
    }

    //static void dfs(int[][] M, Cell cell, Set<Cell> visited, List<Integer> result) { // dont use
    static void dfs(int[][] M, Cell cell, Set<Cell> visited) { // rsult as a param but use global
        if (visited.contains(cell)) {  // result, because with each call result local variable
            return;                  // will point to blank
        }
        visited.add(cell);
        for (int i = 0; i < R.length; i++) {
            int r = cell.row + R[i];
            int c = cell.col + C[i];
            List<Integer> path = new ArrayList<>();
            path.addAll(cell.path);
            Cell newCell = new Cell(r, c, path);

            if (isValidCell(M, r, c, visited, newCell)) {
                path.add(M[r][c]);
                if (M[r][c] - M[cell.row][cell.col] == 1) {
                    if (path.size() > res.size()) {
                        res = path;
                        System.out.println(" result updated to: " + Arrays.toString(res.toArray()));
                    }
                    dfs(M, newCell, visited);
                }
            }
        }
    }

    static boolean isValidCell(int[][] M, int row, int col, Set<Cell> visited, Cell cell) {
        return row >= 0 && row < M.length && col >= 0 && col < M[0].length && !visited.contains(cell);
        // since cell overrode the equals and hashcode method we can use visited.contains(cell)
    }
}

class Cell {

    int row;
    int col;
    List<Integer> path;

    public Cell(int row, int col, List<Integer> path) {
        this.row = row;
        this.col = col;
        this.path = path;
    }

    @Override
    public boolean equals(Object that) {
        return this.row == ((Cell) that).row && this.col == ((Cell) that).col;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(row) + Objects.hashCode(col);
    }

}
