package core.gi.core.gi2;

import java.util.*;

/**
 * From INterNet
 * A sub-inventory is a subdivision of an organisation representing either a physical area or a
 * logical grouping of items such as a store-room or receiving dock. Every organisation needs
 * at least one sub-inventory.
 * When an item is defined it is allocated to particular sub-inventories. If an item has a
 * restricted list of sub-inventories you will only be able to transfer materials to those
 * subinventories listed.
 * <p>
 * Org -> Sub -> Item -> Quantity
 * Date: 4/5/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 * <p>
 * item (13) - org1 (7)  - RCV(4)
 * - Staging(3)
 * org2 (5)  - RCV(2)
 * *                    - Staging(3)
 */
public class _0_OnHand_Dealer {
    public static void main(String args[]) {
        OnHand o1 = new OnHand(new Item("Book"), "RCV", "ORG1", 2);
        OnHand o2 = new OnHand(new Item("Book"), "stores", "ORG1", 10);
        OnHand o3 = new OnHand(new Item("Book"), "staging", "ORG1", 4);
        OnHand o4 = new OnHand(new Item("Pencil"), "stores", "ORG1", 5);
        OnHand o5 = new OnHand(new Item("Pencil"), "staging", "ORG1", 6);

        OnHand o11 = new OnHand(new Item("Book"), "RCV", "ORG2", 1);
        OnHand o12 = new OnHand(new Item("Book"), "stores", "ORG2", 9);
        OnHand o13 = new OnHand(new Item("Book"), "staging", "ORG2", 3);
        OnHand o14 = new OnHand(new Item("Pencil"), "stores", "ORG2", 4);
        OnHand o15 = new OnHand(new Item("Pencil"), "staging", "ORG2", 5);
        OnHand[] oA = new OnHand[]{o1, o2, o3, o4, o5, o11, o12, o13, o14, o15};
        List<OnHand> list = new ArrayList<OnHand>(Arrays.asList(oA));

        onHandProcessor2(list);
    }

    static void onHandProcessor(List<OnHand> list) {
        Map<String, Map<String, Map<Item, Integer>>> orgMap = new HashMap<>(); // set is the
        // subinventory
        for (OnHand on : list) {
            String org = on.org;
            String subIn = on.subInventory;
            Item item = on.item;
            Integer qty = on.quantity;

            Map<String, Map<Item, Integer>> subInMap = orgMap.get(org);

            if (subInMap == null) {
                subInMap = new HashMap<>();
                orgMap.put(org, subInMap);
            }
            Map<Item, Integer> itemsMap = subInMap.get(subIn);

            if (itemsMap == null) {
                itemsMap = new HashMap<>();
                subInMap.put(subIn, itemsMap);
            }

            if (itemsMap.containsKey(item)) {
                itemsMap.put(item, itemsMap.get(item) + qty);
            } else {
                itemsMap.put(item, qty);
            }

        }

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Map<String, Map<Item, Integer>>> entry : orgMap.entrySet()) {
            int itemCount = 0;
            int subInCount = 0;
            int orgCount = 0;
            sb.append("" + entry.getKey() + "\n");
            Map<String, Map<Item, Integer>> subInMap = entry.getValue();
            for (Map.Entry<String, Map<Item, Integer>> subE :
                    subInMap.entrySet()) {

                Map<Item, Integer> itemsMap = subE.getValue();
                sb.append("     " + subE.getKey() + "\n");
                for (Map.Entry<Item, Integer> iE : itemsMap.entrySet()) {
                    itemCount++;
                    sb.append("         [" + iE.getKey().name + ", " + iE.getValue() + "]" + "\n");
                }
            }
        }
        System.out.println(sb);

        sb.setLength(0);
        for (Map.Entry<String, Map<String, Map<Item, Integer>>> entry : orgMap.entrySet()) {
            int itemCount = 0;
            int subInCount = 0;
            int orgCount = 0;
            Map<String, Map<Item, Integer>> subInMap = entry.getValue();
            StringBuilder sbsub = new StringBuilder();
            for (Map.Entry<String, Map<Item, Integer>> subE :
                    subInMap.entrySet()) {
                subInCount = 0;

                Map<Item, Integer> itemsMap = subE.getValue();
                StringBuilder itemsb = new StringBuilder();
                for (Map.Entry<Item, Integer> iE : itemsMap.entrySet()) {
                    subInCount += iE.getValue();
                    orgCount += iE.getValue();
                    itemsb.append("\n            [" + iE.getKey().name + ", " + iE.getValue() +
                            "]");
                }
                sbsub.append("\n     " + subE.getKey() + "(" + subInCount + ")").append(itemsb).append(
                        "\n");
            }
            sb.append(entry.getKey() + "(" + orgCount + ")").append(sbsub).append("\n");
        }
        System.out.println(sb);

    }

    static void onHandProcessor2(List<OnHand> list) {
        Map<String, Map<String, Map<Item, Integer>>> orgMap = new HashMap<>(); // set is the
        // subinventory
        for (OnHand on : list) {
            String org = on.org;
            String subIn = on.subInventory;
            Item item = on.item;
            Integer qty = on.quantity;

            if (!orgMap.containsKey(org)) {
                orgMap.put(org, new HashMap<String, Map<Item, Integer>>());
            } // NOTE if you use else here rows will miss as if org does not exist we input new map
            Map<String, Map<Item, Integer>> subinMap = orgMap.get(org); // and skip else
            if (!subinMap.containsKey(subIn)) {
                subinMap.put(subIn, new HashMap<Item, Integer>());
            }
            Map<Item, Integer> itemsMap = subinMap.get(subIn);
            if (!itemsMap.containsKey(item)) {
                itemsMap.put(item, qty);
            } else {
                itemsMap.put(item, itemsMap.get(item) + qty);
            }
        }

        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Map<String, Map<Item, Integer>>> entry : orgMap.entrySet()) {
            int itemCount = 0;
            int subInCount = 0;
            int orgCount = 0;
            sb.append("" + entry.getKey() + "\n");
            Map<String, Map<Item, Integer>> subInMap = entry.getValue();
            for (Map.Entry<String, Map<Item, Integer>> subE :
                    subInMap.entrySet()) {

                Map<Item, Integer> itemsMap = subE.getValue();
                sb.append("     " + subE.getKey() + "\n");
                for (Map.Entry<Item, Integer> iE : itemsMap.entrySet()) {
                    itemCount++;
                    sb.append("         [" + iE.getKey().name + ", " + iE.getValue() + "]" + "\n");
                }
            }
        }
        System.out.println(sb);

        sb.setLength(0);
        for (Map.Entry<String, Map<String, Map<Item, Integer>>> entry : orgMap.entrySet()) {
            int itemCount = 0;
            int subInCount = 0;
            int orgCount = 0;
            Map<String, Map<Item, Integer>> subInMap = entry.getValue();
            StringBuilder sbsub = new StringBuilder();
            for (Map.Entry<String, Map<Item, Integer>> subE :
                    subInMap.entrySet()) {
                subInCount = 0;

                Map<Item, Integer> itemsMap = subE.getValue();
                StringBuilder itemsb = new StringBuilder();
                for (Map.Entry<Item, Integer> iE : itemsMap.entrySet()) {
                    subInCount += iE.getValue();
                    orgCount += iE.getValue();
                    itemsb.append("\n            [" + iE.getKey().name + ", " + iE.getValue() +
                            "]");
                }
                sbsub.append("\n     " + subE.getKey() + "(" + subInCount + ")").append(itemsb).append(
                        "\n");
            }
            sb.append(entry.getKey() + "(" + orgCount + ")").append(sbsub).append("\n");
        }
        System.out.println(sb);

    }
   /* static void onHandProcessor(List<OnHand> list){
        Map<String, Set<String>> orgMap = new HashMap<>(); // set is the subinventory
        Map<String, Set<Item>> subMap = new HashMap<>();
        Map<Item, Integer> items = new HashMap<>();

        for(OnHand on : list){
            String org = on.org;

            if(!orgMap.containsKey(org)){
                orgMap.put(on.org, new HashSet<>());
            }
            // update subInve
            Set<String> subInvenSet = orgMap.get(on.org);
            if(!subInvenSet.contains(on.subInventory)){
                subInvenSet.add(on.subInventory);
            }
            if(subInvenSet.contains(on.subInventory)){
                /// check subinventory map
                if(!subMap.containsKey(on.subInventory)){
                    subMap.put(on.subInventory, new HashSet<Item>());
                }
                if(subMap.containsKey(on.subInventory)){
                    Set<Item> itemSet = subMap.get(on.subInventory);
                    if(itemSet.contains(on.item)){
                        items.put(on.item, items.get(on.item) + on.quantity);
                    }else{
                        items.put(on.item, on.quantity);
                    }
                }
            }
        }

        for(Map.Entry<String, Set<String>> orgE : orgMap.entrySet()){
            //Set<String> subIn = orgE.getKey(orgE.getKey());
            String orgName = orgE.getKey();
            Set<String> subIn = orgE.getValue();
            for(Map.Entry<String, Set<Item>> sE : subMap.entrySet()){

                for(Map.Entry<Item, Integer> iE : items.entrySet()){

                }
            }
        }
    }*/
}

class OnHand {
    Item item;
    String subInventory;
    Integer quantity;
    String org;
    public OnHand(Item item, String subInventory, String org, Integer quantity) {
        this.item = item;
        this.subInventory = subInventory;
        this.quantity = quantity;
        this.org = org;
    }
}

/*
class OnHandProcessor{
    Map<Organization, List<Subinventory>> orgMap = new HashMap<>();
    Map<Subinventory, List<Pairs>> subMap = new HashMap<>();


}
*/

class Pairs {
    Item item;
    Integer quantity;
}

class Items {

    List<Organization> orgList;

    public Items() {
    }

    public void setOrgList(List<Organization> orgList) {
        this.orgList = orgList;
    }
}

class Organization {
    List<Subinventory> sub;

    public Organization() {
    }

    public void setSub(List<Subinventory> sub) {
        this.sub = sub;
    }

}

class Subinventory {
    Integer quantity;
    String name;
    public Subinventory(String name, Integer quantity) {
        this.quantity = quantity;
        this.name = name;
    }
}

/*
ORG1(27)
     RCV(2)
            [Book, 2]

     stores(15)
            [Book, 10]
            [Pencil, 5]

     staging(10)
            [Book, 4]
            [Pencil, 6]

ORG2(22)
     RCV(1)
            [Book, 1]

     stores(13)
            [Book, 9]
            [Pencil, 4]

     staging(8)
            [Book, 3]
            [Pencil, 5]
 */