package core.gi.core.gi2;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Date: 4/7/19
 */
public class _82_LRU_2 {
    public static void main(String args[]){
        LRU2 cache = new LRU2(2);
        cache.put(1, 1);
        cache.print();
        cache.put(2, 2);
        cache.print();
        cache.get(1);       // returns 1
        cache.put(3, 3);
        cache.print();// evicts key 2
        System.out.println(" get 2 from cache " +cache.get(2));       // returns -1 (not found)
        cache.put(4, 4);    // evicts key 1
        cache.print();
        cache.get(1);       // returns -1 (not found)
        cache.get(3);       // returns 3
        cache.get(4);       // returns 4
    }
}
class LRU2 {//extends LinkedHashMap<Integer, LRU2.Node> {
    private static LinkedHashMap<Integer, Integer> map;
    public LRU2(int capacity) {
        map = new LinkedHashMap<Integer, Integer>(capacity){
            protected boolean removeEldestEntry(Map.Entry eldest) {
                return size() > capacity;
            }
        };
    }
    public int get(int key) {
        return map.getOrDefault(key, -1);
    }
    public void put(int key, int value) {
        map.put(key, value);
    }

    static void print(){
        System.out.println(map.size());
        for(Map.Entry<Integer, Integer> entry : map.entrySet()){
            System.out.print(entry.getKey()+" -> ");
        }
        System.out.println();
    }
}