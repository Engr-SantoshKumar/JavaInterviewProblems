package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 4/2/19
 * gest common prefix from a set of strings.
 * “aaabbb”
 * “aabbb”
 * “abcde”
 */
public class _20_Longest_Common_Prefix {
    public static void main(String args[]){
        String[] ar = {"aaabbb", "aabbb", "aabcde"};
        longestPrefix(Arrays.asList(ar));
    }
    static void longestPrefix(List<String> list){
        List<char[]> l = new ArrayList<>();
        for(String s : list){
            l.add(s.toCharArray());
        }
        String prefix="";
        for(int i=0; i< l.get(0).length; i++){
            char c = l.get(0)[i];
            boolean match = true;
            for(int j=1; j< l.size(); j++){
                if(c != l.get(j)[i]){
                    match = false;
                    break;
                }
            }
            if(match){
                prefix+=c;
            }else{
                break;
            }
        }
        System.out.println(" longest prefix : "+prefix);
    }
}
