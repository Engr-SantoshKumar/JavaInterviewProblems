package core.gi.core.gi2;

import java.util.Arrays;

/**
 * Date: 4/6/19
 * https://medium.com/@rebeccahezhang/leetcode-418-sentence-screen-fitting-9d6258ce116e
 */
public class _53_Text_Screen {
    public static void main(String args[]) {
        String sentence0 = "hello world";
        fit(sentence0.split(" "), 2, 8);

        String sentence = "a bcd e";
        String[] ar = sentence.split(" ");
        fit(ar, 3, 6);

        String sentence2 = "I had apple pie";
        fit(sentence2.split(" "), 4, 5);
    }

    static void fit(String[] ar, int i, int j) {
        int k = 0;
        int times = 0;
        char[][] M = new char[i][j];
        for (int row = 0; row < i; row++) {
            for (int col = 0; col < j; col++) {
                String word = ar[k % ar.length];// circularly pick word

                if (j - word.length() - col >= 0) { // j=6 col=3, word bcd=> 6-3-4 = -1 so next row
                    for (char c : word.toCharArray()) {
                        M[row][col++] = c; // becz for loop adds another col++ end of loop, that add
                    }                      // the space, while this stmt moves ptr to next col
                    times = times(k, ar);
                    k++; // move to next word when one sentence is done
                }
            }
        }
        print(i, j, M);
        System.out.println(" times sentence \"" + Arrays.toString(ar) + "\" fits in is " + times);
    }

    static int times(int k, String[] ar) {
        int times = 0;
        if ((k % ar.length) == ar.length - 1) { // imp k% ar.len because k becomes 3,4,5
            times++;  // etc which is never going to meet condition after k >=3
        }
        return times;
    }

    static void print(int i, int j, char[][] M) {
        for (int x = 0; x < i; x++) {
            for (int y = 0; y < j; y++) {
                System.out.print(" " + M[x][y]);
            }
            System.out.println();
        }
    }
}
/*
 h e l l o - - -
 w o r l d - - -
 times sentence "[hello, world]" fits in is 1
 a - b c d
 e - a - -
 b c d - e
 times sentence "[a, bcd, e]" fits in is 1
 I - h a d
 a p p l e
 p i e - I
 h a d - -
 times sentence "[I, had, apple, pie]" fits in is 0

 */
