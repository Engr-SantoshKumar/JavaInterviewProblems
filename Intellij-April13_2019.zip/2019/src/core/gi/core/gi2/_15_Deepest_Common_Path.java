package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.List;

/**
 * Date: 4/2/19
 */
public class _15_Deepest_Common_Path {
    public static void main(String[] args) {
        List<String> list = new ArrayList<>();
        list.add("/home/kv/test/h");
        list.add("/home/kv/");
        list.add("/home/kv/test/hel");
        list.add("/home/kv/test/hello");
        findDeepestCommonPath(list);
    }

    static String findDeepestCommonPath(List<String> list) {
        if (list == null || list.size() == 0) {
            System.out.println(" invalid input");
        }

        List<String[]> l = new ArrayList<>();
        for (String s : list) {
            l.add(s.split("/"));
        }

        StringBuilder sb = new StringBuilder();
        int x = 0;
        for (int i = 0; i < l.get(0).length; i++) {
            boolean match = false;
            String s = l.get(0)[i];
            for (int j = 1; j < l.size(); j++) {
                String[] a = l.get(j);
                if (i > a.length - 1) { // imp to handle when other ar is lesser len to avoid AIOB
                    match = false;
                    break;
                }
                if (s.equals(a[i])) {
                    match = true;
                } else {
                    match = false;
                    break;
                }
            }
            if (!match) {
                break;
            }else{
                sb.append(s+"/");
            }
        }
        System.out.println(sb);
        return sb.toString();
    }
}
