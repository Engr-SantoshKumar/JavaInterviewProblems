package core.gi.core.gi2;

/**
 * Date: 4/2/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _19_String_Has_Duplicate_Chars {
    public static void main(String args[]) {
        testFor("abc");
        testFor("abcc");
        testFor("ABC");
        testFor("AabC");
        testFor("AA");
        testFor(" ");
        testFor("");
    }
    static void testFor(String s){
        System.out.println(" input "+s+" "+isDupCharsStr(s));
    }

    static boolean isDupCharsStr(String s) {
        int[] key = new int[127];
        for (char c : s.toCharArray()) {
            key[c]++;
        }
        for (int i : key) {
            if (i > 1) {
                return true;
            }
        }
        return false;
    }
}