package core.gi.core.gi2;

import java.util.Arrays;

/**
 * Date: 4/1/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _12_Popular_Number_Flavour2 {

    public static void main(String[] args) {
        Integer[] a = {0, 1, 1, 1, 1, 4, 6, 6};
        System.out.println(Arrays.toString(a));
        System.out
                .println("Popular(number repeated <25% of array length) Number in the above array is: "
                        + findPopular(a));
    }



    public static int findPopular(Integer[] a) {
        int n = a.length;
        int k = n / 4;
        if (count(a, n / 4) >= k) {
            return a[n / 4];
        } else if (count(a, n / 2) >= k) {
            return a[n / 2];
        } else if (count(a, (3 * n) / 4) >= k) {
            return a[3*n / 4];
        }
        return -1;
    }

    public static int count(Integer[] a, int x) {
        int leftIndex = findLoIdx(a, a[x]);
        int rightIndex = findHiIdx(a, a[x]);
        int count = rightIndex - leftIndex + 1;
        System.out.println(String.format("target: %s, occurances: %s , startIndex: %s, endIndex: %s",
                a[x], count, leftIndex, rightIndex));
        return count;
    }
    static int findLoIdx(Integer[] ar, Integer key) {
        int lo = 0;
        int hi = ar.length - 1;
        int loIdx = -1;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            System.out.println(" lo is " + lo + " hi " + hi + " mid is " + mid);
            if (ar[mid] > key) {
                hi = mid - 1;
            } else if (ar[mid] < key) {
                lo = mid + 1;
            } else if (ar[mid] == key) {
                loIdx = mid;// we got a temp result but will keep finding on left
                hi = mid - 1;
            }
        }
        System.out.println(" now hi becomes " + hi + " lo is " + lo + " lo index is " + loIdx);
        return loIdx;
    }

    // This solution is from mycodeSchool
    static int findHiIdx(Integer[] ar, Integer key) {
        key = ar[key];
        int lo = 0;
        int hi = ar.length - 1;
        int hiIdx = -1;
        while (lo <= hi) {
            int mid = (lo + hi) / 2;
            System.out.println(" lo is " + lo + " hi " + hi + " mid is " + mid);
            if (ar[mid] > key) {
                hi = mid - 1;
            } else if (ar[mid] < key) {
                lo = mid + 1;
            } else if (ar[mid] == key) {
                hiIdx = mid;// we got a temp result but will keep finding on left
                lo = mid + 1;
            }
        }
        System.out.println(" now hi becomes " + hi + " lo is " + lo + " lo index is " + hiIdx);
        return hiIdx;
    }
}
