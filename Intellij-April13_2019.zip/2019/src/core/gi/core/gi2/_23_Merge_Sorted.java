package core.gi.core.gi2;

import java.util.Arrays;

/**
 * Given two sorted integer arrays X and Y , merge Y into X as one sorted array.
 * X = { 1, 3, 5, 9, 11,_,_,_,_,_}
 * Y = { 2, 6, 7, 10, 13}
 */
public class _23_Merge_Sorted {
    public static void main(String args[]) {
        int[] ar = new int[]{1, 3, 5, 9, 11, 0, 0, 0, 0, 0};
        int[] ar1 = new int[]{2, 6, 7, 10, 13};
        merge(ar, ar1);
        System.out.println(Arrays.toString(ar));

    }
    // This will not work when you do merging from start of arrays
    static void merge(int[] ar1, int[] ar2) {
        int k = ar1.length-1;
        int i = ar1.length-1;
        int j = ar2.length-1;

        while(ar1[i] == 0){
            i--;
        }

        while(i>=0 && j>=0){
            System.out.println("i "+i+" j "+j);
            if(ar1[i]>= ar2[j]){
                ar1[k--] = ar1[i--];
            }else{
                ar1[k--] = ar2[j--];
            }
        }
    }

    static void swap(int i, int j, int[] ar1, int[] ar2) {
        int temp = ar1[i];
        ar1[i] = ar2[j];
        ar2[j] = temp;
    }
}
