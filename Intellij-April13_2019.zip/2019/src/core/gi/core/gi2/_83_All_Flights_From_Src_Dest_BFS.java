package core.gi.core.gi2;

import java.util.*;

/**
 * *** ArrayList preserves order of insertion as is Array based
 *why used LinkedHashSet,
 * you can use arrayList to store path, it preserves order of insertion but to find any element is
 * in path list or not it is O(n)
 * why not HashSet, HashSet does not preserve order of insertion so we used LinkedHS as it will
 * have order preserved + contains in path is O(1)
 */
public class _83_All_Flights_From_Src_Dest_BFS {
    public static void main(String args[]){
        Flight a = new Flight("SFO", "LAX");
        Flight b = new Flight("SFO", "DEN");
        Flight c = new Flight("SFO", "NYC");
        Flight d = new Flight("LAX", "DEN");
        Flight e = new Flight("LAX", "IAH");
        Flight f = new Flight("DEN", "NYC");
        Flight g = new Flight("IAH", "NYC");
        Flight gd = new Flight("IAH", "IAH");
        Flight h = new Flight("DEN", "ABC");
        List<Flight> list = new ArrayList<>();
        list.add(h);list.add(a);list.add(b);list.add(c);list.add(d);list.add(e);list.add(f);list.add(g);list.add(gd);

        // create map or graph
        Map<String, List<String>> G = new LinkedHashMap<>();
        for(Flight flight : list){
            List<String> dest;
            if(G.containsKey(flight.start)){
                dest = G.get(flight.start);
            }else{
                dest = new ArrayList<String>();
            }
            dest.add(flight.dest);
            G.put(flight.start, dest);
        }
        long s = System.currentTimeMillis();
        System.out.println();
        List<LinkedHashSet<String>> result = bfs("SFO", "NYC", G);
        for(LinkedHashSet<String> ll : result){
            System.out.println(ll);
        }
        long ed = System.currentTimeMillis();
        System.out.println(" total time take in ms "+(ed-s));

    }

    static List<LinkedHashSet<String>> bfs(String source, String dest, Map<String, List<String>> G){
        List<LinkedHashSet<String>> result = new ArrayList<LinkedHashSet<String>>();
        Queue<Pair> q = new ArrayDeque<>();
        LinkedHashSet<String> firstPath = new LinkedHashSet<>();
        firstPath.add(source);
        q.add(new Pair(source, firstPath));
        while(!q.isEmpty()){
            Pair top = q.poll();
            if(top.src == dest){
                result.add(top.path);
            }
            if(!G.containsKey(top.src)){ // This is to Handle when we look for "ABC" in G
                continue;
            }

            for(String d : G.get(top.src)){
                // below is to handle visited case
                if(top.path.contains(d)){
                    System.out.println("....");
                    continue;
                }
                LinkedHashSet<String> thisPath = new LinkedHashSet<>(top.path);
                thisPath.add(d);
                q.offer(new Pair(d, thisPath));
            }
        }
        return result;
    }
}

class Pair{
    public Pair(String src, LinkedHashSet<String> path) {
        this.src = src;
        this.path = path;
    }

    String src;
    LinkedHashSet<String> path;
    public String toString(){
        return src;//+" : "+path.toString();
    }
}
/*
[SFO]
[LAX, DEN, NYC]
[DEN, NYC, DEN, IAH]
[NYC, DEN, IAH, ABC, NYC]
[DEN, IAH, ABC, NYC]
[IAH, ABC, NYC, ABC, NYC]
[ABC, NYC, ABC, NYC, NYC]
[NYC, ABC, NYC, NYC]
[ABC, NYC, NYC]
[NYC, NYC]
[NYC]*/

/*
output
[SFO, NYC]
[SFO, DEN, NYC]
[SFO, LAX, DEN, NYC]
[SFO, LAX, IAH, NYC]*/
