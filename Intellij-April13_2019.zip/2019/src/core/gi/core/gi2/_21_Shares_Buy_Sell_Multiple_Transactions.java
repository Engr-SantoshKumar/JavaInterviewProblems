package core.gi.core.gi2;

/**
 * Date: 4/4/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _21_Shares_Buy_Sell_Multiple_Transactions {

    public static void main(String args[]) {
        int[] ar = new int[]{12, 4, 1, 6, 7, 15, 11, 12, 0, 3};
        System.out.println(profitMultipleTransactions(ar));
    }
    static int profitMultipleTransactions(int[] ar){
        int buy = ar[0];
        int totalProfit=0;
        for(int i=1; i< ar.length; i++){
            int profit = ar[i] - ar[i-1];
            if(profit>0){
                System.out.println(" profit "+profit);
                totalProfit += profit;
            }
        }
        return totalProfit;
    }
}
