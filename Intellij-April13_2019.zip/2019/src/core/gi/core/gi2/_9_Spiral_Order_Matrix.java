package core.gi.core.gi2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 3/31/19
 * Q: given matrix output it in spiral order. Eg,
 * 1 2 3
 * 4 5 6 ---> 5 6 9 8 7 4 1 2 3
 * 7 8 9
 */
public class _9_Spiral_Order_Matrix {
    public static void main(String args[]) {
        int[][] M = new int[][]{
                {1, 2, 3},
                {4, 5, 6},
                {7, 8, 9}
        };
        int[][] M1 =  {
                      {1, 2, 3, 4},
                      {12, 13, 14, 5},
                      {11, 16, 15, 6},
                      {10, 9, 8, 7}};
        for(int[] ar : M1){

            System.out.println(Arrays.toString(ar));
        }

        List<Integer> spiral = spiral2(M, 1,1 );
        System.out.println(Arrays.toString(spiral.toArray()));
        List<Integer> spiral1 = spiral2(M1, 0,0 );
        System.out.println("..." +Arrays.toString(spiral1.toArray()));
    }

    static List<Integer> spiral(int[][] M, int row, int col) {
        List<Integer> spiral = new ArrayList<>();
        int R = M.length;
        int C = M[0].length;
        int[][] visited = new int[M.length][M[0].length];
        while (inRange(row, col, R, C, M, visited)) {
            //Right
            while (inRange(row, col, R, C, M, visited)) {
                visited[row][col]=1;
                spiral.add(M[row][col++]);
            }
            col--;
            row++;

            //Down
            while (inRange(row, col, R, C, M, visited)) {
                visited[row][col]=1;
                spiral.add(M[row++][col]);
            }
            row--;
            col--;

            while (inRange(row, col, R, C, M, visited)) {
                visited[row][col]=1;
                spiral.add(M[row][col--]);
            }
            col++;
            row--;

            while (inRange(row, col, R, C, M, visited)) {
                visited[row][col]=1;
                spiral.add(M[row--][col]);
            }
            row++;
            col++;
        }
        return spiral;
    }

    static List<Integer> spiral2(int[][] M, int row, int col) {
        int[] R = {0, 1, 0, -1};
        int[] C = {1, 0, -1, 0};
        int ROW = M.length;
        int COL = M[0].length;
        int[][] visited = new int[M.length][M[0].length];
        List<Integer> spiral = new ArrayList<>();

        boolean first = true;
        while (spiral.size() < ROW*COL) { // run 16 times for 4*4 Matrix, dont use visited here
                                          // else second layer would not be working
            if(first){                    // This is very imp to put first item
                spiral.add(M[row][col]);
                visited[row][col] = 1;
                first = false;
            }

            for (int i = 0; i < R.length; i++) {
                while(inRange(row+R[i], col+C[i], ROW, COL, M, visited)){
                    spiral.add(M[row+R[i]][col+C[i]]);
                    row = row+R[i];
                    col = col+C[i];
                    visited[row][col] = 1;
                }
            }
        }
        return spiral;
    }

    static boolean inRange(int row, int col, int R, int C, int[][] M,  int[][] visited) {
        //System.out.println(" is in range "+ row+" ci :"+col);
        return row < R && col < C && row >-1 && col >-1  && visited[row][col] == 0;
    }
}
