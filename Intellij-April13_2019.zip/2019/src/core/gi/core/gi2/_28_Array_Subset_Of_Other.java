package core.gi.core.gi2;

import java.util.ArrayDeque;
import java.util.Arrays;

/**
 * Date: 4/6/19
 */
public class _28_Array_Subset_Of_Other {
    public static void main(String args[]){
        int[] ar1 = new int[]{1,2,3,4,5,6};
        int[] ar2 = new int[]{3,4,5};
        testFor(ar1, ar2);
        testFor(new int[]{1,2,3,4,5,6}, new int[]{1,2,3,4,5,6});
        testFor(new int[]{1,2,3,4,5,6}, new int[]{4,5,6});
        testFor(new int[]{1,2,3,4,5,6}, new int[]{4,5,7});
        testFor(new int[]{4,5}, new int[]{4,5});
        testFor(new int[]{4,5}, new int[]{4});
        testFor(new int[]{4,5}, new int[]{5});
        testFor(new int[]{4}, new int[]{4});
        testFor(new int[]{4}, new int[]{5});
        testFor(new int[]{4}, new int[]{});
    }

    static void testFor(int[] ar1, int[] ar2){
        System.out.println(" =======================");
        System.out.println(Arrays.toString(ar1));
        System.out.println(Arrays.toString(ar2));
        System.out.println("is subset 2 of 1 : "+isSubset(ar1, ar2));

    }
    static boolean isSubset(int[] ar1, int[] ar2){
        int i=0; int j=0;
        while(i<ar1.length && j< ar2.length){
            if(ar1[i] < ar2[j]){
                i++;
            }else{
                j++;
            }
        }
        if(j == ar2.length){ // This will return true when {4}, {} so check for len of array
            return true;
        }
        return false;
    }
}
