package core.gi.core.gi2;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Date: 4/7/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _0_Two_Sum {
    public static void main(String args[]) {
        int[] ar = {1, 4, 6, 8, 8, 10, 12, 15, 24, 45};
        testFor(ar, 5);
        testFor(ar, 16);
        testFor(ar, 51);
        testFor(ar, 20);
        testFor(ar, 18);
        testFor(ar, 23);
        testFor(ar, 69);
    }

    static void testFor(int[] ar, int k){
        System.out.println(" testing for sum: "+k +" in "+ Arrays.toString(ar));
        twoSumMap(ar, k);
    }

    // Passed in LeetCode***********
    static void twoSumMap(int[] ar, int sum) {
        // store compliment and its index
        Map<Integer, Integer> map = new HashMap<>();
        for (int i = 0; i < ar.length; i++) {// search till last elem
            if(map.containsKey(ar[i])){
                System.out.println(" pair is {"+(ar[i])+", "+ ar[map.get(ar[i])]+"}");
                map.remove(ar[i]);
            }
            int compliment = sum - ar[i];
            map.put(compliment, i);
        }
    }
    // GOood working solution
    static void twoSum(int[] ar, int sum) {
        for (int i = 0; i < ar.length-1; i++) { // search till the second last elem only
            int compliment = sum - ar[i];
            int index = binarySearch(ar, i+1, ar.length-1, compliment);
            if(index != -1){
                System.out.println(" pair is {"+(ar[i])+", "+ compliment+"}");
            }
        }
    }

    static int binarySearch(int[] ar, int lo, int hi, int key) {
        if (ar == null || ar.length == 0) {
            return -1;
        }

        while (lo <= hi) { // imp check for lo<=hi else in given array u cannot find 2nd,
            int mid = (lo + hi) / 2;// last or mid element element
            if (key == ar[mid]) {
                return mid;
            } else if (key < ar[mid]) {
                hi = mid - 1;
            } else if (key > ar[mid]) {
                lo = mid + 1;
            }
        }
        return -1;
    }
}
