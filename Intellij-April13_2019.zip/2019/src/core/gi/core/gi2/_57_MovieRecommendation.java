package core.gi.core.gi2;

import java.util.*;

/**
 * Date: 3/29/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _57_MovieRecommendation {
    public static void main(String args[]) {
        Movie a = new Movie(1, 1.2F);
        Movie b = new Movie(2, 2.4F);
        Movie c = new Movie(3, 3.6F);
        Movie d = new Movie(4, 4.8F);

        a.addSimilarMovie(b);
        a.addSimilarMovie(c);
        b.addSimilarMovie(d);
        c.addSimilarMovie(d);

        List<Integer> similar = getMovieRecommendations(a, 1);
        for (Integer s : similar) {
            System.out.println(s);
        }
    }

    static List<Integer> getMovieRecommendations(Movie m, int k) {
        Set<Movie> visited = new HashSet<>();
        PriorityQueue<Movie> pq = new PriorityQueue<>(new Comparator<Movie>() {
            public int compare(Movie a, Movie b) {
                return b.rating.compareTo(a.rating);
            }
        });
        List<Integer> result = new ArrayList<>();
        dfs(m, visited, pq);
        while (!pq.isEmpty() && k>0){
            result.add(pq.poll().movieId);
            k--;
        }
        return result;
    }

    static void dfs(Movie source, Set<Movie> visited, PriorityQueue<Movie> pq) {
        if (visited.contains(source)) {
            return;
        }
        visited.add(source);
        List<Movie> similar = source.getSimilarMovies();
        for (Movie m : similar) {

            if (!visited.contains(m)) {
                pq.offer(m);
            }
            dfs(m, visited, pq);
        }
    }
}

class Movie {

    final int movieId;
    Float rating;
    private List<Movie> similarMovies; // Similarity is bidirectional

    public Movie(int movieId, float rating) {
        this.movieId = movieId;
        this.rating = rating;
        similarMovies = new ArrayList<Movie>();
    }

    public void addSimilarMovie(Movie movie) {
        similarMovies.add(movie);
        movie.similarMovies.add(this);
    }

    public List<Movie> getSimilarMovies() {
        return similarMovies;
    }
}