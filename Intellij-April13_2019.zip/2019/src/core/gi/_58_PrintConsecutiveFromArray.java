package core.gi;

import java.util.LinkedList;
import java.util.Stack;

/**
 * Date: 3/16/19
 * Print the values in consecutive order from given number array.
 * i/p => { 1, 3, 6, 8, 10, 11, 12, 15, 17, 20, 21, 22, 25, 30, 31 }
 * o/p => 10, 11, 12, 20, 21, 22, 30, 31.
 */
public class _58_PrintConsecutiveFromArray {
    public static void main(String args[]) {
        int[] ar = new int[]{1, 3, 6, 8, 10, 11, 12, 15, 17, 20, 21, 22, 25, 30, 31};
        printConsecutive(ar);
    }

    // Simple version, TODO make only one list of result
    static void printConsecutive(int[] ar) {
        for(int i = 0;i<ar.length; i++){
            LinkedList<Integer> ll = new LinkedList<>();
            while(i<ar.length-1 && ar[i+1]-ar[i] ==1){ // run till second last element
                ll.add(ar[i]);
                i++;
            }
            ll.add(ar[i]); // when you reach array end the last element 31 will be inserted
            if(ll.size()>1){
                System.out.println(ll.toString());
            }
            ll.clear();
        }
    }

    static void printConsecutive2(int[] ar) {
        Stack<Integer> st = new Stack<>();
        for (int i = 0; i < ar.length; i++) {
            //System.out.println(" at "+i+" elem "+ar[i] +" st was "+st);
            if (st.isEmpty()) {
                //System.out.println(" pushing to stack "+ar[i]);
                st.push(ar[i]);
                continue;
            }
            if (ar[i] - st.peek() == 1) {
                st.push(ar[i]);
            } else {
                if (st.size() > 0) {
                    if (st.size() == 1) {
                        // System.out.println(" empty stack");
                        st.clear();
                        st.push(ar[i]);
                    } else {
                        while (!st.isEmpty()) {
                            System.out.print(", " + st.pop());
                        }
                    }
                }
            }
        }
    }

}
