package core.gi;

import java.util.HashSet;
import java.util.Set;

/**
 * Date: 3/17/19
 * Runtime Complexity: o(?) --
 */
public class Z_61_One_Char_Substitute {
    public static void main(String[] args) {
        Set<String> set = new HashSet<String>();
        set.add("apple");
        set.add("pear");
        System.out.println(isValidWord(set, "adple"));
        System.out.println(isValidWord(set, "addle"));
        System.out.println(isValidWord(set, "aple"));

    }

    static boolean isValidWord(Set<String> set, String s) {
        char[] ar = s.toCharArray();
        for (int i = 0; i < ar.length; i++) {
            if (canForm(set, ar, i)) {
                return true;
            }
        }
        return false;
    }

    static boolean canForm(Set<String> set, char[] ar, int i) {
        char temp = ar[i];
        for (char c = 'a'; c <= 'z'; c++) {
            ar[i] = c;
            String s = new String(ar);
           // System.out.println(" s formed as " + s);
            if (set.contains(s)) {
                System.out.println(" word can be formed " + s);
                return true;
            }
        }
        ar[i] = temp; // If this is done then we get wrong results because we want to bring str
                      // to its original state
        return false;
    }

    static boolean isValidWord2(Set<String> dictionary, String word) {
        for (int i = 0; i < word.length(); i++) {
            // make sure the char array is made here else we get stale data
            // if we put above the main foor loop then the carray is Zpple
            // then in second iter the array retains the last elem again zzple
            char[] cArray = word.toCharArray();
            for (char c = 'a'; c <= 'z'; c++) {
                cArray[i] = c;
                if (dictionary.contains(new String(cArray))) {
                    return true;
                }
            }
        }
        return false;
    }

}
