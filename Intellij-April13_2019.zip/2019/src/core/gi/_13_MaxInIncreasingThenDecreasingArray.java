package core.gi;

import java.util.Arrays;

/**
 * Date: 3/12/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _13_MaxInIncreasingThenDecreasingArray {
    public static void main(String args[]){
        int ar[] = new int[] {40, 30, 20};
        int ar1[] = new int[] {1, 40, 5};
        int[] ar2= new int[]{20, 2};
        int[] ar3= new int[]{1, 50, 50, 50, 50, 60};
        int[] ar4= new int[]{60, 50, 50, 50, 50};
       /* fMax(ar);
        fMax(ar1);
        fMax(ar2);*/
        fMax(ar3);
        fMax(ar4);

       // System.out.println(ar[findMax(ar)]+ ", "+ar[findMax(ar1)]+" , "+ar[findMax(ar2)]);
    }

    static void fMax(int[] ar){
        int i = max(ar);
        if(i == -1){
            System.out.println(" max in array "+Arrays.toString(ar)+ " was not found");
        }else{
            System.out.println(" max in array "+Arrays.toString(ar)+ " was  "+ar[i]);
        }

    }

    static int max(int[] ar){

        int lo = 0; int hi = ar.length-1;
        int max = -1;
        while(lo<=hi){
            int mid = (lo+hi)/2;
            if(lo==hi){
                return lo;
            }
            if(hi-lo == 1){
                return ar[lo]>=ar[hi]?lo: hi;
            }
            System.out.println(" lo "+lo+" mid "+mid+" hi "+hi);
            // Since it is incr and then decr so mid>=hi is not possible else for
            // 60, 50 ,50, 50 the o/p comes to 50 as
            if(mid>0 && mid< ar.length-1 && ar[mid]>=ar[mid-1] && ar[mid]>ar[mid+1]){
                return mid;
            }
            if(ar[mid] < ar[lo]){
                hi = mid-1;
            }else{
                lo = mid+1; // since ar[mid]>ar[mid+1] was in the above condition
                // 50, 50 50, 60 then as per ar[mid]>ar[mid+1] mid is guranteed not the
                // biggest, so for for mid equal or greater lo mid>= lo always go
                // right is safe
            }
        }
        return -1;
    }
    public static int findMax(int[] a) {
        //Array length should be greater than 3 to compute max
        if (a == null || a.length < 3) {
            System.out.println("Not a valid array of elements");
            return Integer.MAX_VALUE;
        }
        int left = 0;
        int right = a.length;
        int mid = 0;
        System.out.println(Arrays.toString(a));
        System.out.print("Max Element is: ");
        while (left <= right) {
            mid = left + (right - left) / 2;
            if (a[mid] > a[mid - 1] && a[mid] > a[mid + 1]) {
                System.out.println(a[mid]);
                return a[mid];
            }
            if (a[mid] > a[mid - 1] && a[mid] < a[mid + 1]) {
                left = mid + 1;
            } else {
                right = mid - 1;
            }
        }
        return Integer.MAX_VALUE;
    }
}
