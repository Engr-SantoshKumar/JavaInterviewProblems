package core.gi;

import java.util.Arrays;

/**
 * Date: 3/13/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _21_Airplane_in_Air {
    public static void main(String[] args) {
        double takeoff[] = {9.00, 9.40, 9.50, 11.00, 15.00, 18.00};
        double landing[] = {9.10, 12.00, 11.20, 11.30, 19.00, 20.00};
        // ater sorting    {9.00, 11.20, 11.30, 12.00, 19.00, 20.00};
        int c = maxNumberOfPlanesOnTheAir(takeoff, landing);
        System.out.println(c);
    }

    static int maxNumberOfPlanesOnTheAir(double[] takeoff, double[] landing) {
        Arrays.sort(takeoff);
        Arrays.sort(landing);
        int i = 0;
        int j = 0;
        int maxCount = 0;
        int count = 0;
        while (i < takeoff.length && j < landing.length) {
            if (takeoff[i] < landing[j]) {
                count++;
                i++;
             /*} else if (takeoff[i] == landing[j]) { // this equal condition may be needed or not
                i++; j++; // should ask this question if both are same then what to do?
                          // online is like this code
            }*/
            } else {
                j++;
                count--;
            }
            maxCount = Math.max(maxCount, count);
        }
        return maxCount;
    }
}
