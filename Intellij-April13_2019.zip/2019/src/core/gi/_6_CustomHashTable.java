package core.gi;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * https://leetcode.com/problems/design-hashmap/
 *
 * Date: 3/10/19
 [Erown, 7],
 [Alvin2, 3], [Brown, 4],
 [Crown, 5],
 [Alvin, 2], [Drown, 6],

Check here a simple but similar approach
 https://dzone.com/articles/custom-hashmap-implementation-in-java
 * Remember:
 */
public class _6_CustomHashTable {
    public static void main(String args[]) {
        Map<String, Integer> map = new HashMap<>();
        HashMp<String, Integer> hm = new HashMp<>(4);
        hm.put("Alvin", 1);
        hm.put("Alvin", 2);
        hm.put("Alvin2", 3);
        hm.put("Brown", 4);
        hm.put("Crown", 5);
        hm.put("Drown", 6);
        hm.put("Erown", 7);
        System.out.println(" size of map " + hm.size());
        hm.iterate();
    }
}

class HashMp<K, V> {
    Node[] ar;
    int size;

    public HashMp(int capacity) {
        ar = new Node[capacity]; //16
        size = ar.length;
    }

    void put(K key, V value) {
        int hash = hash(key);
        Node<K, V> n = new Node(hash, key, value);
        if (ar[hash] == null) {
            ar[hash] = n;
        } else {
            Node<K,V> x = ar[hash];
            while (x != null) {
                if (x.getHash() == hash && x.getKey().equals(key)) {
                    // override duplicate key for new value
                    //x = new Node(hash, key, value, null);
                    x.value = value;
                    return;
                }
                if(x.next == null){
                    break;
                }
                x = x.next;
            }
            x.next = n;
        }
    }

    public V get(K key) {
        int hash = hash(key);
        Node<K,V> n = ar[hash];
        while (n != null) {
            if (n.getHash() == hash) {
                return n.getValue();
            }
            n = n.next;
        }
        return null;
    }

    int hash(K key) {
        int hash = Objects.hash(key);
        int index = hash & (size - 1);
        return index;
    }

    int size() {
        return size;
    }

    void iterate() {
        StringBuilder sb = new StringBuilder();
        for (Node n : ar) {
            sb.append("\n");
            while (n != null) {
                sb.append("["+n.getKey() +", "+ n.getValue()+"], ");
                n = n.next;
            }
        }
        System.out.println(sb);
    }

    static class Node<K, V> {
        int hash;
        K key;
        V value;
        Node<K, V> next;

        public Node(int hash, K key, V value) {
            this.hash = hash;
            this.key = key;
            this.value = value;
        }

        public int getHash() {
            return hash;
        }

        public K getKey() {
            return key;
        }

        public V getValue() {
            return value;
        }
    }

}