package core.gi;

import java.util.HashMap;
import java.util.Map;

/**
 * Date: 3/13/19
 * My Own Method:
 * More helpful when lists are not sorted then put every thing in HashMap with key and count,
 * for first array load map and for second array remove elems from map, if elem not in map add to
 * res1, so res1 is elems in B not in A and what is left in map is elems in A not in B
 */
public class _18_ElementsInANotInB_InBNotInA {
    public static void main(String[] args) {
        int[] a1 = new int[]{1, 2, 2, 2, 3, 6, 7};
        int[] a2 = new int[]{2, 4, 5, 10, 12, 13, 14, 15};
        findDiff(a1, a2);
        findDiffKVMethod(a1, a2);
    }

    static void findDiff(int[] ar1, int[] ar2) {
        int i = 0;
        int j = 0;
        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        while (i < ar1.length && j < ar2.length) {
            if (ar1[i] == ar2[j]) {
                i++;
                j++;
            } else if (ar1[i] < ar2[j]) {
                sb2.append(", " + ar1[i++]);
            } else {
                sb1.append(", " + ar2[j++]);
            }
        }
        // exhaust first
        while (i < ar1.length) {
            sb2.append(", " + ar1[i++]);
        }
        // exhaust second
        while (j < ar2.length) {
            sb1.append(", " + ar2[j++]);
        }
        System.out.println(" Elems in A not IN B " + sb2);
        System.out.println(" Elems in B not IN A " + sb1);
    }

    static void findDiffKVMethod(int[] ar1, int[] ar2) {
        int i = 0;
        int j = 0;
        StringBuilder sb1 = new StringBuilder();
        StringBuilder sb2 = new StringBuilder();
        Map<Integer, Integer> map = new HashMap<>();
        // update map with key and count for array 1
        for(int a : ar1){
            int count = 1;
            if(map.containsKey(a)){
                count+=map.get(a);
            }
            map.put(a, count);
        }
        // decrement map for keys in array 2
        for(int a : ar2){
            if(map.containsKey(a) && map.get(a)!=0){
                map.put(a, map.get(a)-1);
            }else{
                sb1.append(", "+a);
            }
        }
        for(Integer x : map.keySet()){
            int count = map.get(x);
            while(count--> 0) {
                sb2.append(", " + x);
            }
        }
        System.out.println(" Elems in A not IN B " + sb2);
        System.out.println(" Elems in B not IN A " + sb1);
    }
}
