package core.gi;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentSkipListSet;

/**
 * Date: 3/14/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _31_First_Int_Grtr_Than_0_Not_In_Arry {
    public static void main(String args[]){
        int[] ar = new int[]{1,2,-3};
         int [] ar1 = new int[] {3,5,-1,1, -2};
        int x = findFirstPositiveGrtThan0(ar1);
        //findFirstPositiveGrtThan0Array(ar1);
        System.out.println(x);
    }

    static int findFirstPositiveGrtThan0(int[] ar){
        Set<Integer> set = new HashSet<>();
        for(int a: ar){
            set.add(a);
        }

        int start = 1;
        while(set.contains(start)){ // if you do start++ here then you miss cas 1,2,4, 5 ans would
            start++;                // be 4 but you expect 3
        }
        return start;
    }

    /*static void findFirstPositiveGrtThan0Array(int[] ar){

        // Order not maintained but moved all negatives to starting and positives to end
        int count = ar.length-1;
        for(int i=ar.length-1; i>=0; i--){
            swap(count, i, ar);
            if(ar[count] >= 0){
                count--;
            }
        }
        System.out.println(Arrays.toString(ar));
        System.out.println(count+1);

        count = count+1;


        for(int i = count; i<ar.length; i++){
            int x = ar[i];
            if(x>=0 && (x+1)<ar.length){
                ar[x+1] = -1*ar[x+1];
            }
        }

    }*/

    static void swap(int i, int j, int[] ar) {
        System.out.println(" swapping " + i + " with " + j);
        int temp = ar[i];
        ar[i] = ar[j];
        ar[j] = temp;
    }
}
