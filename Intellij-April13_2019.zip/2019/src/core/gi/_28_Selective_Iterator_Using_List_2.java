package core.gi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.NoSuchElementException;

interface Selector<T> {
    public boolean select(T t);
}

/**
 * Date: 3/21/19
 * idea from https://usabilityetc.com/articles/selection-iterators/
 * Problem Description:
 * Remember: if you have a class MYLIst extending list then you can use the parent class methods
 * using this.somemethod(), similarly if you have a relation like
 * MyList extends List{
 *     private class AnotherPrivateClassINMyList{}
 * }
 * then you can use MyList.this.somemethod() to call methods of List class
 */
public class _28_Selective_Iterator_Using_List_2 {
    public static void main(String args[]){
        SelectionList2<Number> sl = new SelectionList2<>(new IntegerSelector());
        sl.add(new Double(2.5D));
        sl.add(new Long(4L));
        sl.add(new Integer(1));
        sl.add(new Integer(2));
        sl.add(new Integer(3));
        /*ArrayList<Integer> al = new ArrayList<>();
        al.add(1);al.add(2);al.add(3);
        for(int i=0; i<al.size(); i++){
            System.out.println(al.get(i));
        }*/
        Iterator it = sl.iterator();
        while(it.hasNext()){
            System.out.println(it.next());
        }
    }
}

class SelectionList2<T> extends ArrayList<T> {
    Selector<T> selector;
    public SelectionList2(Selector<T> selector) {
        this.selector = selector;
    }

    public Iterator<T> iterator() {
        return new SelectionIterator();
    }

    private class SelectionIterator implements Iterator<T> {
        int size;
        int i = 0;
        T curr ;
        public SelectionIterator() {
            size = SelectionList2.this.size(); // refer to method of ArrayList Class
            advance();
        }

        @Override
        public boolean hasNext() {
            return curr != null;
        }

        @Override
        public T next() {
            if (curr == null) {
                throw new NoSuchElementException();
            }
            T temp = (T) curr;
            curr = null; // This is very imp, as for last element curr will hold 3 and when u go to
            advance();  // advance method here then it will not nullify curr, making infinite loop
            return temp;
        }

        void advance() {
            while(i<size){
                T t = SelectionList2.this.get(i); // if you do get(i++) its wrong it first makes
                i++;                                    // ++ then evaluate
                if (selector.select(t)) {
                    curr = t;
                    break;
                }
            }

        }

    }
}

class IntegerSelector<T> implements Selector<T> {
    public boolean select(T t) {
        return t instanceof Integer;
    }
}

class DoubleSelector<T> implements Selector<T> {
    public boolean select(T t) {
        return t instanceof Double;
    }
}