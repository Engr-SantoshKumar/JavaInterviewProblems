package core.gi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Date: 3/11/19
 * Solution:
 * Remember:
 *
 * // -3 1
 * //  [-1], -1, -1
 * // [-1] -2,-1
*/
public class _10_Missing_Ranges {
    static StringBuilder sb = new StringBuilder();
    public static void main(String args[]) {
        int ar[] = { -5, -1, 2, 50, 52, 75, 98 };
        //int ar[] = {};
        System.out.println(Arrays.toString(ar));
        //getMissingList(ar, 0, 99);
        List<String> s =  findMissingRanges(ar, 1, 100);
        System.out.println(Arrays.toString(s.toArray()));
        System.out.println(sb);
      //ASSUMPTION , FIRST NUM IN ARRAY IS BETWEEN LOWER AND UPPER
        /*List<String> word = findMissingRanges(new int []{5}, -2,1 );
        System.out.println(Arrays.toString(word.toArray()));
    */}

    static List<String> findMissingRanges(int[] A, int lower, int upper) {
        List<String> res = new ArrayList<>();
        if (A.length == 0) {
            res.add(range(lower, upper));
            return res;
        }

        if (A[0] != lower) {
            res.add(range(lower, A[0] - 1));
        }

        for (int i = 1; i < A.length; i++) {
            if (A[i] == A[i-1] || A[i] == A[i-1] + 1) continue;
            res.add(range(A[i-1] + 1, A[i] -1));
        }

        if (A[A.length - 1] != upper) {
            res.add(range(A[A.length -1] + 1, upper));
        }
        return res;
    }

    static String range(int lo, int hi) {
        return lo == hi ? lo +"" : lo +"->" + hi;
    }

    /*static void getMissingList(int[] ar, int lower, int upper){
        if(ar == null || ar.length == 0){
            corner(lower, upper);
            return;
        }
        *//*if(ar[0] > lower && ar[0]>upper){
            corner(lower, upper);
            return;
        }
        if(ar[ar.length-1]>lower &&  ar[ar.length-1]>upper){
            corner(lower, upper);
            return;
        }*//*
        for(int i=1; i< ar.length; i++){
            int current = ar[i];
            if(current - lower >1){
                update(lower, current);
            }
            lower = current;
        }
        update(lower, upper);
    }*/
    static void corner(int lower, int upper){
        if(upper == lower){
            sb.append(lower);
            return;
        }else if(upper - lower == 1){
            sb.append(lower+", "+upper);
            return;
        }else{
            sb.append(lower+"->"+upper);
            return;
        }
    }
    static void update(int lower, int current){

        if(current - lower > 2){
            sb.append(lower+1);
            sb.append(" - "+(current-1));
        }else if(current - lower == 2){
            sb.append(lower+1);
        }
        sb.append(", ");
    }
}
