package core.gi;

/**
 * Date: 3/14/19
 * Problem Description: buying and selling shares one transaction
 * Solution:
 * Remember:
 */
public class _27_Stocks_Buy_Sell_1_Transaction {
    public static void main(String args[]) {
        int[] ar = new int[]{1, 12, 19, 3, 28, 37, 6, 3, 9, 12, 45, 67, 68,
                90, 91, 92, 93, 94}; // 18, 34, 91
        buySellShares(ar);
        buySellSharesMultipleTransactions(ar);


        int[] p = {100, 80, 120, 130, 70, 60, 100, 125};
        buySellSharesMultipleTransactions(p);
    }

    // this is easiest and is from INterview cake - 1 Transaction
    private static int buySellShares(int[] ar) {
        int profit = 0;
        int maxProfit = 0;
        int buy = ar[0];
        for (int j = 1; j < ar.length; j++) {
            profit = ar[j] - buy;
            maxProfit = Math.max(maxProfit, profit); // keep max profit
            buy = Math.min(buy, ar[j]);              // keep buy to minimum
        }
        System.out.println(" max profit 1 xactn " + maxProfit);
        return maxProfit;
    }

    // MULTI transactions, we add the profit of each window
    private static int buySellSharesMultipleTransactions(int[] ar) {
        int totalProfit = 0;
        for (int j = 1; j < ar.length; j++) {
            int currentProfit = ar[j] - ar[j - 1];
            if (currentProfit > 0) {
                totalProfit += currentProfit;
            }
        }
        System.out.println(" max profit multiple xactn " + totalProfit);
        return totalProfit;
    }

    static void buySellSharesNew(int[] ar) {
        int buy = ar[0];
        int profit = 0;
        for (int i = 1; i < ar.length; i++) {
            profit = Math.max(profit, ar[i] - buy);
            buy = Math.min(buy, ar[i]);
        }
        System.out.println(" max profit " + profit);
    }

    static void buySellSharesMultipleTransactionsNew(int[] ar) {
        int buy = ar[0];
        int sell = ar[1];
        int profit = 0;
        for (int i = 1; i < ar.length; i++) {
            sell = ar[i];
            if (sell >= buy) {
                profit += sell - buy;
                buy = sell;
            } else {
                buy = sell;
            }
        }
        System.out.println(" max profit multiple xactn " + profit);
    }
}
