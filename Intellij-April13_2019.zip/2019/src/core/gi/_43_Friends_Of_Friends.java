package core.gi;

import java.util.*;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _43_Friends_Of_Friends {
    public static void main(String args[]){
        Person p0 = new Person("P0");
        Person p1 = new Person("P1");
        Person p2 = new Person("P2");
        Person p3 = new Person("P3");
        Person p4 = new Person("P4");
        Person p5 = new Person("P5");

        p0.setFriends(p1);
        p0.setFriends(p2);
        p0.setFriends(p3);

        p1.setFriends(p3);p1.setFriends(p5);
        p2.setFriends(p1);
        p3.setFriends(p4);
        p4.setFriends(p3);p4.setFriends(p5);

        friendsOfFriends(p0);
    }
    static void friendsOfFriends(Person source){
        Set<Person> directFriends = source.friends;
        Set<Person> visited = new HashSet<>();
        List<Person> result = new ArrayList<>();
        for(Person friend : source.friends){
            dfs(friend, directFriends, visited, result);
        }
        System.out.println(" friends of friends of "+source + " => "
                +Arrays.toString(result.toArray()));
    }
    static void dfs(Person source, Set<Person> directFriends, Set<Person> visited,
                    List<Person> result){

        if(visited.contains(source)){
            return;
        }
        visited.add(source);

        for(Person friend : source.friends){
            if(!directFriends.contains(friend) && !result.contains(friend)){// dups in absence of
                result.add(friend);                                    // !results.contains() check
            }
            if(!visited.contains(friend)){
                dfs(friend, directFriends, visited ,result);
            }
        }
    }
}


class Person{
    public Person(String name) {
        this.name = name;

    }
    public void setFriends(Person p){
        friends.add(p);
    }
    String name;
    Set<Person> friends = new HashSet<>();
    public String toString(){
        return this.name;
    }
}