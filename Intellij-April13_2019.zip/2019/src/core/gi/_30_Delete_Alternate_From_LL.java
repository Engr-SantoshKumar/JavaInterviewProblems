package core.gi;

import core.MyLinkedList;
import core.Node;

/**
 * Date: 3/14/19
 * i/p- 9->8->5->7->     o/p: 9->5->
 * checked for blank, 1 elem, 2 elem, 3 elem etc, it is working fine
 * Remember: *********** if originalHead is not kept then o/p is null at end as we iterate head
 */
public class _30_Delete_Alternate_From_LL {
    public static void main(String[] args) {
        MyLinkedList ll = newMyLinkedList();
        MyLinkedList.iterate(ll.getFirst());
        MyLinkedList.iterate(deleteAlternate(ll));
    }

    static Node deleteAlternate(MyLinkedList ll){
        Node head = ll.getFirst();                         // 9->8->5->7-> head is 9
        Node originalHead = head;                          // original head = 9 ** important most
        while(head!=null && head.next!=null){    //1st iter          //2nd iter
            Node newHead = head.next.next;       // newHead = 5       newHead 5.n.n = null
            head.next.next = null;               // 5.next = null     7.next = null
            head.next = newHead;                 // 9.next = 5        5.next = null
            head = newHead;                      // head = 5          head   = null
        }
        return originalHead;  // if you return head here then o/p is null, becoz we iterate head
    }

    static MyLinkedList newMyLinkedList() {
        MyLinkedList ll = new MyLinkedList();
        ll.add(5);
        ll.add(7);
        ll.addFirst(8);
        ll.addFirst(9);
        return ll;
    }
}
