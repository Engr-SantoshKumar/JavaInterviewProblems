package core.gi;

import java.util.*;

/**
 * Date: 3/24/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class ____41_TreeMapDemo {
    public static void main(String args[]){

        TreeMap<Integer, String> map = new TreeMap<>();

        map.put(4, "four");
        map.put(1, "one");
        map.put(3, "three");
        map.put(2, "two");
        map.put(6, "six");

        StringBuilder sb = new StringBuilder();
        System.out.println(" map.higherKey(4) => "+map.higherKey(4)); // higher or null
        System.out.println(" map.lowerKey(4) => "+map.lowerKey(4));
        System.out.println(" map.ceilingKey(4) => "+map.ceilingKey(4)); // higher or equal
        System.out.println(" map.floorKey(4) => "+map.floorKey(4));

        System.out.println(" map.floorKey(6) => "+map.ceilingKey(6));
        System.out.println(" map.higherKey(6) => "+map.higherKey(6));
        System.out.println(" map.ceilingKey(5) => "+map.ceilingKey(5)); // higher or equal

        System.out.println(" map.ceilingEntry(5) => ("+map.ceilingEntry(5)+")");// results entry
                                                                                    // 6:six

        SortedMap<Integer, String> map2 = map.tailMap(3);
        for(Map.Entry e : map2.entrySet()){
            System.out.println(" pair "+e.getKey()+ " : " +e.getValue());
        }
        //map.higherKey(4));
        System.out.println(sb);

        TreeMap<String, String> treemap = new TreeMap<String, String>();

        // Put elements to the map
        treemap.put("Key1", "Jack");
        treemap.put("Key2", "Rick");
        treemap.put("Key3", "Kate");
        treemap.put("Key4", "Tom");
        treemap.put("Key5", "Steve");

        // Calling the method sortByvalues
        Map sortedMap = sortByValues(treemap);

        // Get a set of the entries on the sorted map
        Set set = sortedMap.entrySet();

        // Get an iterator
        Iterator i = set.iterator();

        // Display elements
        while(i.hasNext()) {
            Map.Entry me = (Map.Entry)i.next();
            System.out.print(me.getKey() + ": ");
            System.out.println(me.getValue());
        }
    }

    public static <K, V extends Comparable<V>> Map<K, V>
    sortByValues(final Map<K, V> map) {
        Comparator<K> valueComparator =
                new Comparator<K>() {
                    public int compare(K k1, K k2) {
                        int compare =
                                map.get(k1).compareTo(map.get(k2));
                        if (compare == 0)
                            return 1;
                        else
                            return compare;
                    }
                };

        Map<K, V> sortedByValues =
                new TreeMap<K, V>(valueComparator);
        sortedByValues.putAll(map);
        return sortedByValues;
    }

}
