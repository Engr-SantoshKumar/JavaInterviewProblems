package core.gi;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Implement a class that manages a counter.  The counter can be incremented by 1, and we can query
 * the counter to find out how often it was incremented in the last second, the last minute, and the
 * last hour.
 * <p>
 * Solution:
 * Remember:
 */
public class _39_Class_Of_Time_And_Counter {
    static int secCounter = 0;
    static int minCounter = 0;
    static int hrCounter = 0;

    public static void main(String args[]) {
        System.out.println(System.currentTimeMillis());


        long sec = System.currentTimeMillis() / 1000;
        long min = sec * 50;
        long hr = min * 50;

        /*sec = System.currentTimeMillis()/100; // consider 10 sec as 1 sec
        min = sec*50; // min as 500 sec = 1 min
        hr = min*50;  //*/
        long start = System.currentTimeMillis();
        long end = start + 1000 * 60 * 2; //start + 2mins
        while(true) {
            try {
                Thread.sleep(100); // sleep for 1/10 of sec, so gen 10 entries in 1 sec
                hitCounter();
                if(System.currentTimeMillis() - start > 1000 * 60 * 2){
                    break;
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }
    }

    static Queue<Long> qSec = new ArrayDeque<>();
    static Queue<Long> qMin = new ArrayDeque<>();
    static Queue<Long> qhr = new ArrayDeque<>();
    static void hitCounter() {


        long currTimeSec = System.currentTimeMillis() / 1000;


        qSec.offer(currTimeSec);
        secCounter++;
        System.out.println("size " +qSec.size());
        System.out.println(qSec);
        currTimeSec = System.currentTimeMillis() / 1000;
        while (!qSec.isEmpty() && currTimeSec - qSec.peek() > 0) {
            secCounter--;
            minCounter++;
            qMin.offer(qSec.poll());
        }

        while (!qMin.isEmpty() && currTimeSec - qMin.peek()> 60) {
            minCounter--;
            hrCounter++;
            qhr.offer(qMin.poll());
        }

        while (!qhr.isEmpty() && currTimeSec - qhr.peek() > 60*60) {
            hrCounter--;
            qhr.poll();
        }
        System.out.println(" at this time sec counter " + qSec.size());
        System.out.println(" at this time min counter " + (qMin.size()+qSec.size()));
        System.out.println(" at this time hr counter " + (qhr.size()+qMin.size()+qSec.size()));

    }
}
