package core.gi;

import java.util.HashSet;
import java.util.Set;

/**
 * Date: 3/13/19
 * Simple is to use a SET if that is not allowed then we have another 2 methods
 * - if it is only lower case we can use char array of 26
 * - If mixed case we definitely need char array of 127 and you dont need to do c-'a' in this case
 *   Basically ENGLISH KEYBOARD'S all letters are covered in 127, and in 256 it covers another
 *   language special chars, but not chinese, for chinese unicode
 *   https://theasciicode.com.ar/
 */
public class _16_CanThe_Word_Made_With_Given_Chars {
    public static void main(String[] args) {
        char[] car = new char[]{ 'a','c','e','Z'};
        System.out.println(possibleWordsInLowerCaseCharsMixedCase(car, "aceZ"));
        char[] car1 = new char[]{ 'a','c','e'};
        System.out.println(possibleWordsInLowerCaseChars(car1, "ace"));
        System.out.println(possibleWithSet(car, "aceZ"));
    }
    static boolean possibleWordsInLowerCaseChars(char[] car, String s){
        boolean[] ar = new boolean[26];
        for(char c : car){
            int index = c-'a';
            ar[index] = true;
        }
        for(char c : s.toCharArray()){
            int index = c-'a';
            if(!ar[index]){
                return false;
            }
        }
        return true;
    }

    static boolean possibleWordsInLowerCaseCharsMixedCase(char[] car, String s){
        boolean[] ar = new boolean[127];
        for(char c : car){
            int index = c;
            ar[index] = true;
        }
        for(char c : s.toCharArray()){
            if(!ar[c]){
                return false;
            }
        }
        return true;
    }

    static boolean possibleWithSet(char[] car, String s){
        Set<Character> set = new HashSet<>();
        for(char c : car){
            set.add(c);
        }
        for(char c : s.toCharArray()){
            if(!set.contains(c)){
                return false;
            }
        }
        return true;
    }
}
