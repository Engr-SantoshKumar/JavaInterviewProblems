package core.gi;

import java.util.Arrays;

/**
 * Date: 3/17/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _60_Move_Zeroes_To_End_Of_Array {
    public static void main(String args[]) {
        int[] ar = new int[]{1, 6, 0, 3, 8, 9, 0, 2};
        System.out.println(Arrays.toString(ar));
        moveZeroesToEnd(ar);
        System.out.println(Arrays.toString(ar));
    }

    static void moveZeroesToEnd(int[] ar) {
        int count = 0;
        for (int i = 0; i < ar.length; i++) {
            ar[count] = ar[i];
            if (ar[i] > 0) {
                count++;
            }
        }
        while(count<ar.length){
            ar[count++] = 0;
        }
    }

    static void swap(int i, int j, int[] ar) {
        System.out.println(" swapping " + i + " with " + j);
        int temp = ar[i];
        ar[i] = ar[j];
        ar[j] = temp;
    }
}
