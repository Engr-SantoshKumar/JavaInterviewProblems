package core.gi;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _46_Even_Numbers_Even_Indices {
    public static void main(String args[]){
        int[] ar = new int[] { 1 , 3 , 5 , 8 , 10 , 13 , 18 , 36 , 78 };
        print(ar);
        print(null);
        print(new int[]{});
    }
    static void print(int[] ar){
        if(ar == null || ar.length==0){
            System.out.println(" \n invalid input ");
            return;
        }
        for(int i=0;i<ar.length;i++){
            if(i%2==0){
                System.out.print(".. ["+i+" ,"+ar[i]+"]");
            }
        }
    }
}
