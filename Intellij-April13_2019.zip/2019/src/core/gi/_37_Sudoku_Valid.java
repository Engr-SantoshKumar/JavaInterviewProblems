package core.gi;

import java.util.HashSet;
import java.util.Set;

/**
 * {'5', '3', '.', '.', '8', '.', '.', '.', '.'},
 * {'6', '.', '.', '1', '9', '5', '.', '.', '.'},
 * {'.', '9', '8', '.', '.', '.', '.', '6', '.'},
 * {'8', '.', '.', '.', '6', '.', '.', '.', '3'},
 * {'4', '.', '.', '8', '.', '3', '.', '.', '1'},
 * {'7', '.', '.', '.', '2', '.', '.', '.', '6'},
 * {'.', '6', '.', '.', '.', '.', '2', '8', '.'},
 * {'.', '.', '.', '4', '1', '9', '.', '.', '5'},
 * {'.', '.', '.', '.', '8', '.', '.', '7', '9'}
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _37_Sudoku_Valid {


    static boolean validate(char[][] M){
        System.out.println(" row validator");
        // validate all rows
        for(int row=0; row<M.length; row++){

            if(!validateHelper(row, 0, 1, M[0].length, M)){
                return false;
            }
        }

        System.out.println(" col validator");
        // validate all cols
        for(int col=0; col<=M[0].length; col++){

            if(!validateHelper(0, col, M.length, 1, M)){
                return false;
            }
        }

        // validate Box
        validateBox(M);
        return true;
    }
    static boolean validateBox(char[][] M) {
        int rS = 0;
        int rE = M.length;
        int cS;
        int cE = M[0].length;
        int offSet = (int) Math.sqrt(M.length);
        // RS would be 0,3,6 - Cs Should be
        while (rS + offSet <= rE) { // jump rows after every offset(3) rows, here validate first 3
            cS = 0;                 // rows, then in it validate 3 boxes
            while (cS + offSet <= cE) { // jump cols after every offset(3) cols
                if (!validateHelper(rS, cS, offSet, offSet, M)) {// first call 0, 0 meaning
                    return false;
                }
                cS += offSet;
            }
            rS += offSet;
        }
        return true;
    }

    //when called from the box validator
    // call 0,0 meaning this function will  calc 0-3 rows and 0-3 cols
    // second call 0, 3 meaning row 0-3, col 3-6, third: 0,3 and 6-9
    static boolean validateHelper(int rS, int cS, int rowOffSet, int colOffset, char[][] M) {
        int boxSum = 0;
        for (int row = rS; row < rS + rowOffSet; row++) {
            Set<Character> visited = new HashSet<>();
            for (int col = cS; col < cS + colOffset && col < M[0].length; col++) {
                if (visited.contains(M[row][col])) {
                    return false;
                }
                if (M[row][col] != '.') {
                    boxSum += M[row][col] - '0';
                    visited.add(M[row][col]);
                }
            }
        }
        System.out.println(" this box sum " + boxSum);
        return true;
    }

    /*static boolean validateBox(char[][] M) {
        int rS = 0;
        int rE = 9;
        int cS = 0;
        int cE = 9;
        while (rS + 3 < rE) {
                for (int row = rS; row < rS+3; row++) {
                    Set<Character> visited = new HashSet<>();
                    for (int col = cS; col < cS+3 && col<9; col++) {
                        int boxSum = 0;
                        if(visited.contains(M[row][col])){
                            return false;
                        }
                        if(M[row][col] !='.'){
                            boxSum+=Integer.valueOf(M[row][col]);
                            visited.add(M[row][col]);
                        }
                        System.out.println(" this box sum "+boxSum);
                    }
                    cS+=3;
                }
                rS+=3;
        }
        return true;
    }
*/
    public static void main(String args[]) {
        char[][] M = new char[][]{
                {'5', '3', '.', '.', '8', '.', '.', '.', '.'},
                {'6', '.', '.', '1', '9', '5', '.', '.', '.'},
                {'.', '9', '8', '.', '.', '.', '.', '6', '.'},
                {'8', '.', '.', '.', '6', '.', '.', '.', '3'},
                {'4', '.', '.', '8', '.', '3', '.', '.', '1'},
                {'7', '.', '.', '.', '2', '.', '.', '.', '6'},
                {'.', '6', '.', '.', '.', '.', '2', '8', '.'},
                {'.', '.', '.', '4', '1', '9', '.', '.', '5'},
                {'.', '.', '.', '.', '8', '.', '.', '7', '9'}
        };
        System.out.println(validate(M));
    }
}
