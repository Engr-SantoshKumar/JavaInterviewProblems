package core.gi;

import java.util.*;
import java.util.concurrent.ConcurrentSkipListSet;

/**
 * Date: 3/10/19
 * * Remember: ConcurrentSkipListSet for fail safe operation..
 */
public class _3_LongestConcecutiveInteger {
    public static void main(String args[]){
        int arr[] = new int[] { 36, 41, 56, 35, 44, 33, 34, 92, 43, 32, 42 };
        System.out.println(" longest concecutive list is "+longestList(arr));
    }
    static int longestList(int[] ar){
        // load to set
        Set<Integer> set = new ConcurrentSkipListSet<>();
        for(int elem : ar){
            set.add(elem);
        }
        Iterator<Integer> it = set.iterator(); // specify the Iterator type ex<Integer> else it is
                                               // cast is asked
        int longestListCount = 0;
        for(int item : set){
            List<Integer> thisList = new ArrayList<>();
            int before = item; // This is very important, if you just pass item on below while
                               // loop your answer will be wrong
            int after = item;
            set.remove(item);
            int count = 1;
            thisList.add(item);
            while(set.contains(--before)){
                thisList.add(before);
                set.remove(before);
                count++;
            }

            while(set.contains(++after)){
                thisList.add(after);
                set.remove(after);
                count++;
            }
            longestListCount = Math.max(longestListCount, count);
        }
        return longestListCount;
    }
}
