package core.gi;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * Date: 3/10/19
 * when intervals are not sorted then we need to sort them
 */
public class _2_MergeIntervalsNotSorted {
    public static void main(String args[]){
        List<Interval> intervalList = createIntervalList();
        Collections.sort(intervalList, new Comparator<Interval>(){
            public int compare(Interval a, Interval b){
                return a.start - b.start;
            }
        });
        Interval in = new Interval(4, 13);
        List<Interval> result = _2_MergeIntervals.insertInterval(intervalList, in);
        for(Interval interval : result){
            System.out.println(interval.start+", "+interval.end);
        }
    }
    static private List<Interval> createIntervalList() {
        List<Interval> list = new ArrayList<Interval>();
        list.add(new Interval(1, 5));
        list.add(new Interval(15, 20));
        list.add(new Interval(7, 10));
        list.add(new Interval(25, 35));
        System.out.println("Initial interval List");
        return list;
    }
}
