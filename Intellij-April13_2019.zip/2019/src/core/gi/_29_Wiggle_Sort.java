package core.gi;

import java.util.Arrays;

/**
 * Date: 3/14/19
 * Problem Description:
 * Sort an array of numbers u = [u1, u2, ... uN ] so that, for its sorted
 * version s = [s1, s2, ..., sN]
 * where: s1 <= s2 >= s3 <= s4 ...
 * Solution:
 * ** very imp to keep [ (i+1) <ar.length ]  or [ i< ar.length-1 ]-1, else it fails miserably
 *
 *  input : []  : output : []
 *  input : [1]  : output : [1]
 *  input : [1, 2]  : output : [1, 2]
 *  input : [1, 2, 3]  : output : [1, 3, 2]
 *  input : [1, 2, 3, 5]  : output : [1, 3, 2, 5]
 *  input : [1, 2, 3, 5, 6]  : output : [1, 3, 2, 6, 5]
 * Remember: (i+1) < ar.length
 */
public class _29_Wiggle_Sort {
    static int[] ar0 = new int[]{};
    static int[] ar1 = new int[]{1};
    static int[] ar2 = new int[]{1, 2};
    static int[] ar3 = new int[]{1, 2, 3};
    static int[] ar4 = new int[]{1, 2, 3, 5};
    static int[] ar5 = new int[]{1, 2, 3, 5, 6};

    public static void main(String args[]) {
        System.out.println("\n\n** very imp to keep [ (i+1)<ar.length ]  or [ i< ar.length-1 ]"
                +"-1, else it fails miserably");
        testFor(ar0);
        testFor(ar1);
        testFor(ar2);
        testFor(ar3);
        testFor(ar4);
        testFor(ar5);
    }
    static void testFor(int[] ar){
        System.out.print("\n input : " +Arrays.toString(ar));
        wiggleSort(ar);
        System.out.print("  : output : "+Arrays.toString(ar));
    }

    static void wiggleSort(int[] ar) {
        //*** very important to keep (i+1)<ar.length or i< ar.length -1, else it fails miserably
        for (int i = 1; (i+1) < ar.length; i += 2) {
            swap(i, i + 1, ar);
        }
    }

    static void swap(int i, int j, int[] ar) {
        int temp = ar[i];
        ar[i] = ar[j];
        ar[j] = temp;
    }
}
