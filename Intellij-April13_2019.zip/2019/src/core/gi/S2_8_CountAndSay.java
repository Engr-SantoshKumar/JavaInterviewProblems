package core.gi;

/**
 * Date: 3/25/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class S2_8_CountAndSay {
    public static void main(String args[]) {
        System.out.println((countAndSay(5, "11")));
    }

    static String countAndSay(int n, String ip) {
        if (n == 0) {
            return ip;
        }
        StringBuilder sb = new StringBuilder();
        for (int j = 0; j < ip.length(); ) {
           int count=1;
           while(j+1<ip.length() && ip.charAt(j+1) == ip.charAt(j) ){
               j++;
               count++; //count would be 2 if input is 11, prev 1 curr 1 count =2
            }
           sb.append(count);
           sb.append(ip.charAt(j));
            j++; // do j++ all the time as we already considered the next, i.e j+1 th element
        }
        System.out.println(ip+" new ip "+sb.toString());
        return countAndSay(n-1, sb.toString());
    }

    //OLD
    static void countAndSay(int n) {
        StringBuilder sb = new StringBuilder();
        sb.append(1);
        //.sb.append(1);
        for(int i=1; i<=n; i++) {
            System.out.println(": calling with "+sb);
            StringBuilder sb1 = cns(sb);
            sb = new StringBuilder(sb1);
        }

        System.out.println("sb "+sb);
    }
    static StringBuilder cns(StringBuilder sbb) {
        System.out.println(" calling "+sbb);
        char[] ar = sbb.toString().toCharArray();

        int prev = Character.getNumericValue(ar[0]);
        int count =1;
        StringBuilder sb = new StringBuilder();
        for(int i=1;i<ar.length;i++) {
            System.out.println(" reunning for "+ar[i]+" prev "+prev);

            if(Character.getNumericValue(ar[i]) == prev) {
                count ++;
            }else {
                sb.append(count);
                sb.append(prev);
                count=1;
            }
            prev = Character.getNumericValue(ar[i]);

        }
        sb.append(count);
        sb.append(prev);
        System.out.println("sb returned "+sb);
        return sb;
    }
}
