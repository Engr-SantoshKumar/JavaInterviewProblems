package core.gi;

import core.api.Node;
import core.api.TreePrint;

/**
 * Date: 3/10/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _5_WeightedSubtree {
    public static void main(String args[]) {
        Node r = TreePrint.create(new int[]{5, -1, 3, -2, 4, -6, 10});
        System.out.println(sum(r));
        TreePrint.print(r);
        // The original problem is not wighted printing weighted tree its just limited to print
        // i guess but if below is intent we can do as follows
        converToWeightedTree(r);
        System.out.println("\n*** weighted Tree is ****");
        TreePrint.print(r);
    }

    static int sum(Node root) {
        if (root == null) {
            return 0;
        }
        System.out.println(" weighted for node"+root.data+" is "+(root.data + sum(root.left) + sum(root.right)));
        return root.data + sum(root.left) + sum(root.right);
    }

    static int converToWeightedTree(Node root) {
        if (root == null) {
            return 0;
        }
        root.data = root.data + converToWeightedTree(root.left) + converToWeightedTree(root.right);
        return root.data;
    }
}
