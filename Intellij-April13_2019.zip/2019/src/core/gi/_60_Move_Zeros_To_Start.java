package core.gi;

import java.util.Arrays;

/**
 * Date: 3/17/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * all the zeroes to the beginning of the array (while leaving the order of the other
 * <p>
 * numbers intact). Example:
 * <p>
 * [ 4, 5, 6, 1, 0, 6, 8, 0, 0, 8, 9, 10 ]
 * [ 0, 0, 0, 4, 5, 6, 1, 6, 8, 8, 9, 10 ]"
 * Solution:
 * Remember:
 */
public class _60_Move_Zeros_To_Start {
    public static void main(String args[]) {
        int[] ar = new int[]{4, 5, 6, 1, 0, 6, 8, 0, 0, 8, 9, 10};
        testFor(ar);
        testFor(new int[]{1,0});
        testFor(new int[]{1,2});
        testFor(new int[]{1,0, 2});
        testFor(new int[]{0,2, 0});
        testFor(new int[]{0});
        testFor(new int[]{1});
        testFor(new int[]{});
        testFor(null);
    }

    static void testFor(int[] ar){
        System.out.println("-----------------------------");
        System.out.println(" input " + Arrays.toString(ar));
        moveZeroesToStart(ar);
        System.out.println(" output " + Arrays.toString(ar));
    }

    static void moveZeroesToStart(int[] ar) {
        if(ar == null || ar.length==0){
            System.out.println(" invalid input ");
            return;
        }

        int count = ar.length-1;
        for (int i = ar.length-1; i>=0; i--) {
            ar[count] = ar[i];
            if (ar[i] > 0) {
                count--;
            }
        }
        while(count>=0){
            ar[count--] = 0;
        }
    }

    static void moveZeroes(int[] ar) {
        for (int i = ar.length - 1; i > 0; i--) {
            if (ar[i] == 0) {
                int j = i;
                while (j > 0 && ar[j] == 0) {
                    j--;
                }
                swap(i, j, ar);
            }
        }
    }

    static void moveZeroes1(int[] ar) {
        int i = ar.length - 1;
        int j = i;
        while (i > 0 && j >= 0) {
            // find a zero element
            while (i > 0 && ar[i] != 0) {
                i--;
            }
            if (j > i) {
                j = i;
            }
            while (j > 0 && ar[j] == 0) {
                j--;
            }
            // if(i>=0 && j>=0){
            swap(i, j, ar);
            //}
            i--;
            j--;
            System.out.println(Arrays.toString(ar));
        }
    }

    static void swap(int i, int j, int[] ar) {
        System.out.println(" swapping " + i + " with " + j);
        int temp = ar[i];
        ar[i] = ar[j];
        ar[j] = temp;
    }
}
