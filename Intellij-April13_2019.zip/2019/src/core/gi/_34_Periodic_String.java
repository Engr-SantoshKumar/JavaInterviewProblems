package core.gi;

import java.util.Arrays;

import static core.gi.____34_Periodic_String.repeatedSubstringPattern2;

/**
 * Date: 3/23/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _34_Periodic_String {
    public static void main(String args[]) {
        String x = "abdabc";
        testFor("a");
        testFor("ab");
        testFor("abc");
        testFor("abcd");
        testFor("abab");
        testFor("abababx");//wrong ans
        testFor("abcabc");
        testFor("abdabc");
        testFor("abcabcx");
        testFor("abcdabcy");
    }

    static void testFor(String s) {
        System.out.println("\n--------input " + s);
        repeatedSubstringPattern(s);
        repeatedSubstringPattern2(s);
    }

    static void repeatedSubstringPattern(String s) {

        // build suffix array
        int[] ar = new int[s.length()];
        char[] c = s.toCharArray();
        int j = 1;
        int i = 0;

        while (j < ar.length) {
            if (c[i] == c[j]) {
                ar[j] = i + 1;
                i++;
                j++;
            } else {
                if (i > 0) {
                    int idx = ar[i - 1];
                    ar[j] = idx;
                } else {
                    ar[j] = 0;
                }
                j++;
            }
        }
        System.out.println(" p1... "+Arrays.toString(ar));

    }
}
