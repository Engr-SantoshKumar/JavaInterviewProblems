package core.gi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Date: 3/16/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _52_Search_Item_And_Iterator {
    static String space = "";

    public static void main(String args[]) {
        assert("".substring(0,0)).equals("");
        assert("a".substring(0,1)).equals("a");  // you can go one index up for substr
        //assert("a".substring(0,2).equals("ab"));   //Iout of bound error
       // System.out.println("a".substring(0,2));
        String search = "sunmoon";
        System.out.println("aaasun".endsWith(search));
        List<String> list = new ArrayList<>();
        list.add("abc");
        list.add(""); // "".subString(0,0); is fine ""
        list.add("a");// "a".subString(0,0); is fine "a"
        list.add("sun");
        list.add("moos");
        list.add("sun");
        list.add("mo");
        list.add("on");
        list.add("done");
        boolean exist = isExists(search, list.iterator());
        System.out.println(" does exist " + exist);       // True
    }

    static boolean isExists(String s, Iterator<String> it) {


        while (it.hasNext()) {
            String token = it.next();
            space += token;
            System.out.println(space);
            if (space.contains(s)) {
                return true;
            }
            space = space.substring(getLastMisMathcIndex(space, s));
        }
        return false;
    }

    static int getLastMisMathcIndex(String space, String s) {
        int toReject = -1;
        int j = 0;
        for (int i = 0; i < space.length(); i++) {
            if (space.charAt(i) != s.charAt(j)) {
                toReject = i;
            } else {
                j++;
            }
        }
        if (toReject == -1) {
            return 0;
        }
        return toReject + 1;
    }
}

