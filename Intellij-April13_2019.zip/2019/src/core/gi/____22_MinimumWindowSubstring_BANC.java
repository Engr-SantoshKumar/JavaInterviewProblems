package core.gi;

import java.util.HashMap;
import java.util.Map;

/**
 * Date: 3/13/19
 * Problem Description:
 * Solution:
 * Remember:
 */
public class ____22_MinimumWindowSubstring_BANC {
    public static void main(String[] args) {
       /* String s="ADOBECODEBANC";
        String t = "ABC";*/
        String s="aa";
        String t = "aa";
        String result = "";
        System.out.println(minWindow2(s,t));
        //System.out.println(" result "+result);
    }
    static String minWindow(String s, String t){
        String result = "";
        Map<Character, Integer> tMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        //load map
        for(int i=0; i<t.length(); i++){
            char c = t.charAt(i);
            tMap.put(c, tMap.containsKey(c)? tMap.get(c)+1: 1);
        }
        if(tMap.size() == s.length() && s.length() == t.length()){
            for(char c : s.toCharArray()){
                if(!tMap.containsKey(c)){
                    return "";
                }
            }
        }
        if(t.length()>s.length()){
            return"";
        }
        Map<Character, Integer> map = new HashMap<>();

        for(int i=0; i<s.toCharArray().length; i++){
            char c = s.charAt(i);
            sb.append(c);
            if(tMap.containsKey(c)){
                map.put(c, map.containsKey(c)? map.get(c)+1: 1);
            }

            if(map.size() >= tMap.size()){
                System.out.println(" now map .size is same or greater");
                String ss = sb.toString();
                System.out.println(" now analyzing "+ss);
                int m = 0;
                int index = 0;
                char temp = ss.charAt(m);

                // we will shrink the string one char a time, if the current char is not in map
                // we can ignore and move fwd, if cur char in map then reduce its value if >1
                // the loop stops where we have all chars exactly once in our array
                while (m < ss.length() && (!map.containsKey(temp) || (map.get(temp) >= tMap.get(temp)))) {
                    if (map.containsKey(temp) && map.get(temp) > tMap.get(temp)) {

                        map.put(temp, map.get(temp) - 1);
                    }
                    String res = ss.substring(index);
                    System.out.println(" new ruslt is " + res);
                    sb = new StringBuilder(res);
                    if (result.equals("") || res.length() < result.length()) {
                        result = res;
                        System.out.println(" a result is stored as " + result);
                    }
                    index++;
                    m++;
                    temp = ss.charAt(m);
                }
            }
        }
        return result;
    }
    /*static String minWindow(String s, String t){
        String result = s;
        Map<Character, Integer> tMap = new HashMap<>();
        StringBuilder sb = new StringBuilder();
        //load map
        for(int i=0; i<t.length(); i++){
            char c = t.charAt(i);
            tMap.put(c, tMap.containsKey(c)? tMap.get(c)+1: 1);
        }
        if(tMap.size() == s.length()){
            for(char c : s.toCharArray()){
                if(!tMap.containsKey(c)){
                    return "";
                }
            }
        }
        Map<Character, Integer> map = new HashMap<>();

        for(int i=0; i<s.toCharArray().length; i++){
            char c = s.charAt(i);
            sb.append(c);
            if(tMap.containsKey(c)){
                map.put(c, map.containsKey(c)? map.get(c)+1: 1);
            }

            if(map.size() >= tMap.size()){
                System.out.println(" now map .size is same or greater");
                String ss = sb.toString();
                System.out.println(" now analyzing "+ss);
                int m = 0;
                int index = 0;
                char temp = ss.charAt(m);

                // we will shrink the string one char a time, if the current char is not in map
                // we can ignore and move fwd, if cur char in map then reduce its value if >1
                // the loop stops where we have all chars exactly once in our array
                while (m < ss.length() && (!map.containsKey(temp) || (map.get(temp) > 1))) { // for
                    if (map.containsKey(temp) && map.get(temp) > 1) {// duplicate change map.get
                                                        // (t)>1 to map.get(temp) > tMap.get(temp)
                        map.put(temp, map.get(temp) - 1);
                    }
                    index++;
                    m++;
                    temp = ss.charAt(m);
                }
                // The above loop can be simplified or understood in below commented loop
                *//*while (m < ss.length()) {
                    char temp = ss.charAt(m);
                    if (!map.containsKey(temp)) {
                        index ++;
                        m++;
                        continue;
                    }else if(map.get(temp) > 1 ){
                        map.put(temp, map.get(temp)-1);
                        index++;
                        m++;
                        continue;
                    }else{
                        break;
                    }

                }*//*
                String res = ss.substring(index);
                System.out.println(" new ruslt is "+res);
                sb = new StringBuilder(res);
                if(res.length() < result.length()){
                    result = res;
                    System.out.println(" a result is stored as "+result);
                }
            }
        }
        return result;
    }*/

    // OLD Method
    static String minWindow2(String s, String t) {
        String result="";
        int minLen=Integer.MAX_VALUE;
        int left =0;
        //initialize target Map
        Map<Character, Integer> target = new HashMap<>();
        for(int i=0; i<t.length(); i++) {
            char c = t.charAt(i);
            if(target.containsKey(c)) {
                target.put(c, target.get(c)+1);
            }else {
                target.put(c, 1);
            }
        }
        Map<Character, Integer> currMap = new HashMap<>();
        for(int i=0; i<s.length(); i++) {
            char c = s.charAt(i);
            if (target.containsKey(c)) {
                if (currMap.containsKey(c)) {
                    currMap.put(c, currMap.get(c) + 1);
                } else {
                    currMap.put(c, 1);
                }
            }
            //if currMap has all the chars in target
            if(currMap.size() == target.size()) {
                // this is time to shrink and find the min char len
                char leftC=s.charAt(left);
                //shrink the str if current char is not in map
                //or if curr char is in map but its count in map is greater than in target
                //lets say in target A-1, B2, C3 if in our map we have A2 then we only need one A
                // so when we have only 1 A left we break the loop B-2 B-3

                while(!currMap.containsKey(leftC) || currMap.get(leftC)>=target.get(leftC)) {
                    if(currMap.containsKey(leftC) && currMap.get(leftC)>=target.get(leftC)) {
                        currMap.put(leftC, currMap.get(leftC)-1);
                        left--;
                    }
                    left++;
                    leftC=s.charAt(left);
                }
                if(i-left+1<minLen) {
                    result = s.substring(left, i+1);
                    System.out.println(" this could be rsult "+result);
                    minLen = i-left+1;
                }

            }

        }
        return result;
    }
}
