package core.gi;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Date: 3/13/19
 * Solution accepted by Leetcode,
 * Important check i<j at every stage because internal while loop
 * has potential to run i > ar.len
 * and similarly j< 0
 * : input : epppppppi => : ipppppppe
 * : input : aA => : Aa
 * : input : united states => : enated stitus
 * : input : united => : enitud
 * : input :  => :
 * : input : sun => : sun
 * : input : moon => : moon
 * : input : **{} => : **{}
 * : input : magic => : migac
 * : input : maec => : meac
 * : input : mntc => : mntc
 */
public class _20_Reverse_Vowels_InString {
    static String reverseVowels(String str) {
        Set<Character> vowels = new HashSet<>();
        vowels.add('a');
        vowels.add('e');
        vowels.add('i');
        vowels.add('o');
        vowels.add('u');
        vowels.add('A');
        vowels.add('E');
        vowels.add('I');
        vowels.add('O');
        vowels.add('U');
        char[] car = str.toCharArray();
        int i = 0;
        int j = car.length - 1;
        while (i < j) {

            while (i < j && !vowels.contains(car[i])) { // Important i<j here or Array index oob err
                i++;
            }
            while (i < j && !vowels.contains(car[j])) {
                j--;
            }
            char temp = car[i];
            car[i] = car[j];
            car[j] = temp;
            i++;
            j--;
        }
        return new String(car);
    }

    static void testFor(String sentence){
        System.out.print("\n: input : "+sentence);
        System.out.print(" => : "+reverseVowels(sentence));
    }
    public static void main(String[] args) {
        //String sentence = "epppppppi";
        testFor("epppppppi");
        testFor("aA");
        testFor("united states");
        testFor("united");
        testFor("");
        testFor("sun");
        testFor("moon");
        testFor("**{}");
        testFor("magic");
        testFor("maec");
        testFor("mntc");

    }
}

