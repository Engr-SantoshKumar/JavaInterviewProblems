package core.gi;

/**
 * Date: 3/14/19
 */
public class InvalidException extends Exception{
    public InvalidException(String message){
        super(message);
    }
}