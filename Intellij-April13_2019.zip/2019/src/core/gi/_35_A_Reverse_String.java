package core.gi;

import org.omg.CORBA.DynAnyPackage.Invalid;

/**
 * Date: 3/14/19
 */
public class _35_A_Reverse_String {
    public static void main(String args[]) throws InvalidException{
        testFor("");
        testFor("S");
        testFor("DJ");
        testFor("SUN");
        testFor("ABCD");
       // testFor(null);
    }
    static void testFor(String s) throws InvalidException{
        System.out.println(" input " + s + " rev " + reverse(s));
        System.out.println(" input " + s + " revrec " + reverseRecursive(s));
    }

    static String reverse(String s) throws InvalidException{
        if(s == null){
            System.out.println(" invalid input");
            throw new InvalidException("Invalid Input..");
        }
        char[] car = s.toCharArray();
        int i = 0;
        int j = car.length - 1;
        while (i < j) {
            char temp = car[i];
            car[i++] = car[j];
            car[j--] = temp;
        }
        return new String(car);
    }

    static String reverseRecursive(String s) throws InvalidException{
        if(s == null){
            System.out.println(" invalid input");
            throw new InvalidException("Invalid Input..");
        }
        char[] car = s.toCharArray();
        reverseRec(car, 0, s.length() - 1);
        return new String(car);
    }

    static void reverseRec(char[] ar, int start, int end) {
        if (end <= start) {
            return;
        }
        reverseRec(ar, start + 1, end - 1);
        swap(start, end, ar);
    }

    static void swap(int i, int j, char[] car) {
        char temp = car[i];
        car[i++] = car[j];
        car[j--] = temp;
    }
}
