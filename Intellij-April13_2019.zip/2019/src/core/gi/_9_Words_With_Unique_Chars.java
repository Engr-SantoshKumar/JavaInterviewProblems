package core.gi;

import java.util.*;

/**
 * Date: 3/11/19
 * Important, how mix case can be handled, if it is capitals then do c-'A' so 0-20 stores capitals
 * and for (c-'a')+27 stores small letters from 27..52
 */
public class _9_Words_With_Unique_Chars {
    public static void main(String[] args) {
        int x = 'a';
        System.out.println(x);
        String words[] = {"May", "student", "students", "dog",
                "studentssess", "god", "cat", "act", "Tab",
                "bat", "flow", "wolf", "lambs", "aMy", "yam",
                "balms", "looped", "poodle"};
        int n = words.length;
        Map<String, List<String>> map = uniqueCharStrs(words);
        for (List<String> list : map.values()) {
            System.out.println(Arrays.toString(list.toArray()));
        }
    }

    static Map<String, List<String>> uniqueCharStrs(String[] words) {
        Map<String, List<String>> map = new HashMap<>();
        for (String word : words) {
            String key = getKeyMixedCase(word);
            if (map.containsKey(key)) {
                map.get(key).add(word);
            } else {
                List<String> list = new ArrayList<>();
                list.add(word);
                map.put(key, list);
            }
        }
        return map;
    }

    static String getKey(String s) {
        boolean[] ar = new boolean[26];
        for (char c : s.toCharArray()) {
            ar[c - 'a'] = true;
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ar.length; i++) {
            if (ar[i] == true) {
                sb.append(i + 'a');
            }
        }
        return sb.toString();
    }

    static String getKeyMixedCase(String s) {
        boolean[] ar = new boolean[52];

        for (char c : s.toCharArray()) {
            boolean x = Character.isUpperCase(c);
            if (x) {
                int t = c - 'A';
                ar[t] = true;
            } else {
                int t = c - 'a';
                ar[t + 27] = true;
            }
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < ar.length; i++) {
            if (ar[i] == true) {
                sb.append(i + 'a');
            }
        }
        return sb.toString();
    }
}
/*
[cat, act]
[tab, bat]
[dog, god]
[flow, wolf]
[may, amy, yam]
[looped, poodle]
[student, students, studentssess]
[lambs, balms]

 */
