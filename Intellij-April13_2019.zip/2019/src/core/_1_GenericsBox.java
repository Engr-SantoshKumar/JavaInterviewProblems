package core;

public class _1_GenericsBox<T> {
	
	//kv
	public static void main(String[] args) {
		GenericsBox<Integer> a = new GenericsBox<>(new Integer(4));	//this class is now of type:
		//class java.lang.Integer

		GenericsBox<String> b = new GenericsBox<>(new String("4"));
		//	this class is now of type :class java.lang.String
	}
}

class GenericsBox<T>{
	public GenericsBox(T t) {
		System.out.println(" this class is now of type :"+t.getClass());
	}
}