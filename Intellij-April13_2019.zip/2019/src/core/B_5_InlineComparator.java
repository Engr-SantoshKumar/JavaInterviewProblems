package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class B_5_InlineComparator {
	public static void main(String[] args) {
		Fruit a = new Fruit("Orange", 2);
		Fruit b = new Fruit("Apple", 3);
		Fruit c = new Fruit("Banana", 1);
		Fruit d = new Fruit("Fruit", 0);
		List<Fruit> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		Collections.sort(list, new Comparator<Fruit>() {
			@Override
			public int compare(Fruit one, Fruit two) {
				return one.size - two.size;
			}
		}// anonymous block bracket
		);// sorts right bracket
		for(Fruit fruit : list) {
			System.out.println(String.format("color:%s & size:%s", fruit.name, fruit.size));
		}
		
		
		// Inline anonymous
		Collections.sort(list, new Comparator<Fruit>() {
			public int compare(Fruit a0, Fruit a1) {
				return 0;
			}
		});
	}
}

/*class Fruit {
	String name;
	Integer size;

	public Fruit(String name, int size) {
		this.name = name;
		this.size = size;
	}
}

class FruitComparator implements Comparator<Fruit> {

	@Override
	public int compare(Fruit first, Fruit second) {
		return first.size - second.size;
	}

}*/