package core;

public class _5_GenericWithComparable {
	public static void main(String[] args) {
		Integer[] ar = new Integer[] {12};
		String result = Test.compareElements(ar, 12);
		System.out.println(" result of compare >> "+result);
	}
}

class Test {
	static <T> int compareElementsFailure(T[] array, T element) {
		for (T e : array) {
			// return e> element ? 1 :-1; // THIS WILL NOT COMPILE
		}
		return -1;
	}

	// Since Type of T is not decided until run time so T should be comparable, if we use > symbol it can only compare primitives
	// hence above method will give error because Type is not decided until run time and > means only primitives would be used
	// so we indicate that we only use objects T that extends Comparable class
	static <T extends Comparable<T>> String compareElements(T[] array, T element) {
		for (T e : array) {
			if (e.compareTo(element) == 0) {
				return "equal";
			}
		}
		return "not equal";
	}
}
