package core;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Comparator;


public class E_2_PQWithInlineComparator {
	public static void main(String[] args) {
		Transaction2 t1 = new Transaction2(1, 12);
		Transaction2 t2 = new Transaction2(1, 15);
		Transaction2 t3 = new Transaction2(1, 10);
		Transaction2 t4 = new Transaction2(1, 14);
		List<Transaction2> list  = new ArrayList<>();
		list.add(t1);list.add(t2);
		list.add(t3);list.add(t4);
		
		// in pq there is no method to specify size its just initial capacity
		PriorityQueue<Transaction2> pq = new PriorityQueue<>(new Comparator<Transaction2>() {
			@Override
			public int compare(Transaction2 o1, Transaction2 o2) {
				// TODO Auto-generated method stub
				return -o1.amount + o2.amount;
			}});
		
		// maintains a size of 3 for pq
		for(Transaction2 t : list) {
			if(pq.size()>2) {
				Transaction2 tt = pq.peek();
				if(tt.amount < t.amount){
					pq.poll();
					pq.offer(t);
				}
			}else{

				pq.offer(t);
			}
		}
		while(!pq.isEmpty()) {
			System.out.println(" Transaction : "+pq.poll().amount);
		}
		
	}
	// By default pq is min pq, 
	/* Transaction : 17
	 Transaction : 12
	 Transaction : 10
	 */
}

class Transaction2{
	int day;
	int amount;
	
	public Transaction2(int day, int amount) {
		this.day = day;
		this.amount = amount;
	}

	public int compareTo(Transaction that) {
		return this.amount - that.amount;
	}
}