package core;

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

/*
 * I DONT PREFER TO USE THIS IMPLEMENTATION WITH THE COMPARABLE, BEST IS TO USE COMPARATOR ONE
 * MEANING THE OBJECT SHOULD NOT BE COMPARABLE
 * */
public class E_1_PQ {
	public static void main(String[] args) {
		Transaction t1 = new Transaction(1, 12);
		Transaction t2 = new Transaction(1, 15);
		Transaction t3 = new Transaction(1, 10);
		Transaction t4 = new Transaction(1, 17);
		List<Transaction> list  = new ArrayList<>();
		list.add(t1);list.add(t2);
		list.add(t3);list.add(t4);		
		
		// in pq there is no method to specify size its just initial capacity
		PriorityQueue<Transaction> pq = new PriorityQueue<>(3);
		for(Transaction t : list) {
			if(pq.size()>2) {
				pq.remove();
			}
			pq.offer(t);
		}
		while(!pq.isEmpty()) {
			System.out.println(" Transaction : "+pq.poll().amount);
		}
		
	}
	// By default pq is min pq, 
	/* Transaction : 12
	 Transaction : 15
	 Transaction : 17*/
}

class Transaction implements Comparable<Transaction> {
	int day;
	int amount;
	
	public Transaction(int day, int amount) {
		this.day = day;
		this.amount = amount;
	}

	public int compareTo(Transaction that) {
		return this.amount - that.amount;
	}
}