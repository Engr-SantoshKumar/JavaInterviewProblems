package core.algo.basics;

import java.util.Arrays;

public class A_2_MergeSort {
	// static int[] aux = new int[6];

	public static void main(String[] args) {
		int[] ar = new int[] { 4, 2, 1, 6, 3, 5 };
		int[] ar2 = new int[] { 7, 6, 5, 4, 3, 2, 1 };
		System.out.println(Arrays.toString(ar));
		System.out.println(Arrays.toString(ar2));
		mergeSort(ar, 0, ar.length - 1);
		mergeSort(ar2, 0, ar2.length - 1);
		System.out.println(Arrays.toString(ar));
		System.out.println(Arrays.toString(ar2));
	}

	static void mergeSort(int[] ar, int lo, int hi) {
		if (hi <= lo) {
			return;
		}

		int mid = (lo + hi) / 2;
		System.out.print(" sort " + ar[lo] + ", " + ar[mid]);
		System.out.println(" and " + ar[mid + 1] + ", " + ar[hi]);
		mergeSort(ar, lo, mid);
		mergeSort(ar, mid + 1, hi);
		sort(ar, lo, mid, hi);
	}

	static void sort(int[] ar, int lo, int mid, int hi) {
		int[] aux = new int[ar.length];

		for (int i = lo; i <= hi; i++) {
			aux[i] = ar[i];
		}

		int i = lo;
		int j = mid + 1;

		for (int k = lo; k <= hi; k++) {
			if (i > mid) {
				ar[k] = aux[j++];
			} else if (j > hi) {
				ar[k] = aux[i++];
			} else if (aux[i] <= aux[j]) {
				ar[k] = aux[i++];
			} else {
				ar[k] = aux[j++];
			}
		}
		System.out.println(".." + Arrays.toString(ar));
	}
}
