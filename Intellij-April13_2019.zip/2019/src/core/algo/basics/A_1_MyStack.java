package core.algo.basics;

import java.util.ArrayDeque;

public class A_1_MyStack {
	public static void main(String[] args) {
		ArrayDeque<Integer> mystack = new ArrayDeque<>(10);
		try {
			mystack.push(7);
			mystack.push(9);
			System.out.println("current stack " + mystack);
			System.out.println("popped this " + mystack.pop());
			System.out.println("popped this " + mystack.pop());
			System.out.println("popped this " + mystack.pop());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class Stack<T> {
	private T[] array;
	int capacity;
	int top = -1;

	public Stack(int capacity) {
		// ugly cast due to the limitation of array on generics
		array = (T[]) new Object[capacity];
		this.capacity = capacity;
	}

	public void push(T t) throws Exception {
		System.out.println(array.length + " cap " + capacity);
		if (top < capacity) {
			array[++top] = t;
			for (T a : array) {
				System.out.println(a);
			}
			System.out.println();
		} else {
			throw new Exception(" max capacity reached");
		}
	}

	public T pop() throws Exception {
		if (isEmpty()) {
			throw new Exception(" stack is empty");
		}
		return array[top--];
	}

	public boolean isEmpty() {
		return top == -1;
	}

	public String toString() {
		StringBuilder s = new StringBuilder();
		for (T item : array) {
			s.append(item);
			s.append(' ');
		}
		return s.toString();
	}

}