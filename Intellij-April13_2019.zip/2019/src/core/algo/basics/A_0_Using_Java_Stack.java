package core.algo.basics;
import java.util.ArrayDeque;
import java.util.Stack;
public class A_0_Using_Java_Stack {
	public static void main(String[] args) {
		/*Queue<Integer> stack = new Queue<>();
		stack.push(5);
		System.out.println(stack.pop());
		*/
		ArrayDeque<Integer> ad = new ArrayDeque<>();
		ad.push(7);
		ad.push(8);
		ad.push(9);
		ad.addLast(6);
		
		while(!ad.isEmpty()) {
			System.out.println("..." +ad.pop());
		}
	}
}
