package core;

import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * Date: 3/30/19
 * Runtime Complexity: o(?),    Space Complexity: o(?)
 * <p>
 * Problem Description:
 * Solution:
 * Remember:
 */
public class _0_HashMap_vs_TreeMap {
    public static void main(String args[]){
        AddressWithOutHashCodeWithEquals addr2[] = new AddressWithOutHashCodeWithEquals[4];
        addr2[0] = new AddressWithOutHashCodeWithEquals(1, "Hollywood Street");
        addr2[1] = new AddressWithOutHashCodeWithEquals(2, "Baker Avenue");
        addr2[2] = new AddressWithOutHashCodeWithEquals(2, "Baker Avenue");
        addr2[3] = new AddressWithOutHashCodeWithEquals(4, "Baker Avenue");

        Map<AddressWithOutHashCodeWithEquals, Integer> map1 = new HashMap<>();
        map1.put(addr2[0], 55);
        map1.put(addr2[1], 65);
        map1.put(addr2[2], 75);
        map1.put(addr2[3], 85);
        for(Map.Entry<AddressWithOutHashCodeWithEquals, Integer> entry : map1.entrySet()){
            System.out.println(" "+entry.getKey().toString()+" : "+entry.getValue());
        }

        AddressWithHashCodeEquals addr[] = new AddressWithHashCodeEquals[4];
        addr[0] = new AddressWithHashCodeEquals(1, "Hollywood Street");
        addr[1] = new AddressWithHashCodeEquals(2, "Baker Avenue");
        addr[2] = new AddressWithHashCodeEquals(2, "Baker Avenue");
        addr[3] = new AddressWithHashCodeEquals(4, "Baker Avenue");

        Map<AddressWithHashCodeEquals, Integer> map2 = new HashMap<>();
        map2.put(addr[0], 55);
        map2.put(addr[1], 65);
        map2.put(addr[2], 75);
        map2.put(addr[3], 85);
        System.out.println(" -- with HC and Eq");
        for(Map.Entry<AddressWithHashCodeEquals, Integer> entry : map2.entrySet()){
            System.out.println(" "+entry.getKey().toString()+" : "+entry.getValue());
        }

        System.out.println(" -- with TreeMap-- IT DOES NOT CARE OF HASHCODE BUT YOU SHOULD HAVE " +
                "COMPARE TO ELSE WILL NOT  WORK");
        Map<AddressWithOutHashCodeWithEquals, Integer> map3 =
                new TreeMap<>(new Comparator<AddressWithOutHashCodeWithEquals>() {
            @Override
            public int compare(AddressWithOutHashCodeWithEquals t,
                               AddressWithOutHashCodeWithEquals t1) {
                if (t.aptNo.compareTo(t1.aptNo) > 0 && t.streetName.compareTo(t1.streetName) > 0) {
                    return 1;
                } else if (t.aptNo.compareTo(t1.aptNo) ==
                        0 && t.streetName.compareTo(t1.streetName) == 0) {
                    return 0;
                } else {
                    return -1;
                }
            }
        });
        map3.put(addr2[0], 55);
        map3.put(addr2[1], 65);
        map3.put(addr2[2], 75);
        map3.put(addr2[3], 85);
        for(Map.Entry<AddressWithOutHashCodeWithEquals, Integer> entry : map3.entrySet()){
            System.out.println(" "+entry.getKey().toString()+" : "+entry.getValue());
        }
    }
}
