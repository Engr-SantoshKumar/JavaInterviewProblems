package core;
import java.util.ArrayList;
import java.util.*;

public class A_GenericsClassDemo {
	/*public static void main(String[] args) {
		Queue<? super B> stackA = new Queue<A>();
		Queue<? extends A> stackA1 = new Queue<B>();
		List<? extends Number> foo3 = new ArrayList<Number>();
		List<? extends Number> foo4 = new ArrayList<Integer>();
		A a = new A();
		B b = new B();
		foo4.add(new Integer(8));
		//stackA.push(a);
		stackA.push(b);
		stackA1.push(b);
		*//*foo4.add(new Integer(5));*//*
	}
}
class Stack1<T> extends Stack{
	
}
class A{
	public A() {
		System.out.println(" I m in class A");
	}
	
	public void print() {
		System.out.println(" print of class A");
	}
}

class B extends A{
	public B() {
		System.out.println(" I m in class B");
	}
	public void print() {
		System.out.println(" print of class B");
	}
*/}