package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class _3_GenericPair {
	public static void main(String[] args) {
		Pair<Integer, String> pair1 = new Pair<>(1, "apple");
		Pair<Integer, Float> pair2 = new Pair<>(2, 15.8F);
		System.out.println("Key : "+pair1.key+" value :"+pair1.value);
		System.out.println("Key : "+pair2.key+" value :"+pair2.value);
		
		Pairx<Integer, String> pair3 = new Pairx<>(3, "apple");
		Pairx<Integer, String> pair4 = new Pairx<>(1, "adple");
		List<Pairx> l = new ArrayList<>();
		l.add(pair3);
		l.add(pair4);
		for(Pairx elem : l) {
			System.out.println(elem.getValue());
		}
		Collections.sort(l);
		for(Pairx elem : l) {
			System.out.println(".." + elem.getValue());
		}
		System.out.println();
	}
}

class Pair<K, V> {
	K key;
	V value;

	public Pair(K key, V value) {
		this.key = key;
		this.value = value;
	}

	K getKey() {
		return key;
	}

	V getValue() {
		return value;
	}
}

// COmparable in generics, if you do not declare K extends Comparable<K> you cannot implement
// compareTo
class Pairx<K extends Comparable<K>, V extends Comparable<V>> implements Comparable<Pairx<K,V>>{
	K key;
	V value;

	public Pairx(K key, V value) {
		this.key = key;
		this.value = value;
	}

	K getKey() {
		return key;
	}

	V getValue() {
		return value;
	}
	
	@Override
	public int compareTo(Pairx<K,V> that){
		return this.key.compareTo(that.key);
	}


	
}
