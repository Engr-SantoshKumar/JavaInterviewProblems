package core.educative_crs1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class A_Ar_2_TwoSum {
	public static void main(String[] args) {
		int[] ar = new int[] { 1, 2, 3, 4, 6 };
		System.out.println(" original array "+Arrays.toString(ar));
		List<Pair> pairs = findTwoSum(ar, 6);
		for(Pair p: pairs) {
			System.out.println(p.a+","+p.b);
		}
		System.out.println(" binary search ");
		List<Pair> pairs1 = findTwoSumBinarySearch(ar, 6);
		for(Pair p: pairs1) {
			System.out.println(p.a+","+p.b);
		}
	}

	 static List<Pair> findTwoSum(int[] ar, int target) {
		List<Pair> list = new ArrayList<>();
		Set<Integer> set = new HashSet<>();
		for(int i=0;i<ar.length; i++) {
			if(set.contains(target-ar[i])) {
				list.add(new Pair(ar[i], target-ar[i]));
				set.remove(ar[i]); 
				set.remove(target-ar[i]);
			}
			set.add(ar[i]);
		}
		System.out.println(set);
		return list;
	}
	 
	 static List<Pair> findTwoSumBinarySearch(int[] ar, int target) {
			List<Pair> list = new ArrayList<>();
			for(int i=0;i<ar.length; i++) {
				int complement = target-ar[i];
				int idx = Arrays.binarySearch(ar, complement);
				System.out.println(" findfor "+ar[i]+" is comp "+complement +" in array idx "+idx);
				/*if(idx == i) {
					continue;
				}*/
				if(idx>i) {
					list.add(new Pair(ar[i], complement));
				}
			}
			return list;
		}

	private static class Pair {
		int a;
		int b;
		public Pair(int a, int b) {
			this.a = a;
			this.b = b;
		}
	}
}
