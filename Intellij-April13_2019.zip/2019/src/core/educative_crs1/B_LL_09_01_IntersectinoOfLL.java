package core.educative_crs1;

import java.util.HashSet;

import core.MyLinkedList;
import core.Node;

/*Sample Input
list1 = 10->20->80->60
list2 = 15->20->30->60->45
Sample Output
Union = 10->20->80->60->15->30->45
Intersection = 20->60*/
public class B_LL_09_01_IntersectinoOfLL {
	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.add(10);
		ll.add(20);
		ll.add(80);
		ll.add(60);
		MyLinkedList ll2 = new MyLinkedList();
		ll2.add(15);
		ll2.add(20);
		ll2.add(30);
		ll2.add(60);
		ll2.add(45);
		// MyLinkedList.iterate(ll.getFirst());
		findIntersection(ll.getFirst(), ll2.getFirst());
		// MyLinkedList.iterate(ll.getFirst());
	}
    // ADD ALL ELEMNS FROM LL1 TO SET AND THEN ON SECOND ITERATE
	// AND FIND THE COMMON ELEMS
	static void findIntersection(Node head1, Node head2) {
		HashSet<Integer> commonElements = new HashSet<>();
		MyLinkedList result = new MyLinkedList();
		while (head1 != null) {
			commonElements.add(head1.data);
			head1 = head1.next;
		}
		while (head2 != null) {
			if (commonElements.contains(head2.data)) {
				result.add(head2.data);
			}
			head2 = head2.next;
		}
		MyLinkedList.iterate(result.getFirst());
	}

}
