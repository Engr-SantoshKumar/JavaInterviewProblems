package core.educative_crs1;

import java.util.Iterator;

import core.MyLinkedList;
import core.Node;

public class B_LL_02_DeleteFromLL {
	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.add(5);
		ll.add(7);
		ll.addFirst(8);
		ll.removeFirst();
		Iterator<Node> it = ll.iterator();
		while (it.hasNext()) {
			System.out.println(it.next().data);
		}
		System.out.println(" done ");
	}
}
