package core.educative_crs1;

public class C_STQ_02_MYQueue {
	/*public static void main(String[] args) {
		Queue<Account> q = new Queue<>(5);
		q.enqueue(new Account(5));
		q.enqueue(new Account(4));
		q.enqueue(new Account(3));
		q.enqueue(new Account(2));
		q.enqueue(new Account(1));
		q.dequeue();
		System.out.println(".............");
		q.enqueue(new Account(6));
		while(!q.isEmpty()) {
			System.out.println(" .. "+q.dequeue().ac);
		}
		
	}
	
	private static class Account{
		int ac;
		public Account(int ac) {
			this .ac = ac;
		}
	}
}

class Queue<T>{
	int capacity;
	T[] ar;
	int head = 0;
	int tail = 0;
	public Queue(int capacity) {
		ar =  (T[]) new Object[capacity];
		this.capacity = capacity;
	}
	
	public void enqueue(T t){
		//if(tail >= ar.length) {
			if(head>0) {
				System.out.println("here "+(tail++%ar.length));
				ar[tail++%ar.length] = t;
				return;
			}else if(head-tail == 1){
				System.out.println("q is full");
				return;
			}
		//}
		ar[tail++%ar.length] = t;
	}
	public T dequeue() {
		if(head%ar.length)
	}
	
	public boolean isEmpty() {
		return tail == 0;
	}
*/}
