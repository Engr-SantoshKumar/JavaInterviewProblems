package core.educative_crs1;

import core.MyLinkedList;
import core.Node;
public class B_LL_09_02_findPointOfIntersectinOfLL_______ {
	public static void main(String[] args) {
		MyLinkedList ll1 = new MyLinkedList();
		Node n1 = new Node(1);
		Node n2 = new Node(2);
		Node n3 = new Node(3);
		
		Node n20 = new Node(0);
		Node n21 = new Node(-1);
		
		Node common1 = new Node(4);
		Node common2 = new Node(5);
		Node common3 = new Node(6);
		common1.next = common2;common2.next = common3;
		
		n1.next = n2;
		n2.next = n3;
		n3.next = common1; // set next of ll1 to common1
		
		n20.next = n21;
		n21.next = common1;
		findIntersection(n1, n20);
	}
	
	static void findIntersection(Node head1, Node head2){
		
	}
}
