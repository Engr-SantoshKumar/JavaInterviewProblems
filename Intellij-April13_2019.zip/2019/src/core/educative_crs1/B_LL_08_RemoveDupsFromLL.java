package core.educative_crs1;

import core.MyLinkedList;
import core.Node;
/*Sample Input
linkedlist = 1->2->2->2->3->4->4->5->6
Sample Output
linkedlist = 1->2->3->4->5->6*/

public class B_LL_08_RemoveDupsFromLL {
	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.add(1);
		ll.add(2);
		ll.add(2);
		ll.add(2);
		ll.add(3);
		ll.add(4);
		ll.add(4);
		ll.add(5);
		ll.add(6);
		MyLinkedList.iterate(ll.getFirst());
		remvoeDups(ll.getFirst());
		MyLinkedList.iterate(ll.getFirst());
	}
	
	static void remvoeDups(Node head) {
		if(head == null) {
			return;
		}
		Node prev = head;
		Node t = head.next;
		while(t!=null) {
			if(prev.data == t.data) {
				Node temp = t.next;
				t.next = null;
				prev.next = temp;
				t = temp;
				continue;
			}else {
				prev = prev.next;
				t = t.next;
			}
		}
	}
	
}
