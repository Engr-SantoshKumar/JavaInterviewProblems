package core.educative_crs1;

import core.MyLinkedList;
import core.Node;

public class B_LL_05_ReverseLL {
	static Node newHead = null;
	public static void main(String[] args) {
		MyLinkedList ll = MyLinkedList.getDefaultMyLinkedList();
		MyLinkedList.iterate(ll.getFirst());
		//MyLinkedList.iterate(reverse(ll.getFirst()));
		Node head = reverseIterative(ll.getFirst());
		MyLinkedList.iterate(head);
		
		MyLinkedList ll2 = new MyLinkedList();
		//ll2.add(null);
		Node head2 = reverseIterative(ll2.getFirst());
		System.out.println(" pass null LL"+head2);
		MyLinkedList.iterate(head2);
	}
	
	static Node reverse(Node head) {
		if(head == null) {
			return null;
		}
		if(head.next == null) {
			return head;
		}
		Node h = reverse(head.next);
		head.next.next = head;
		head.next = null;
		return h;
	}
	
	static Node reverseIterative(Node head) {
		Node prev = null;
		while(head!=null) {
			Node temp = head.next;
			head.next = prev;
			prev = head;
			head = temp;
		}
		return prev;
		
	}
}