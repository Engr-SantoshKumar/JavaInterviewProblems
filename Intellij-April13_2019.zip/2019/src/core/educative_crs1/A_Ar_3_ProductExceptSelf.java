package core.educative_crs1;

import java.util.Arrays;

public class A_Ar_3_ProductExceptSelf {
	public static void main(String[] args) {
		int[] ar = new int[]{1,2,3,4};
		prodExceptSelf(ar);
		prodExceptSelfSimple(ar);
	}
	
	static void prodExceptSelfSimple( int ar[]) {
		int[] result = new int[ar.length];
		int total = 1;
		for(int i=0;i<ar.length;i++) {
			total*=ar[i];
		}
		for(int i=0;i<ar.length;i++) {
			result[i] = (total/ar[i]) ;
		}
		System.out.println(" Arrays "+Arrays.toString(result));
	}
	static void prodExceptSelf( int ar[]) {
		int[] result = new int[ar.length];
		int rightSum = 1;
		// first collect rightsum in result
		for(int i=ar.length-1 ;i>=0; i--) {
			result[i] = rightSum;
			rightSum*=ar[i];
		}
		// 
		int leftSum=1;
		for(int i=0;i<ar.length;i++) {
			result[i] = result[i]*leftSum;
			leftSum*=ar[i];// collect original entry in leftSum
		}
		System.out.println(" Arrays "+Arrays.toString(result));
	}
}
