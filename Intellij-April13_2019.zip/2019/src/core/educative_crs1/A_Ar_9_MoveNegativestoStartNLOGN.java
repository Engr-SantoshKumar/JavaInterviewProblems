package core.educative_crs1;

import java.util.Arrays;
/*create reArrange() function which will sort the elements such that all the negative elements 
 * appear at left and positive elements appear at the right.
 * ORDER SHOULD BE MAINTAINED FOR NEGATIVE AND POSITIVE NUMBERS
 * */
/*Use modified merge sort*/
public class A_Ar_9_MoveNegativestoStartNLOGN {
	static int aux[] = null;
	public static void main(String[] args) {
		int ar[] = new int[] { 10, -1, 20, -7, 5, -9, -6 };
		System.out.println(" result .. "+Arrays.toString(ar));
		aux = new int[ar.length];
		modifiedMergeSort(ar, 0, ar.length-1);
		System.out.println(" result .. "+Arrays.toString(ar));
	}
	
	static void modifiedMergeSort(int ar[], int lo, int hi) {
		if(hi<=lo) {
			return;
		}
		int mid = (lo+hi)/2;
		modifiedMergeSort(ar, lo, mid);
		modifiedMergeSort(ar, mid+1, hi);
		sort(ar, lo, mid, hi);
	}
	/*note the sort happens from arrays of size 1 so at any point for bigger arrays if first elem is not negative it means
	 * there is no negative in the rem array
	 * ex: [10] [-1] => [-1,10] 
	 * [20] [-7] => [-7,20]
	 * merging [-1,10] and [-7,20]
	 * -1,-7,10,20
	 * */ 
	static void sort(int ar[], int lo, int mid, int hi) {
		System.out.print(" sorting from "+ar[lo]+" < "+ar[mid]+"> "+", "+ar[hi]);
		for(int i=0; i<=hi; i++) {
			aux[i] = ar[i];
		}
		
		int i=lo;
		int j=mid+1;
		
		for(int k=lo; k<=hi; k++) {
			if(i>mid) {
				ar[k] = aux[j++]; // if first half is exhausted, copy from second half
			}else if(j>hi) {
				ar[k] = aux[i++]; // similar
			}else if(aux[i] <0) {
				ar[k] = aux[i++]; // if num in 1st half is negative copy that first, so order is maintained
			}else if(aux[j] <0) {
				ar[k] = aux[j++]; // then num in 2nd half if negative should come  
			}else if(aux[i] >= 0 ) {
				ar[k] = aux[i++];  // this means the index are not overflown and no negatives so num at 1st half should come next
			}else if(aux[j] >= 0 ) {
				ar[k] = aux[j++];  // followed by num at 2nd half
			}
		}
		System.out.println(" result "+Arrays.toString(ar));
	}
}
