package core.educative_crs1;

import java.util.LinkedList;
import java.util.Queue;

public class C_STQ_2_GenerateBinNumUsingQuue {
	public static void main(String[] args) {

	}
	public static String[] findBin(int number) {

		String[] result = new String[number];
		Queue<Integer> queue = new LinkedList<Integer>();

		queue.offer(1);

		for (int i = 0; i < number; i++) {
			result[i] = String.valueOf(queue.poll());
			String s1 = result[i] + "0";
			String s2 = result[i] + "1";
			queue.offer(Integer.parseInt(s1));
			queue.offer(Integer.parseInt(s2));
		}

		return result; //For number = 3 , result = {"1","10","11"};
	}
}
