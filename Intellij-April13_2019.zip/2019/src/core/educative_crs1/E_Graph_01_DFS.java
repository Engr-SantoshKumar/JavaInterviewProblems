package core.educative_crs1;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
		/*
            1   
		   / \
		  2   3       7->8
		 / \   \
		4   5   6
		
*/
// DFS is used to find if a path exists between a source and destination node
// Actually It finds the path to all nodes from a given node
import core.api.GraphOfObjects;
public class E_Graph_01_DFS {
	
	static void dfs(GraphOfObjects<Integer> G) {
		Integer source = 1;// getSourceVertex(G);
		dfs(G, source);
		//edgeTo.put(source, source);
	}
	
	static void dfs(GraphOfObjects<Integer> G, Integer v) {
		visited.add(v);
		for(Integer w : G.getAdj(v)) {
			if(!visited.contains(w)) {
				edgeTo.put(w, v);
				dfs(G, w);
			}
		}
	}
	
	static Integer getSourceVertex(GraphOfObjects<Integer> G) {
		// get any edge let say the first in Graph
		Set<Integer> vertices = G.vertices();
		if(!vertices.isEmpty()) {
			return vertices.iterator().next();
		}
		return -1;
	}
		
	static ArrayDeque<Integer> pathToSource(int source, int dest){
		ArrayDeque<Integer> stack = new ArrayDeque<Integer>();
		if(!edgeTo.containsKey(dest)) {
			return null;
		}
		while(source != dest) {
			stack.push(dest);
			dest = edgeTo.get(dest);
		}
		stack.push(source);
		return stack;
	}
	
	static Map<Integer, Integer> edgeTo = new HashMap<>();
	static Set<Integer> visited = new HashSet<>();
	public static void main(String[] args) {
		GraphOfObjects<Integer> G = new GraphOfObjects<>();
		G.addEdge(1, 2);
		G.addEdge(1, 3);
		G.addEdge(2, 4);
		G.addEdge(2, 5);
		G.addEdge(3, 6);
		G.addEdge(7, 7);
		G.addEdge(8, 7);
		dfs(G);
		System.out.println(visited.toString());
		for(Map.Entry<Integer, Integer> entry : edgeTo.entrySet()) {
			System.out.println(" "+ entry.getKey()+" : "+entry.getValue());
		}
		// Find path between 1 and 6
		
		ArrayDeque<Integer> stack = pathToSource(1,6);
		StringBuilder sb = new StringBuilder();
		while(stack != null && !stack.isEmpty()) {
			sb.append(stack.pop()).append("->");
		}
		System.out.println("path is "+sb);
	}
	/*Other way to find path
	 * StringBuilder sb = new StringBuilder();
	int dest=8; int source = 1;
	while(dest!=source) {
		sb.append(dest).append("->");
		System.out.println(" new dest "+dest);
		dest = edgeTo.get(dest);
		if(dest == edgeTo.get(dest)) {
			break;
		}
	}
	sb.append(source);*/
}
