package core.educative_crs1;

import core.MyLinkedList;
import core.Node;

public class B_LL_06_FindLoopINLL {
	public static void main(String[] args) throws InterruptedException {
		MyLinkedList ll2 = new MyLinkedList();
		ll2.add(5);
		Node x = ll2.add(7);
		ll2.add(14);
		Node y = ll2.add(21);
		y.next = x;
		
		//MyLinkedList.iterate(ll2.getFirst());
		detectLoop(ll2.getFirst());
		Node f = FindBeginning(ll2.getFirst());
		System.out.println(" f "+f.data);
	}
	// check FindBeginning method that is from CTCI, this one is 
	// too much code
	//** point to note is always keep slow and fast at the same point
	// else if you put slow at head and fast at head.next you cannot find
	// intersection point
	static void detectLoop(Node head) throws InterruptedException {
		Node slowP = head;
		Node fastP = head;
		boolean loop=false;
		
		while(slowP!=null && fastP!=null) {
			slowP = slowP.next;
			fastP = fastP.next.next;
			if(slowP == null || fastP == null) {
				break;
			}
			if(slowP.data == fastP.data) {
				System.out.println(" there is a loop"+slowP.data+" fas "+fastP.data);
				loop = true;
				break;
			}
		}
		
		// find intersection
		slowP = head;
		System.out.println(" now slow p "+slowP.data+" f "+fastP.data);
		while(slowP.data != fastP.data) {
			System.out.println(slowP.data+"  "+fastP.data);
			slowP = slowP.next;
			fastP = fastP.next;
			Thread.sleep(100);
		}
		System.out.println("point of intersection is "+slowP.data);
	}
	
	static Node FindBeginning(Node head) {
		Node slow = head;
		Node fast = head; 
		
		// Find meeting point
		while (fast != null && fast.next != null) { 
			slow = slow.next; 
			fast = fast.next.next;
			if (slow == fast) {
				break;
			}
		}

		// Error check - there is no meeting point, and therefore no loop
		if (fast == null || fast.next == null) {
			return null;
		}

		/* Move slow to Head. Keep fast at Meeting Point. Each are k steps
		/* from the Loop Start. If they move at the same pace, they must
		 * meet at Loop Start. */
		slow = head; 
		System.out.println(" slow "+slow.data+" fas "+fast.data);
		while (slow != fast) { 
			System.out.println(" in inter "+ slow.data+" fas "+fast.data);
			slow = slow.next; 
			fast = fast.next; 
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		// Both now point to the start of the loop.
		return fast;
	}
	
	
}
