package core.educative_crs1;

import core.MyLinkedList;
import core.Node;

public class B_LL_03_SearchInLL {
	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.add(5);
		ll.add(7);
		ll.addFirst(8);
		
		Node head = ll.getFirst();
		while(head!=null) {
			if(head.data==7) {
				System.out.println(" found "+head.data);
			}
			
			// below statement is important, always keeps missing it
			head = head.next;
			
		}
	}
}
