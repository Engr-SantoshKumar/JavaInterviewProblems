package core.educative_crs1;

import java.util.Arrays;

/*Arrange elements in such a way that the maximum element appears at first, 
 * then minimum at second, then second maximum at the third position and second 
 * minimum at fourth and so on.
	input = {1,2,3,4,5,6,7}
	{7,2,3,4,5,6,1}
	{7,1,3,4,5,6,2}
	{7,1,6,2,5,3,4}
	{7,1,5,2,6,3,4}
	output = {5,1,4,2,3}
	
	*
	*NOT ANY good solution, all are some kind of formula
	*just make another array and copy min and max using some pointer*/
public class A_Ar_A_10_ArrangeInMaxMinOrder {
	public static void main(String[] args) {
		int[] ar = new int[] { 1, 2, 3, 4, 5 };
		System.out.println(Arrays.toString(ar));
		rearrange(ar, 5);
		System.out.println(Arrays.toString(ar));
	}
	public static void maxMin(int arr[]) 
    { 
        int n = arr.length;
        int maxEle = arr[n - 1]; 
        int minEle = arr[0]; 
        for (int i = 0; i < n; i++) { 
            if (i % 2 == 0) { 
                arr[i] = maxEle; 
                maxEle -= 1; 
            } 
            else { 
                arr[i] = minEle; 
                minEle += 1; 
            } 
        } 
    } 
	
	public static void rearrange(int arr[], int n) 
	{ 
		// initialize index of first minimum and first 
		// maximum element 
		int max_idx = n - 1, min_idx = 0; 

		// store maximum element of array 
		int max_elem = arr[n - 1] + 1; 

		// traverse array elements 
		for (int i = 0; i < n; i++) { 
			// at even index : we have to put 
			// maximum element 
			if (i % 2 == 0) { 
				System.out.println("arr[i] += (arr[max_idx] % max_elem) * max_elem; ");
				System.out.println(arr[i]+"+=("+arr[max_idx]+"%"+max_elem+")*"+max_elem);
				System.out.println("arr[i]"+arr[i]);
				arr[i] += (arr[max_idx] % max_elem) * max_elem; 
				System.out.println("arr[max_idx]="+arr[max_idx]);
				System.out.println("max_elem="+max_elem);
				System.out.println("result="+arr[i]);
				//System.out.println(arr[i]+" + (arr[max_idx]%" +arr[max_idx]+ "  max_elem )"+ max_elem+"*max_elem"+ max_elem+" result"+ (arr[max_idx] % max_elem) * max_elem );
				max_idx--; 
			} 

			// at odd index : we have to put minimum element 
			else { 
				arr[i] += (arr[min_idx] % max_elem) * max_elem; 
				min_idx++; 
			} 
		} 

		// array elements back to it's original form 
		for (int i = 0; i < n; i++) 
			arr[i] = arr[i] / max_elem; 
	} 
	
	static void arrange(int[] ar) {
		int minIdx = 0;
		int maxIdx = ar.length - 1;
		while (minIdx < maxIdx) {
			if (minIdx % 2 == 0) {
				int temp = ar[maxIdx];
				ar[maxIdx] = ar[minIdx];
				ar[minIdx] = temp;
			}
			minIdx++;
			maxIdx--;
		}
		System.out.println(Arrays.toString(ar));
	}
}
