package core.educative_crs1;

public class C_STQ_02_MYQueue2 {
	public static void main(String[] args) {
		Queu<Account> q = new Queu<>(5);
		q.enqueue(new Account(5));
		q.enqueue(new Account(4));
		q.enqueue(new Account(3));
		q.enqueue(new Account(2));
		q.enqueue(new Account(1));
		Account e = q.dequeue();
		System.out.println("............."+e.ac);
		q.enqueue(new Account(6));
		System.out.println("..after inserting 6");
		while(!q.isEmpty()) {
			Account x = q.dequeue();
			System.out.println(" .. "+(x!=null?x.ac:" null "));
		}
		q.enqueue(new Account(6));
		while(!q.isEmpty()) {
			Account x = q.dequeue();
			System.out.println(" .. "+(x!=null?x.ac:" null "));
		}
	}
	
	private static class Account{
		int ac;
		public Account(int ac) {
			this .ac = ac;
		}
		public String toString() { return ""+ac;}
	}
}

class Queu<T>{
	int capacity;
	T[] ar;
	int head = -1;
	int tail = -1;
	public Queu(int capacity) {
		ar =  (T[]) new Object[capacity];
		this.capacity = capacity;
	}
	
	public void enqueue(T t){
		System.out.println(" tail i s"+tail +" ar len "+(ar.length-1)+ " head "+head);
		if(tail<ar.length-1) {
			System.out.println(" inserting "+t.toString());
			ar[++tail] = t;
		}else {
			System.out.println(" q is full");
		}
	}
	public T dequeue() {
		System.out.println(" tail i s"+tail +" ar len "+(ar.length-1)+ " head "+head);
		if(head == tail){
			// reset
			head = -1; tail =-1;
			System.out.println(" restart the qu...");
		}else if(tail>-1){
			return ar[++head];
		}else {
			System.out.println("  q is empty");
		}
		return null;
	}
	
	public boolean isEmpty() {
		return tail < 0 || head>ar.length-1;
	}
	public boolean isFull() {
		return tail >= ar.length-1;
	}
}
