package core.educative_crs1;

public class A_Ar_4_LeftSumEqualRightSum {
	public static void main(String[] args) {
		int[] ar = new int[] { 1, 4, 2,	1, 8, 5, 3 };
		leftSumEqualRightSum(ar);
		leftSumEqualRightSumUsingPrefixArray(ar);
	}
	
	static void leftSumEqualRightSum(int[] ar) {
		int totalSum=0;
		for(int i=ar.length-1; i>=0; i--) {
			totalSum += ar[i];
		}
		int leftSum=0;
		
		for (int i = 0; i < ar.length; i++) {
			if(leftSum == totalSum-ar[i]) {
				System.out.println(" ls and rs are equal at index "+i);
			}
			totalSum-=ar[i];
			leftSum+=ar[i];
		}
	}
	
	static void leftSumEqualRightSumUsingPrefixArray(int[] ar) {
		int sumSoFar=0;
		int[] prefixAr = new int[ar.length];
		int[] suffixAr = new int[ar.length];
		for(int i=0; i<ar.length; i++) {
			sumSoFar += ar[i];
			prefixAr[i] = sumSoFar;
			
		}
		sumSoFar=0;
		for(int i=ar.length-1; i>=0; i--) {
			sumSoFar += ar[i];
			suffixAr[i] = sumSoFar;
		}
		
		for (int i = 0; i < ar.length; i++) {
			if(prefixAr[i] == suffixAr[i]) {
				System.out.println(" index is "+i);
			}
		}
	}
	
}
