package core.educative_crs1;

public class A_Ar_5_FirstNonRepeatingINArray {
	public static void main(String[] args) {
		int[] ar = new int[]{9,2,3,2,6,6};
		// here we can put element and index in a hashMap and 
		// remove element if present in hm, at the end HM will have
		//unique entries
		// iterate through the HM to find element with min index
	}
}
