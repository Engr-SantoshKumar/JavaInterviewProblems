package core.educative_crs1;

public class A_Ar_6_FindSecondLargestINArray {
	public static void main(String[] args) {
		int[] ar = new int[]{9,2,3,6};
		int[] ar1 = new int[]{-15, -16};
		int[] ar2 = new int[]{-15, -15};
		int x = secondLargest(ar);
		
		System.out.println(x);
		// Assume array has all positive ints
	
	}
	static int secondLargest(int[] ar) {
		if(ar==null || ar.length==0) {
			System.out.println(" invalid input");
		}
		if(ar.length<2) {
			System.out.println(" should have at least 2 elems ");
		}
		int largest=ar[0]; 
		int secondLargest=Integer.MIN_VALUE;
		
		for(int elem : ar) {
			if(elem>largest) {
				largest = elem;
				secondLargest = largest;
			}else if(elem==largest){
				continue;
			}else {
				secondLargest = Math.max(secondLargest, elem);
			}
		}
	return secondLargest;
	}
}
