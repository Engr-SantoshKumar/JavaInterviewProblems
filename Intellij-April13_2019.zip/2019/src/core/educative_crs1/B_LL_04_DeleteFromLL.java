package core.educative_crs1;

import core.MyLinkedList;
import core.Node;

public class B_LL_04_DeleteFromLL {
	static MyLinkedList newMyLinkedList() {
		MyLinkedList ll = new MyLinkedList();
		ll.add(5);
		ll.add(7);
		ll.addFirst(8);
		ll.addFirst(9);
		return ll;
	}
	public static void main(String[] args) {
		MyLinkedList ll = newMyLinkedList();
		iterate(ll.getFirst());
		System.out.println(" delete fist elem");
		Node x = delete(9, ll);
		iterate(x);
		ll = newMyLinkedList();
		System.out.println(" delete middle elem 5");
		Node x2 = delete(5, ll);
		iterate(x2);
		ll = newMyLinkedList();
		System.out.println(" delete tail elem 7"  );
		Node x3 = delete(7, ll);
		iterate(x3);
		ll = newMyLinkedList();
		System.out.println(" delete the only elem 8");
		Node x4 = delete(7, ll);
		iterate(x4);
		System.out.println(" delete from null ll");
		Node x5 = delete(7, ll);
		iterate(x5);
		
		//
		MyLinkedList ll2 = new MyLinkedList();
	}
	//EERORORORORORORO
	
	static Node delete(int key, MyLinkedList ll) {
		if(ll == null) {
			System.out.println(" ll is null");
			return null;
		}
		Node head = ll.getFirst();
		if(head == null) {
			System.out.println(" head is null");
			return null;
		}
  
        // If head node itself holds the key to be deleted 
        if (head != null && head.data == key) 
        { 
        	head = head.next; // change head to next elem
            return head; 
        } 
     // Store head node 
        Node t = head;// prev = null; 
		while (t.next != null) {
			// delete from second node on
			if (t.next.data == key) {
				t.next = t.next.next;
				//System.out.println(" found " + t.value);
			}
			// below statement is important, always keeps missing it
			if(t.next == null) {
				break;
			}
			t = t.next;
		}
		
		// returning head is imp from this method else the callee will have no way to
		// traverse from this head, as he is only having pointer to old head
		return head;
	}
	/*//1->2->3
	 * p=null del 1
	*/
	
	static void iterate(Node head) {
		while (head != null) {
			System.out.print( head.data+"->");
			head = head.next;
		}
		System.out.println();
	}
}
