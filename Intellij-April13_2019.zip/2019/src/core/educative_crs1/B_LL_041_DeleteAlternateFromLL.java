package core.educative_crs1;

import core.MyLinkedList;
import core.Node;

public class B_LL_041_DeleteAlternateFromLL {
	public static void main(String[] args) {
		MyLinkedList ll = newMyLinkedList();
		MyLinkedList.iterate(ll.getFirst());
		MyLinkedList.iterate(deleteAlternate(ll));
	}
	static Node deleteAlternate(MyLinkedList ll) {
		Node head = ll.getFirst();
		if(head == null) {
			return null;
		}
		Node t = head;
		while(t.next != null) {
			t.next = t.next.next;
			if(t.next == null) {
				break;
			}
			t = t.next;
		}
		//iterate(head);
		// return the original head
		return head;
	}
	
	static MyLinkedList newMyLinkedList() {
		MyLinkedList ll = new MyLinkedList();
		ll.add(5);
		ll.add(7);
		ll.addFirst(8);
		ll.addFirst(9);
		/*ll.addFirst(10);
		ll.addFirst(11);*/
		return ll;
	}
	
	
}
