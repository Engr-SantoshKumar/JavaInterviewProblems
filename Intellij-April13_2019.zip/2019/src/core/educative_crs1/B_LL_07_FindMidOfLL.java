package core.educative_crs1;

import core.MyLinkedList;
import core.Node;
/*Sample Input
linkedlist = 7->14->10->21
Sample Output
mid = 14*/
public class B_LL_07_FindMidOfLL {
	public static void main(String[] args) {
		MyLinkedList ll = new MyLinkedList();
		ll.add(7);
		ll.add(14);
		ll.add(10);
		ll.add(21);
		Node mid = findMid(ll.getFirst());
		System.out.println(" mid is "+mid.data);
	}
	//
	static Node findMid(Node head) {
		Node slow = head;
		Node fast = head;
		
		while(fast!=null && fast.next != null) {
			slow = slow.next;
			fast = fast.next.next;
		}
		return slow;
	}
}
//while(fast!=null && fast.next != null) will give ans as 10 
// for input 7->14->10->21
// but if req is to get 14 then impl should be 
// while(fast.next!=null && fast.next.next != null) 
