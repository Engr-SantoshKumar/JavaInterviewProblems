package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class B_2_Comparables2 {

	public static void main(String[] args) {
		Orange a = new Orange("ared", 1);
		Orange b = new Orange("green", 3);
		Orange c = new Orange("blue", 5);
		Orange d = new Orange("ared", 0);
		
		System.out.println(a.equals(b));
		List<Orange> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		Collections.sort(list);
		for(Orange orange : list) {
			System.out.println(String.format("color:%s & size:%s", orange.color, orange.size));
		}
		//Output
		/*color:ared & size:1 **** Next example we will see if color is same sort on size so this entry will go on second place
		color:ared & size:0
		color:blue & size:5
		color:green & size:3*/
	}
}

class Orange implements Comparable<Orange> {
	String color;
	Integer size;

	public Orange(String color, int size) {
		this.color = color;
		this.size = size;
	}

	@Override
	public int compareTo(Orange that) {
		// natural order with this.compareTo(that) or for this.size-that.size
		return this.color.compareTo(that.color);
	}
}