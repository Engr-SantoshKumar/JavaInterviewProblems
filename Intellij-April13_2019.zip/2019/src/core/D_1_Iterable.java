package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

//THE ONLY USE OF ITERABLE IS TO USE THE FOREACH STATEMENT, SO KIND OF USELESS
public class D_1_Iterable {
	public static void main(String[] args) {
		List<Account> list = new ArrayList<>();
		list.add(new Account(5));
		list.add(new Account(4));
		list.add(new Account(50));
		
		
		for(Account a : list) {
			System.out.println(" ... "+a.amount);
		}
		
		AccountList alist = new AccountList(list);
		Iterator<Account> it = alist.iterator();
		while(it.hasNext()) {
			System.out.println(" printing "+it.next().amount);
		}
		
	}
}
// Iterator can be of any type of list and not of core Account class
class AccountList implements Iterable<Account>{
	List<Account> accountList = new ArrayList<>();
	public AccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
	@Override
	public Iterator<Account> iterator() {
		// you can play with you collection before returning iterator
		Collections.reverse(accountList);
		return accountList.iterator();
	}
}
class Account{
	int amount;
	List<Account> list;
	public Account(int amount) {
		this.amount = amount;
	}
}
