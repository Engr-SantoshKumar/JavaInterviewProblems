package core;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * VERY GOOD ARTICLE ABOUT MAPS
 * https://prismoskills.appspot.com/lessons/Java/Chapter_03_-_Hashcode_Equals_and_CompareTo.jsp
 *
 * VIMP: TREEMAP DOES NOT USE EQUALS OR HASHCODE FOR COMPARISON BUT JUST USES COMPARETO METHOD
 * IT DOES NOT ALLOW DUPLICATE KEYS
 *
 * An interesting corollary from the above analysis is that TreeMap does not use hashCode() or
 * equals() at all!
 * It solely relies on the compareTo() method and if your equals() does not comply with compareTo
 * TreeMap does not care.
 * This could result in a serious application error where two objects considered equal by equals
 * return different values from TreeMap.
 *
 *
 * HASHMAP AND HASHSET USES EQUALS AND HASHCODE TO COMPARE EQUALITY
 *
 *
 *
 This we insert   HM         LinkedHM     TreeMap
      Z - 4       B - 2       Z - 4        A - 1
      A - 1       C - 3       A - 1        B - 2
      C - 3       A - 1       C - 3        C - 3
      B - 2       Z - 4       B - 2        Z - 4
 */
public class _0_Collections_OrderOfInsertionTestMaps {
    public static void main(String args[]) {
        Map<Box, Integer> hashMap = insert("HashMap");
        iterate(hashMap);
        Map<Box, Integer> linkedHashMap = insert("LinkedHashMap");
        iterate(linkedHashMap);
        System.out.println(" If <Box> class does not implem <Comparable> it TreemMap will error: " +
                "java.lang.ClassCastException: core.Box cannot be cast to java.lang.Comparable");
        Map<Box, Integer> treeMap = insert("TreeMap");
        iterate(treeMap);
    }

    static Map<Box, Integer> insert(String type) {
        Map<Box, Integer> map = null;
        switch (type) {
            case "HashMap":
                map = new HashMap<>();
                break;
            case "LinkedHashMap":
                map = new LinkedHashMap<>();
                break;
            case "TreeMap":
                map = new TreeMap<>();
                break;
            default:
                break;
        }
        Box box1 = new Box("Z");
        Box box2 = new Box("A");
        Box box3 = new Box("C");
        Box box4 = new Box("B");
        map.put(box1, 4);
        map.put(box3, 3);
        map.put(box4, 2);
        map.put(box2, 1);

        return map;
    }

    static void iterate(Map<Box, Integer> map) {
        System.out.println(" iterating " + map.getClass());
        for (Map.Entry<Box, Integer> entry : map.entrySet()) {
            System.out.println(entry.getKey().color + " " + entry.getValue());
        }
    }
}

class Box implements Comparable<Box> {
    String color;

    public Box(String color) {
        this.color = color;
    }

    public boolean equals(Box ob) {
        return this.color.equals(ob.color);
    }

    public int hashCode() {
        return 31 * color.hashCode();
    }

    // **** This Box param is only possible because we mention Comparable<Box>
    @Override
    public int compareTo(Box ob) {
        return this.color.compareTo(((Box) ob).color);
    }
    // **** when you write class Box implements Comparable, then your compareTo will need to have
    // Object as parameter, because it does not know that what are you comparing, like below:
   /* @Override
    public int compareTo(Object ob) {
        return this.color.compareTo(((Box) ob).color);
    }*/
}