package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class B_1_Comparables {
	public static void main(String[] args) {
		Apple b = new Apple("green", 3);
		Apple a = new Apple("red", 1);
		Apple c = new Apple("blue", 5);
		
		System.out.println(a.equals(b));
		List<Apple> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		Collections.sort(list);
		for(Apple apple : list) {
			System.out.println(String.format("color:%s & size:%s", apple.color, apple.size));
		}
	}
}

class Apple implements Comparable<Apple> {
	String color;
	Integer size;
	public Apple(String color, int size) {
		this.color = color;
		this.size = size;
	}
	
	// this.size > that.size, gives Ascending, others are understood
	// this.size - that.size gives Ascending, the way to remember when it is obvious implementation it is min first, like pq
	@Override
	public int compareTo(Apple that) {
		/*trivial comparison
		 * if (this.size == that.size) {
			return 0;
		}
		return this.size > that.size ? 1 : -1;*/
		
		// if we use Integer in place of int we could say this.size.CompareTo(that.size())
		return this.size - that.size;
		// or return this.size.compareTo(that.size);
	}
}