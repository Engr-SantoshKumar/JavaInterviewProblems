package core.api;

public class BinarySearch {
	static int binarySearch(int[] ar, int key) {
		int lo = 0;
		int hi = ar.length-1;
		
		while(lo<=hi) {// imp check for lo<=hi else in given array u cannot find 2nd, last or mid element element
			int mid = lo+(hi-lo)/2;
			if(key == ar[mid]) {
				return mid;
			}
			if(key < ar[mid]) {
				hi = mid-1;
			}else {
				lo = mid+1;
			}
		}
		return -1;
	}
	
	static int binarySearchRec(int[] ar, int key) {
		return binarySearchR(ar, key, 0, ar.length-1);
	}
	static int binarySearchR(int[] ar, int key, int lo, int hi) {
		if(hi<lo) {
			return -1;
		}
		int mid = (hi+lo)/2;
		if(key < ar[mid]) {
			return binarySearchR(ar, key, lo, mid-1);
		}else if(key > ar[mid]) {
			return binarySearchR(ar, key, mid+1, hi);
		}else {
			return mid;
		}
	}
	public static void main(String[] args) {
		int[] ar = {3, 6, 9, 12, 15, 18};
		for(int a  : ar) {
			System.out.println(" index of "+a+ ",  "+binarySearch(ar, a));
		}
		for(int a  : ar) {
			System.out.println(" rec i of "+a+ ",  "+binarySearchRec(ar, a));
		}
		System.out.println(" index of "+27+ ",  "+binarySearch(ar, 27));
		System.out.println(" rec i of "+27+ ",  "+binarySearchRec(ar, 27));
	}
}
