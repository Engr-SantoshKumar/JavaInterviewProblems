package core.api;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
public class E_Graph_03_Top {
	static ArrayDeque<Integer> st = new ArrayDeque<>();
	static void dfs(GraphOfObjects<Integer> G) {
		for(Integer source : G.vertices()) {
			if(!visited.contains(source)) {
				dfs(G, source);
			}
		}
	}
	
	static void dfs(GraphOfObjects<Integer> G, Integer v) {
		visited.add(v);
		List<Integer> adj = G.getAdj(v);
		for(Integer w : adj) {
			if(!visited.contains(w)) {
				dfs(G, w);
			}
		}
		st.push(v);
	}
	
	
	static Map<Integer, Integer> edgeTo = new HashMap<>();
	static Set<Integer> visited = new HashSet<>();
	public static void main(String[] args) {
		GraphOfObjects<Integer> G = new GraphOfObjects<>();
		/*G.addEdge(2, 1);
		G.addEdge(1, 3);
		G.addEdge(2, 3);
		G.addEdge(3, 4);
		G.addEdge(3, 5);
		G.addEdge(4, 5);*/
		// this post graph is from Sedgwick
		G.addEdge(0, 1);
		G.addEdge(0, 5);
		G.addEdge(0, 2);
		G.addEdge(1, 4);
		G.addEdge(3, 2);
		G.addEdge(3, 4);
		G.addEdge(3, 5);
		G.addEdge(3, 6);
		G.addEdge(5, 2);
		G.addEdge(6, 4);
		G.addEdge(6, 0);
/*		the ans would vary with connections ex: if we change this to 0,1 0,5
 * 		the ans would change, with current scenario it is 
 * 		3
		6
		0
		5
		2
		1
		4
*/
		dfs(G);
		while(!st.isEmpty()) {
			System.out.println(st.pop());
		}
	}
}
