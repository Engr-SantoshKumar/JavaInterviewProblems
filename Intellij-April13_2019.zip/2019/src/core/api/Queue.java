package core.api;

import java.util.Iterator;

public class Queue<T> implements Iterable<T>, Iterator<T>{
	public static void main(String[] args) {
		Queue<Integer> q = new Queue<>();
		q.enqueue(1);
		q.enqueue(2);
		q.enqueue(3);
		q.enqueue(4);

		/*while (!q.isEmpty()) {
			System.out.println(" elem is " + q.dequeue());
		}*/
		Iterator it = q.iterator();
		while(it.hasNext()) {
			System.out.println(" .. "+it.next());
		}
		q.enqueue(6);
		it = q.iterator();
		while(it.hasNext()) {
			System.out.println(" .. "+it.next());
		}
	}

	Node head, tail;

	public void enqueue(T t) {
		if (head == null) {
			head = new Node(t);
			tail = head;
		} else {
			tail.next = new Node(t);
			tail = tail.next;
		}
	}

	public T dequeue() {
		T retVal = head.data;
		Node temp = head.next;
		head.next = null;
		head = temp;
		return retVal;
	}

	public boolean isEmpty() {
		return head == null;
	}

	private class Node {
		T data;
		Node next;

		public Node(T data) {
			this.data = data;
		}
	}

	// method of Iterable
	@Override
	public Iterator<T> iterator() {
		return this;
	}

	// Methods of Iterator class
	@Override
	public boolean hasNext() {
		return !isEmpty();
	}

	@Override
	public T next() {
		T retVal = head.data;
		head = head.next;
		return retVal;
	}
}
