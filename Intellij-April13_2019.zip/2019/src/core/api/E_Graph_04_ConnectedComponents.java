package core.api;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class E_Graph_04_ConnectedComponents {

	static void dfs(GraphOfObjects<Integer> G) {
		int count = 0;
		for (Integer source : G.vertices()) {
			if (!visited.contains(source)) {
				dfs(G, source, count);
				count++; // make sure count is in if cond..
				// else comp calculated correctly but the comp numbre is high
			}
		}
	}

	static void dfs(GraphOfObjects<Integer> G, Integer v, int count) {
		visited.add(v);
		component.put(v, count);
		List<Integer> adj = G.getAdj(v);
		for (Integer w : adj) {
			if (!visited.contains(w)) {
				dfs(G, w, count);
			}
		}
	}

	static Map<Integer, Integer> component = new HashMap<>();
	static Set<Integer> visited = new HashSet<>();

	public static void main(String[] args) {
		GraphOfObjects<Integer> G = new GraphOfObjects<>();
		G.addEdge(1, 2);
		G.addEdge(1, 3);
		G.addEdge(2, 4);
		G.addEdge(2, 5);
		G.addEdge(3, 6);
		G.addEdge(7, 7);
		G.addEdge(8, 7);
		G.addEdge(9, 10);
		G.addEdge(10, 11);
		G.addEdge(11, 12);
		G.addEdge(12, 10);
		dfs(G);
		System.out.println(visited.toString());
		System.out.println("node" + "-comp");
		for (Map.Entry<Integer, Integer> entry : component.entrySet()) {
			System.out.println("  " + entry.getKey() + "---" + entry.getValue());
		}
	}
}
