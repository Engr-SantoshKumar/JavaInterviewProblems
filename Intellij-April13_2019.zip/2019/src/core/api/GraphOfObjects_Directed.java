package core.api;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
// this has extra marked and 
public class GraphOfObjects_Directed<T> {

	Map<T, List<T>> G;
	public GraphOfObjects_Directed() {
		G = new HashMap<T, List<T>>();
	}
	
	// undirected to so add to both
	public void addEdge(T v, T w) {
		if(G.get(v) == null) {
			G.put(v, new ArrayList<T>());
		}
		if(G.get(w) == null) {
			G.put(w, new ArrayList<T>());
		}
		G.get(v).add(w);
		//G.get(w).add(v);
	}
	
	public List<T> getAdj(int v){
		return G.get(v);
	}
	
	public Set<T> vertices(){
		return G.keySet();
	}
	
	public static void main(String[] args) {
		GraphOfObjects_Directed<Integer> G = new GraphOfObjects_Directed();
		G.addEdge(5, 6);
		G.addEdge(5, 8);
		G.addEdge(8, 6);
		
		List<Integer> adj =null;
		adj = G.getAdj(5);
		for(Integer t : adj) {
			System.out.println("adj of 5 "+t);
		}
		
		adj =null;
		adj = G.getAdj(6);
		for(Integer t : adj) {
			System.out.println("adj of 8 "+t);
		}
	}
}
