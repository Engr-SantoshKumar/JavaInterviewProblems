package core.api;

import java.util.ArrayList;
import java.util.List;

public class Graph {
	List<Integer>[] G;
	public Graph(int vertices) {
		G = (List<Integer>[])new Object[vertices];
		build(vertices);
	}
	
	private void build(int vertices) {
		for(int i=0; i< vertices; i++) {
			G[i] = new ArrayList<Integer>();
		}
	}
	// undirected to so add to both
	public void addEdge(int v, int w) {
		// G[v].add(w); Or below 2 lines
		List<Integer> adjV = G[v];
		adjV.add(w);
		G[w].add(v);
	}
	
	public List<Integer> getAdj(int v){
		return G[v];
	}
}
