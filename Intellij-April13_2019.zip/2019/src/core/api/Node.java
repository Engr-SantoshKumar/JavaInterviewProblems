package core.api;

/**
 * Date: 2/26/19
 * Use this Tree Node
 */
public class Node {
    public Node left; // both left and right should be public
    public Node right;
    public int data;  // data should be public too
    public Node nextSibling;
    public Node(int data){
        this.data = data;
    }
    public Node() {
    }

    public void print() {
        TreePrint.print(this);
    }
}
