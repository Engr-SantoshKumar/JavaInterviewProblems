package core;

import java.util.Iterator;
import java.util.LinkedList;

public class MyLinkedList2 implements Iterator<Node>, Iterable<Node> {
	Node head = null;
	Node last = null;

	public Node add(Integer value) {
		System.out.println("adding "+value+" last "+last);
		Node current =  new Node(value);
		if (head == null) {
			last = current;
			return head = current;
		}
		last.next = current;
		last = current;
		return current;
	}

	// removes the head element
	public Node removeFirst() {
		if (head != null) {
			Node temp = head;
			head = head.next;
			return temp;
		}
		return null;
	}

	@Override
	public void remove() {// Unsupported
	}

	public boolean hasNext() {
		return head!=null;
	}

	public Node next() {
		Node temp = head;
		head = head.next;
		return temp;
	}

	public static void main(String[] args) {
		MyLinkedList2 ll = new MyLinkedList2();
		ll.add(5);
		ll.add(6);
		ll.add(7);
		ll.removeFirst();
		Iterator<Node> it = ll.iterator();
		while(it.hasNext()) {
			System.out.println(it.next().data);
		}
	}

	@Override
	public Iterator<Node> iterator() {
		return this;
	}

}

