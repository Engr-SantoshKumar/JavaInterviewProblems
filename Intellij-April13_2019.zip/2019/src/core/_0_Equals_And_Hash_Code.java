package core;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Objects;

/**
 * when both equals and hascode are implented based on apt # and street name, then result
 *  [[1, Hollywood Street], [2, Baker Avenue], [4, Baker Avenue]]
 *  else if equals is missing
 *  [[1, Hollywood Street], [2, Baker Avenue], [2, Baker Avenue], [4, Baker Avenue]]
 *  the two objects O{2, baker Ave} are considered different objects based on their address
 *  else if hashcode is missing
 *  //[[1, Hollywood Street], [2, Baker Avenue], [4, Baker Avenue], [2, Baker Avenue]]
 *  Since the second time when the hascode is generated for 2, BA it came as 3 and since there is
 *  no other object 2, BA on that bucket this is added in bucket 3
 *
 *  args = {String[0]@570}
 * addr = {AddressWithHashCodeEquals[4]@571}
 * set = {HashSet@572}  size = 3
 *  0 = {AddressWithHashCodeEquals@604} "[1, Hollywood Street]"
 *  1 = {AddressWithHashCodeEquals@605} "[2, Baker Avenue]" // for 2, BA the field was overridden
 *  2 = {AddressWithHashCodeEquals@606} "[4, Baker Avenue]"
 *
 * addr1 = {AddressWithHashCodeWithoutEquals[4]@573}
 * set1 = {HashSet@574}  size = 4
 *  0 = {AddressWithHashCodeWithoutEquals@595} "[1, Hollywood Street]"
 *  1 = {AddressWithHashCodeWithoutEquals@596} "[2, Baker Avenue]" // no equals method so key at buc
 *  2 = {AddressWithHashCodeWithoutEquals@597} "[2, Baker Avenue]"// 2 was considered equal to key
 *  3 = {AddressWithHashCodeWithoutEquals@598} "[4, Baker Avenue]"// at bucket 1
 *
 * addr2 = {AddressWithOutHashCodeWithEquals[4]@577}
 * set2 = {HashSet@588}  size = 4
 *  0 = {AddressWithOutHashCodeWithEquals@580} "[1, Hollywood Street]"
 *  1 = {AddressWithOutHashCodeWithEquals@582} "[2, Baker Avenue]" // no hashcode so the objects
 *  2 = {AddressWithOutHashCodeWithEquals@586} "[4, Baker Avenue]" // will go to any bucket
 *  3 = {AddressWithOutHashCodeWithEquals@584} "[2, Baker Avenue]" // meaning when 2, BA was looked
 *  when the hashcode was generated for 2, BA second time it is calculated as 3 and since there is
 *  no 2, BA present in this bucket to override
 */

public class _0_Equals_And_Hash_Code
{
    public static void main(String[] args)
    {
        AddressWithHashCodeEquals addr[] = new AddressWithHashCodeEquals[4];
        addr[0] = new AddressWithHashCodeEquals(1, "Hollywood Street");
        addr[1] = new AddressWithHashCodeEquals(2, "Baker Avenue");
        addr[2] = new AddressWithHashCodeEquals(2, "Baker Avenue");
        addr[3] = new AddressWithHashCodeEquals(4, "Baker Avenue");

        HashSet<AddressWithHashCodeEquals> set = new HashSet<AddressWithHashCodeEquals>();
        set.addAll(Arrays.asList(addr));
        log(set.toString());
        //[[1, Hollywood Street], [2, Baker Avenue], [4, Baker Avenue]]

        AddressWithHashCodeWithoutEquals addr1[] = new AddressWithHashCodeWithoutEquals[4];
        addr1[0] = new AddressWithHashCodeWithoutEquals(1, "Hollywood Street");
        addr1[1] = new AddressWithHashCodeWithoutEquals(2, "Baker Avenue");
        addr1[2] = new AddressWithHashCodeWithoutEquals(2, "Baker Avenue");
        addr1[3] = new AddressWithHashCodeWithoutEquals(4, "Baker Avenue");

        HashSet<AddressWithHashCodeWithoutEquals> set1 = new HashSet<AddressWithHashCodeWithoutEquals>();
        set1.addAll(Arrays.asList(addr1));
        log(set1.toString());
      //  [[1, Hollywood Street], [2, Baker Avenue], [2, Baker Avenue], [4, Baker Avenue]]


        AddressWithOutHashCodeWithEquals addr2[] = new AddressWithOutHashCodeWithEquals[4];
        addr2[0] = new AddressWithOutHashCodeWithEquals(1, "Hollywood Street");
        addr2[1] = new AddressWithOutHashCodeWithEquals(2, "Baker Avenue");
        addr2[2] = new AddressWithOutHashCodeWithEquals(2, "Baker Avenue");
        addr2[3] = new AddressWithOutHashCodeWithEquals(4, "Baker Avenue");

        HashSet<AddressWithOutHashCodeWithEquals> set2 =
                new HashSet<AddressWithOutHashCodeWithEquals>();
        set2.addAll(Arrays.asList(addr2));
        log(set2.toString());

    }

    static void log(String msg)
    {
        System.out.println(msg);
    }
}

class AddressWithHashCodeEquals
{
    int aptNo;
    String streetName;

    @Override
    public int hashCode() { return aptNo; }

    @Override
    public boolean equals(Object obj)
    {
        AddressWithHashCodeEquals other = (AddressWithHashCodeEquals) obj;
        if (aptNo == other.aptNo && streetName.equals(other.streetName))
            return true;
        return false;
    }

    @Override
    public String toString() { return "[" + aptNo + ", " + streetName + "]"; }

    public AddressWithHashCodeEquals(int aptNo, String streetName)
    {
        this.aptNo = aptNo;
        this.streetName = streetName;
    }
}

class AddressWithHashCodeWithoutEquals
{
    int aptNo;
    String streetName;

    @Override
    public int hashCode() { return aptNo; }

    @Override
    public String toString() { return "[" + aptNo + ", " + streetName + "]"; }

    public AddressWithHashCodeWithoutEquals(int aptNo, String streetName)
    {
        this.aptNo = aptNo;
        this.streetName = streetName;
    }
}

class AddressWithOutHashCodeWithEquals
{
    Integer aptNo;
    String streetName;

    /*@Override
    public int hashCode() {
      return  Objects.hashCode((int)System.currentTimeMillis()) ;
    }*/

    @Override
    public boolean equals(Object obj)
    {
        AddressWithHashCodeEquals other = (AddressWithHashCodeEquals) obj;
        if (aptNo == other.aptNo && streetName.equals(other.streetName))
            return true;
        return false;
    }

    @Override
    public String toString() { return "[" + aptNo + ", " + streetName + "]"; }

    public AddressWithOutHashCodeWithEquals(int aptNo, String streetName)
    {
        this.aptNo = aptNo;
        this.streetName = streetName;
    }
}
