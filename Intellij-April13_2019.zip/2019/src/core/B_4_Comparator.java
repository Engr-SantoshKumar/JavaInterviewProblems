package core;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
/*
o/p
color:Fruit & size:0
color:Banana & size:1
color:Orange & size:2
color:Apple & size:3
 */
public class B_4_Comparator {
	public static void main(String[] args) {
		Fruit a = new Fruit("Orange", 2);
		Fruit b = new Fruit("Apple", 3);
		Fruit c = new Fruit("Banana", 1);
		Fruit d = new Fruit("Fruit", 0);
		List<Fruit> list = new ArrayList<>();
		list.add(a);
		list.add(b);
		list.add(c);
		list.add(d);
		Collections.sort(list, new FruitComparator());
		for(Fruit fruit : list) {
			System.out.println(String.format("color:%s & size:%s", fruit.name, fruit.size));
		}
	}
}

class Fruit {
	String name;
	Integer size;

	public Fruit(String name, int size) {
		this.name = name;
		this.size = size;
	}
}

class FruitComparator implements Comparator<Fruit> {

	@Override
	public int compare(Fruit first, Fruit second) {
		return first.size - second.size;
	}

}