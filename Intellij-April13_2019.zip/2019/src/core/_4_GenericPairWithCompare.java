package core;

public class _4_GenericPairWithCompare {
	public static void main(String[] args) {
		Pair<Integer, String> pair1 = new Pair<>(1, "apple");
		Pair<Integer, String> pair2 = new Pair<>(1, "apple");
		System.out.println(" compare : is pair1 equal to pair 2 :" +new Util().compare(pair1, pair2));
		
		
	}
static class Pair<K, V> {
	K key;
	V value;

	public Pair(K key, V value) {
		this.key = key;
		this.value = value;
	}

	K getKey() {
		return key;
	}

	V getValue() {
		return value;
	}

}

// here K and V does not extends the Comparable so we just not use K.compareTo(K) inside it
static class Util {
	public  <K, V> boolean compare(Pair<K, V> one, Pair<K, V> two) {
		return one.getKey().equals(two.getKey()) && one.getValue().equals(two.getValue());
	}
}

}